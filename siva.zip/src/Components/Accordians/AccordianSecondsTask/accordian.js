import React from "react";
import "./accordian.css";


class Accordian extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            listData: this.props.listData,
        };
    }

    // =================================================

    handClick = (key) => {
        let data = Object.assign([], this.state.listData);

        data = data.map((item, index) => {
            if (index === key) {
                item.isOpen = !item.isOpen;
            }
            else {
                item.isOpen = false;
            }
            return item;
        })
        this.setState({
            listData: data
        })
    }

    // ====================================================

    render() {
        return (
                <div className={"accordian_container " + this.props.className}>
                    <div className="accordian_container_shadow">
                        {this.state.listData.map((item, index) => {
                            return (
                                <div key={index} className="accordian">
                                    <div className={`heading ${item.isOpen ? "active" : ""}`}
                                        onClick={() => this.handClick(index)}>
                                        <div className="title">
                                            {item.img}
                                            <h3>{item.heading}</h3>
                                        </div>
                                        <div className="icon">
                                            {
                                                item.isOpen ?
                                                    <svg
                                                        className={` ${item.isOpen ? "rotate" : "arrow"}`}
                                                        xmlns="http://www.w3.org/2000/svg" width="5" height="8"
                                                        color="white" viewBox="0 0 5 8">
                                                        <g transform="translate(0)"><g transform="translate(0 0)">
                                                            <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z" transform="translate(-56.242 0)" /></g></g>
                                                    </svg>
                                                    :
                                                    <svg className="arrow"
                                                        xmlns="http://www.w3.org/2000/svg" width="5" height="8" viewBox="0 0 5 8">
                                                        <g transform="translate(0)"><g transform="translate(0 0)">
                                                            <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z" transform="translate(-56.242 0)" /></g></g>
                                                    </svg>
                                            }
                                        </div>
                                    </div>
                                    <div className={item.isOpen ? "visible" : "hidden"}>
                                        <div className="list">
                                            <ul>
                                                {
                                                    item.skills ? item.skills.map((list, index) => {
                                                        return <li key={index}>{list}</li>
                                                    })
                                                        : null
                                                }
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

        );
    }
}

export default Accordian;