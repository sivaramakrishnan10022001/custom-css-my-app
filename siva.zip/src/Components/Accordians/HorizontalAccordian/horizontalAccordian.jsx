import React from "react";
import "./horizontalAccordian.css";


class HorizontalAccordian extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            horizontalAccordian_listDATA: this.props.horizontalAccordian_listDATA
        };
    }

    // ======================================================

    handClick = (key) => {
        let data = Object.assign([], this.state.horizontalAccordian_listDATA);
        data = data.map((item, index) => {

            if (index === key) {
                item.isOpen = !item.isOpen;
            } else {
                item.isOpen = false;
            }
            return item;
        })
        this.setState({
            horizontalAccordian_listDATA: data
        })
    }


    render() {
        return (
            <div className={"horizontalAccordian_container " + this.props.className}>
                <div className="horizontalAccordian_container_shadow">
                    {this.state.horizontalAccordian_listDATA.map((item, index) => {
                        return (
                            <div key={index} className="horizontalAccordian">
                                <div className={`heading ${item.isOpen ? "active" : ""}`}
                                    onClick={() => this.handClick(index)}>
                                    <div className="title">
                                        <h3 style={{ color: item.isOpen ? "white" : "black" }}>{item.heading}</h3>
                                    </div>
                                    <div className="icon">
                                        {
                                            item.isOpen ?
                                                <svg
                                                    className={` ${item.isOpen ? "rotate" : "arrow"}`}
                                                    xmlns="http://www.w3.org/2000/svg" width="5" height="8"
                                                    color="white" viewBox="0 0 5 8">
                                                    <g transform="translate(0)"><g transform="translate(0 0)">
                                                        <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z" transform="translate(-56.242 0)" /></g></g>
                                                </svg>
                                                :
                                                <svg className="arrow"
                                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 8">
                                                    <g transform="translate(0)"><g transform="translate(0 0)"><path
                                                        d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z" transform="translate(-56.242 0)" /></g></g>
                                                </svg>
                                        }
                                    </div>
                                </div>
                                <div className={item.isOpen ? "visible" : "hidden"}>
                                    <div className="visible_aliment" >
                                        <p >{item.description}</p>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    }
}


export default HorizontalAccordian;