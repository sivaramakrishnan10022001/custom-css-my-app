import React from "react";
import "./BarChartBorderRadius.css";
import { Chart } from "../../chartcdn/chart";

class BarChartBorderRadius extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }
    
    componentDidMount() {
        let Canvas = document.getElementById('border-radius');

        this.mychart = new Chart(Canvas, this.props.data);
    }
    render() {
        return (
            <div className={"barchart-border-radius-wapper "+this.props.className}>
                <div>
                    <canvas id="border-radius" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default BarChartBorderRadius;