
import React from "react";
import "./Delay.css";
import { Chart } from "../../chartcdn/chart";

class Delay extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('delay').getContext('2d');
        let delayed;
        this.mychart = new Chart(ctx, {
            type: "bar",
            data: this.props.data,
            options: {
                animation: {
                    onComplete: () => {
                        delayed = true;
                    },
                    delay: (context) => {
                        let delay = 0;
                        if (context.type === 'data' && context.mode === 'default' && !delayed) {
                            delay = context.dataIndex * 300 + context.datasetIndex * 100;
                        }
                        return delay;
                    },
                },
                scales: {
                    x: {
                        stacked: true,
                    },
                    y: {
                        stacked: true
                    }
                }
            },

        })
    }
    render() {
        return (
            <div className={"delay-wapper " + this.props.className}>
                <div className="delay container">
                    <canvas id="delay" height="500" width="900" ></canvas>
                </div>
            </div>
        )
    }
}

export default Delay;