import React from "react";
import "./FloatingBars.css";
import { Chart } from "../../chartcdn/chart";

class FloatingBars extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }
    componentDidMount() {
        let Canvas = document.getElementById('floatingbars').getContext('2d');
        this.mychart = new Chart(Canvas, this.props.data);
    }
    render() {
        return (
            <div className={"floatingbars-wapper " + this.props.className}>
                <div className="floatingbars-container">
                    <canvas id="floatingbars" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default FloatingBars;