import React from "react";
import "./barborderRadius.css";
import { Chart } from "../../chartcdn/chart";

class BarBorderRadius extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let Canvas = document.getElementById('barborderRadius').getContext('2d');
        this.mychart = new Chart(Canvas, this.props.data)
    }

    render() {
        return (
            <div className={"barborder-radius-wapper " + this.props.className}>
                <div className="barborder-radius-container">
                    <canvas id="barborderRadius" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default BarBorderRadius;