import React from "react";
import "./barchart.css";
import { Chart } from "../../chartcdn/chart";
class BarChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        const ctx = document.getElementById('bar-chart').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);
    }
    render() {
        return (
            <div className={"barchart-wapper " + this.props.className}>
                <div className="barchart-container">
                    <canvas id="bar-chart" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default BarChart;