import React from "react";
import "./barcharthover.css";
import { Chart } from "../../chartcdn/chart";

class BarChartHover extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('barcharthover').getContext('2d');
        this.mychart = new Chart(ctx,this.props.data);

    }
    render() {
        return (
            <div className={"barcharthover-wapper " + this.props.className}>
                <div className="barcharthover-container">
                    <canvas id="barcharthover" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default BarChartHover;