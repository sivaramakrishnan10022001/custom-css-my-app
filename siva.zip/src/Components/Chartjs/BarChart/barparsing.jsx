import React from "react";
import "./barparsing.css";
import { Chart } from "../../chartcdn/chart";

class Barparsing extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentWillUnmount() {
        this.mychart.destroy();
    }
    componentDidMount() {
        const ctx = document.getElementById('canvas').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);
    }
    render() {
        return (
            <div className={"barparsing-wapper " + this.props.className}>
                <div className="barparsing-content">
                    <canvas id="canvas" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default Barparsing;