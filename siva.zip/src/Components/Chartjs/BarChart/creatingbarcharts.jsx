import React from "react";
import "./creatingbarcharts.css";
import { Chart } from "../../chartcdn/chart";

class CreatingBarCharts extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        const densityCanvas = document.getElementById("densityChart");
        this.mychart = new Chart(densityCanvas, this.props.data);
    }
    render() {
        return (
            <div className={"creatingbarcharts-wapper " + this.props.className}>
                <div className="creatingbarcharts-container">
                    <canvas id="densityChart" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default CreatingBarCharts;