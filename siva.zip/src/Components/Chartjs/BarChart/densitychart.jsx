import React from "react";
import "./densitychart.css";
import { Chart } from "../../chartcdn/chart";

class DensityChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        const densityCanvas = document.getElementById("DensityofPlanets");
        this.mychart = new Chart(densityCanvas, this.props.data);
    }

    render() {
        return (
            <div className={"DensityofPlanets-wapper " + this.props.className}>
                <div className="DensityofPlanets-content">
                    <canvas id="DensityofPlanets" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default DensityChart;