import React from "react";
import "./implementation.css";
import { Chart } from "../../chartcdn/chart";

class Implementation extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.myChart.destroy();
    }

    componentDidMount() {
        const ctx = document.getElementById('implementation').getContext('2d');
        const progress = document.getElementById('implementation');
        this.myChart = new Chart(ctx, {
            type: 'bar',
            data: this.props.data,
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: "bottom",
                        labels: {
                            boxWidth: 50,
                            color: "wight",
                            font: {
                                size: 24,
                                weight: "bold"
                            }
                        }
                    },
                    tooltip: {
                        cornerRadius: 0,
                        caretSize: 0,
                        padding: 18,
                        backgroundColor: 'black',
                        borderColor: "gray",
                        borderWidth: 1,
                        titleMarginBottom: 4,
                        titleFont: {
                            "weight": "bold",
                            "size": 22
                        }
                    }
                },
                animation: {
                    onProgress: function (animation) {
                        progress.value = animation.currentStep / animation.numSteps;
                    }
                },
                scales: {
                    xAxes: [{
                        stacked: true
                    }],
                    yAxes: [{
                        stacked: true
                    }]
                }
            }
        });
    }


    render() {
        return (
            <div className={"implementation-wapper " + this.props.className}>
                <div className="implementation-container">
                    <canvas id="implementation" height="500" width="900"></canvas>
                </div>
            </div>

        )
    }
}

export default Implementation;