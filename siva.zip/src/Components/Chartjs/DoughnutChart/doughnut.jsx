import React from "react";
import "./doughnut.css";
import { Chart } from "../../chartcdn/chart";

class Doughnut extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mydoughnut.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('doughnut').getContext('2d');
        this.mydoughnut = new Chart(ctx, this.props.data);
    }

    render() {
        return (
            <div className={"doughnut-wapper " + this.props.className}>
                <div className="doughnut-container">
                    <canvas id="doughnut" height="500" width="500"></canvas>
                </div>
            </div>
        )
    }
}

export default Doughnut;