
import React from "react";
import "./Drop.css";
import { Chart } from "../../chartcdn/chart";

class Drop extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('drop').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);
    }
    render() {
        return (
            <div className={"drop-wapper "+this.props.className}>
                <div className="drop-container">
                    drop animation
                    <canvas id="drop" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default Drop;