import React from "react";
import "./Loop.css";
import { Chart } from "../../chartcdn/chart";

class Loop extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('loop').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data)
    }
    render() {
        return (
            <div className={"loop-wapper " + this.props.className}>
                <div className="loop-container">
                    Loop animation
                    <canvas id="loop" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default Loop;
