
import React from "react";
import "./ScriptableOptionsLineChart.css";
import { Chart } from "../../chartcdn/chart";

class ScriptableOptionsLineChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('scriptable-options-linechart').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);
    }

    render() {
        return (
            <div className={"scriptable-options-linechart " + this.props.className}>
                <div className="scriptable-options-content">
                    <canvas id="scriptable-options-linechart" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default ScriptableOptionsLineChart;