import React from "react";
import "./UpdateChartType.css";
import { Chart } from "../../chartcdn/chart";

class UpdateChartType extends React.Component {
    constructor() {
        super();
        this.state = {
            height: '500',
            width: '900',
        }
    }

    componentWillUnmount() {
        this.UpdateChart.destroy();
    }

    componentDidMount() {

        let ctx = document.getElementById('UpdateChartType').getContext('2d');
        this.UpdateChart = new Chart(ctx, this.props.config);
    }

    updateChartType = (e) => {


        this.UpdateChart.destroy();
        if (e.target.value === 'line') {
            this.setState({
                height: '500',
                width: '900'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configline);
        }
        else if (e.target.value === 'bar') {
            this.setState({
                height: '500',
                width: '900'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configbar);
        }
        else if (e.target.value === 'doughnut') {
            this.setState({
                height: '500',
                width: '500',
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configdoughnut);
            this.UpdateChart.update();
        }
        else if (e.target.value === 'pie') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configpie);
        }
        else if (e.target.value === 'radar') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configradar);
        }
        else if (e.target.value === 'scatter') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configscatter);
            // this.UpdateChart.update();

        }
        else if (e.target.value === 'bubble') {
            this.setState({
                height: '500',
                width: '900'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configbubble);
            // this.UpdateChart.update();

        }
        else if (e.target.value === 'polarArea') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, this.props.configpolarArea);
        }
        this.UpdateChart.update();
    }

    render() {
        return (
            <div className={"UpdateChartType-wapper " + this.props.className}>
                <div className="UpdateChartType-container">
                    <canvas id="UpdateChartType" height={this.state.height} width={this.state.width}></canvas>
                </div>
                <div className="selector">
                    <div className="select-style">
                        <select name="chartType" id="chartType" onChange={(e) => this.updateChartType(e)}>
                            <option value="line">Line</option>
                            <option value="bar">Bar</option>
                            <option value="doughnut">Doughnut</option>
                            <option value="pie">Pie</option>
                            <option value="radar">Radar</option>
                            <option value="scatter">Scatter</option>
                            <option value="bubble">Bubble</option>
                            <option value="polarArea">polarArea</option>
                        </select>
                    </div>
                </div>
            </div>
        )
    }
}

export default UpdateChartType;