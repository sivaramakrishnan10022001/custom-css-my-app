
import React from "react";
import "./areachart.css";
import Chart from "../../chartcdn/chart";

class AreaChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentDidMount() {
        let ctx = document.getElementById("line-chart").getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);

    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    render() {
        return (
            <div className={"areachart-wapper " + this.props.className}>
                <div className="areachart-container">
                    <canvas id="line-chart" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default AreaChart;