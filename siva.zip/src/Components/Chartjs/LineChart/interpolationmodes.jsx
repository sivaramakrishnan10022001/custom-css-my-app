import React from "react";
import "./interpolationmodes";
import Chart from "../../chartcdn/chart";

class InterpolationModes extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }


    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('interpolationmodes').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);
    }

    render() {
        return (
            <div className={"interpolationmodes-wapper " + this.props.className}>
                <div className="interpolationmodes-container">
                    <canvas id="interpolationmodes" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default InterpolationModes;