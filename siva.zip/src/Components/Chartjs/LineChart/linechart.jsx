import React from "react";
import "./linechart.css";
import Chart from "../../chartcdn/chart";

class Linechart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.chart.destroy();
    }

    componentDidMount() {
        const ctx = document.getElementById('linechart').getContext('2d');
        this.chart = new Chart(ctx, this.props.data);
    }

    render() {
        return (
            <div className={"linechart-wapper " + this.props.className}>
                <div className="linechart-content">
                    <canvas id="linechart" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default Linechart;