import React from "react";
import "./linechartanimation.css"
import Chart from "../../chartcdn/chart";

class LineChartAnimation extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentDidMount() {
        let ctx = document.getElementById("linechartanimation").getContext("2d");
        this.mychart = new Chart(ctx, this.props.data);
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    render() {
        return (
            <div className={"linechartanimation-wapper " + this.props.className}>
                <div className="linechartanimation-container">
                    <canvas id="linechartanimation" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default LineChartAnimation;