import React from "react";
import "./linechartboundaries.css";
import Chart from "../../chartcdn/chart";


class LineChartBoundaries extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('speedChart').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data);
    }

    render() {
        return (
            <div className={"linechartboundaries-wapper " + this.props.className}>
                <div className="linechartboundaries-container">
                    <canvas id="speedChart" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }

}
export default LineChartBoundaries;