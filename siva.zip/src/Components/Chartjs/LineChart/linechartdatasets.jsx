import React from "react";
import "./linechartdatasets.css";
import { Chart } from "../../chartcdn/chart";

class LineChartDatasets extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentWillUnmount() {
        this.lineChart.destroy();
    }
    componentDidMount() {
        let linechartdatasets = document.getElementById('linechartdatasets');
        const checkSpeed = (ctx, color_a, color_b) => ctx.p0.parsed.y > ctx.p1.parsed.y ? color_a : color_b;

        this.lineChart = new Chart(linechartdatasets, {
            type: "line",
            data: {
                labels: ["0s", "10s", "20s", "30s", "40s", "50s", "60s"],
                datasets: [
                    {
                        label: "Car A - Speed (mph)",
                        data: [0, 59, 75, 20, 20, 55, 40],
                        borderColor: "#d942dfe7",
                        borderDash: [3, 3],
                        stepped: "middle",
                        pointStyle: "circle",
                        pointBorderWidth: 4,
                        pointRadius: 5,
                        pointBackgroundColor: "#f1c430e7",
                    },
                    {
                        label: "Car B - Speed (mph)",
                        data: [20, 15, 60, 60, 65, 30, 70],
                        borderColor: "yellowgreen",
                        segment: {
                            borderColor: ctx => checkSpeed(ctx, 'orangered', 'yellowgreen'),
                        }
                    }
                ]
            }
        });

    }
    render() {
        return (
            <div className={"linechartdatasets-wapper " + this.props.className}>
                <div className="linechartdatasets-container">
                    <canvas id="linechartdatasets" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default LineChartDatasets;