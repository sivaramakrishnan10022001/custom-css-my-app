import React from "react";
import "./linechartupdate.css";
import { Chart } from "../../chartcdn/chart";

class LineChartUpdate extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('linechartupdate').getContext('2d');
        this.mychart = new Chart(ctx, this.props.data)
    }

    lineUpdate = () => {
        this.mychart.data.datasets[0].data = [1, 1, 1, 2, 3];
        this.mychart.update();
    }

    render() {
        return (
            <div className={"linechartupdate-wapper "+this.props.className}>
                <div className="linechartupdate-container">
                    <canvas id="linechartupdate" height="500" width="900"></canvas>
                    <button style={{ padding: '10px 20px', margin: "1rem" }} onClick={() => this.lineUpdate()}>update</button>
                </div>
            </div>
        )
    }
}

export default LineChartUpdate;