import React from "react";
import "./lineindexaxis.css";
import { Chart } from "../../chartcdn/chart";

class LineIndexAxis extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.chart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('lineindexaxis').getContext('2d');
        var data = this.props.data;
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                datasets: [
                    {
                        data: data.map((v) => ({ y: v.y, x: v.x })),
                        label: "data1",
                        borderColor: "red",
                        fill: true,
                        tension: 0.4,
                        backgroundColor: "#e621e641",
                    },
                    {
                        borderColor: "blue",
                        label: "data2",
                        data: data.map((v) => ({ y: v.y, x: 2 * v.x - 1.5 * v.y })),
                        fill: true,
                        backgroundColor: "#e6bb2125",
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                layout: {
                    padding: 16,
                },
                scales: {
                    y: {
                        type: "linear",
                    },
                    x: {
                        type: "linear",
                    },
                },
            }
        })
    }
    render() {
        return (
            <div className={"lineindexaxis-wapper " + this.props.className}>
                <div className="lineindexaxis-container">
                    <canvas id="lineindexaxis" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default LineIndexAxis;