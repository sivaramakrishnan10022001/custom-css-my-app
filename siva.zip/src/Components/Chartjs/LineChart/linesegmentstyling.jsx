import React from "react";
import "./linesegmentstyling.css";
import { Chart } from "../../chartcdn/chart";

class LineSegmentStyling extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let ctx = document.getElementById('linesegmentstyling').getContext('2d');
        const skipped = (ctx, value) => ctx.p0.skip || ctx.p1.skip ? value : undefined;
        const down = (ctx, value) => ctx.p0.parsed.y > ctx.p1.parsed.y ? value : undefined;
        const genericOptions = {
            fill: false,
            interaction: {
                intersect: false
            },
            radius: 0,
        };

        this.mychart = new Chart(ctx, {
            type: "line",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: 'My First Dataset',
                        data: [65, 59, NaN, 48, 56, 57, 40],
                        borderColor: 'rgb(75, 192, 192)',
                        segment: {
                            borderColor: ctx => skipped(ctx, 'rgb(0,0,0,0.2)') || down(ctx, 'rgb(192,75,75)'),
                            borderDash: ctx => skipped(ctx, [12, 12]),
                        },
                        spanGaps: true
                    }
                ]

            },
            options: genericOptions
        })
    }
    render() {
        return (
            <div className={"linesegmentstyling-wapper "+this.props.className}>
                LineSegmentStyling
                <div className="linesegmentstyling-container">
                    <canvas id="linesegmentstyling" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default LineSegmentStyling;