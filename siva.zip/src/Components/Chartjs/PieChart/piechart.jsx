
import React from "react";
import "./piechart.css";
import { Chart } from "../../chartcdn/chart";

class PieChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        this.mychart = new Chart(document.getElementById("pie-chart"), this.props.data);
    }

    render() {
        return (
            <div className={"piechart-wapper "+this.props.className}>
                <div className="piechart-container">
                    <canvas id="pie-chart" height="500" width="500"></canvas>
                </div>
            </div>
        )
    }
}

export default PieChart;