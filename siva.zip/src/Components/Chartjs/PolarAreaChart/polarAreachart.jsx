import React from "react";
import "./polarAreachart.css";
import { Chart } from "../../chartcdn/chart";

class PolarAreaChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        this.mychart = new Chart(document.getElementById("polar-chart"), this.props.data);
    }
    render() {
        return (
            <div className={"polarareachart-wapper "+this.props.className}>
                <div className="polarAreachart-container">
                    <canvas id="polar-chart" height="500" width="500"></canvas>
                </div>
            </div>
        )
    }
}

export default PolarAreaChart;