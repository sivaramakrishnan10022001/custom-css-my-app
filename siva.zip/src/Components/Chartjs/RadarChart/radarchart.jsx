import React from "react";
import "./radarchart.css";
import { Chart } from "../../chartcdn/chart";

class RadarChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }
    componentDidMount() {
        this.mychart = new Chart(document.getElementById("radar-chart"), this.props.data);
    }
    render() {
        return (
            <div className={"radarchart-wapper "+this.props.className}>
                <div>
                    <canvas id="radar-chart" height="500" width="500"></canvas>
                </div>
            </div>
        )
    }
}

export default RadarChart;