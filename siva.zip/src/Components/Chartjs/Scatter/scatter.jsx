import React from "react";
import "./scatter.css";
import Chart from "../../chartcdn/chart";

class Scatter extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentWillUnmount() {
        this.mychart.destroy();
    }

    componentDidMount() {
        let Canvas = document.getElementById('scatter').getContext('2d');

        this.mychart = new Chart(Canvas, this.props.data)
    }
    render() {
        return (
            <div className={"scatter-wapper "+this.props.className}>
                <div className="scatter-container">
                    <canvas id="scatter" height="500" width="900"></canvas>
                </div>
            </div>
        )
    }
}

export default Scatter;