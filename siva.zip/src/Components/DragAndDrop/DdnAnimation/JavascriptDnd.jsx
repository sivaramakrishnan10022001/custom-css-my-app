import React from "react";
import "./JavascriptDnd.css";

class JavascriptDnd extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pos: {
                x: null,
                y: null,
            },
            diff: {
                x: null,
                y: null
            },
            rightoffsetX: 0,
            mousedown: false,
            selectedItem: null,
            resetTransition: false,
            transitionTime: 300,
            course: [
                { name: "html" },
                { name: "css" },
                { name: "javascript" },
                { name: "C++" },
                { name: "php" },
                { name: "java" },
            ]
        }
    }
    componentDidMount() {
        this.positionItemFunction();
        this.positionItems();
    }

    positionItems = (insertIndex = null) => {
        let itemsList = document.querySelectorAll('.items .item');
        itemsList = Array.prototype.slice.call(itemsList);
        itemsList = itemsList.filter(item => item.getAttribute('selected') !== 'yes');
        let indexCounter = 0;
        itemsList.forEach((item) => {
            if (insertIndex === indexCounter + 1) {
                indexCounter++;
            }
            item.style.top = (70 * indexCounter) + (indexCounter * 10) + 'px';
            item.setAttribute('order', indexCounter + 1);
            indexCounter++;
            this.setState({
                totleHeight: (70 * indexCounter) + (indexCounter * 10)
            })
        });
    }

    positionItemsInOrder = () => {
        const itemsEle = document.querySelector('.items');
        let itemsList = document.querySelectorAll('.items .item'); itemsList = Array.prototype.slice.call(itemsList);
        itemsList = itemsList.sort((a, b) => {
            return Number(a.getAttribute('order')) > Number(b.getAttribute('order')) ? 1 : -1;
        });
        itemsList.forEach((item, index) => {
            if (item.getAttribute('selected') === 'yes') {
                item.removeAttribute('selected');
                item.style.left = '0';
                setTimeout(() => {
                    item.style.zIndex = '0';
                }, this.state.transitionTime);
            };
            item.style.top = (70 * index) + (index * 10) + 'px';
            item.setAttribute('order', index + 1);
        });
        this.setState({
            resetTransition: true,
        }, () => {
            //When transition is over
            setTimeout(() => {
                while (itemsEle.firstChild) {
                    itemsEle.removeChild(itemsEle.lastChild);
                };
                itemsList.forEach((item) => {
                    itemsEle.append(item);
                });
                this.setState({
                    resetTransition: false,
                })
            }, this.state.transitionTime);
        })
    }

    positionItemFunction = () => {
        const itemsEle = document.querySelector('.items');
        const numOfItems = document.querySelectorAll('.items .item').length;
        //Set fixed height of items container
        document.querySelector('.items').style.height = (numOfItems * 70) + (numOfItems * 10) + 'px';
        document.querySelectorAll('.items .item').forEach((item, index) => {
            item.addEventListener('mousedown', (e) => {
                if (!this.state.pos.x || this.state.resetTransition) return;
                this.setState({
                    mousedown: true,
                    selectedItem: item,
                    diff: {
                        y: this.state.pos.y - item.offsetTop,
                        x: this.state.pos.x - item.offsetLeft
                    }
                }, () => {
                    let offsetY = this.state.pos.y - this.state.diff.y;
                    let offsetX = this.state.pos.x - this.state.diff.x;
                    item.style.top = offsetY + 'px';
                    item.style.left = offsetX + 'px';
                    item.style.zIndex = '1000';
                    item.setAttribute('selected', 'yes');

                }, () => {
                    if (this.state.mousedown === false) {
                        this.positionItemsInOrder();
                    }
                })
            });

            item.addEventListener('mouseup', (e) => {
                this.positionItemsInOrder();
                this.setState({
                    mousedown: false,
                })
                e.stopPropagation()
                e.preventDefault();
            });

            item.addEventListener('mousemove', (e) => {
                this.setState({
                    pos: {
                        x: e.clientX - itemsEle.offsetLeft,
                        y: e.clientY - (itemsEle.offsetTop - window.scrollY)
                    }
                }, () => {
                    // ===== ScrollY, so that a vertical scroll bar does not mess everything up ====
                    if (!this.state.mousedown) return;
                    let offsetY = this.state.pos.y - this.state.diff.y;
                    let offsetX = this.state.pos.x - this.state.diff.x;
                    this.setState({
                        rightoffsetX: offsetX,
                        rightoffsetY: offsetY,
                    }, () => {
                        if (this.state.rightoffsetX > 270 || this.state.rightoffsetX < -260) {
                            this.setState({
                                mousedown: false,
                            }, () => {
                                this.positionItemsInOrder();
                                this.setState({
                                    rightoffsetX: 0,
                                })
                            })
                        }
                        else if (this.state.rightoffsetY > this.state.totleHeight + 70) {
                            this.setState({
                                mousedown: false,
                            }, () => {
                                this.positionItemsInOrder();
                                this.setState({
                                    rightoffsetY: 0,
                                })
                            })
                        }
                        else if (this.state.rightoffsetY < -80) {
                            this.setState({
                                mousedown: false,
                            }, () => {
                                this.positionItemsInOrder();
                                this.setState({
                                    rightoffsetY: 0,
                                })
                            })
                        }
                        this.state.selectedItem.style.top = offsetY + 'px';
                        this.state.selectedItem.style.left = offsetX + 'px';
                        let orderOfSelectedItem = Number(this.state.selectedItem.getAttribute('order'));
                        //================= Test for new position =================
                        if (orderOfSelectedItem !== 1) {
                            let beforeItem = document.querySelector(`.items .item[order*="${orderOfSelectedItem - 1}"]`);
                            let beforeMiddle = this.state.pos.y < beforeItem.offsetTop + (beforeItem.clientHeight / 2);
                            if (beforeMiddle) {
                                this.positionItems(orderOfSelectedItem - 1);
                                this.state.selectedItem.setAttribute('order', orderOfSelectedItem - 1);
                                return;
                            }
                        };
                        if (orderOfSelectedItem !== document.querySelectorAll('.items .item').length) {
                            let afterItem = document.querySelector(`.items .item[order*="${orderOfSelectedItem + 1}"]`);
                            let afterMiddle = this.state.pos.y > afterItem.offsetTop + (afterItem.clientHeight / 2);
                            if (afterMiddle) {
                                this.positionItems(orderOfSelectedItem + 1);
                                this.state.selectedItem.setAttribute('order', orderOfSelectedItem + 1);
                                return;
                            }
                        };
                    })
                })
                e.preventDefault();
            });
        });
    }

    render() {
        return (
            <div className={"drag-and-drop-wapper " + this.props.className}>
                <div className="drag-and-drop-container">
                    <div className="items">
                        {
                            this.state.course.map((course, courseInx) => {
                                return (
                                    <div className="item" key={courseInx}>
                                        <div className="hamburger">
                                            <div className="center"></div>
                                        </div>
                                        <div className="item-heading">{course.name}</div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default JavascriptDnd;