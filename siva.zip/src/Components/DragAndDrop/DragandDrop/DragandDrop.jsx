import React from "react";
import "./DragandDrop.css";

class DragandDrop extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            datas: ["HTML", "CSS", "JavaScript", "PHP", "MySQL"],
            newItem: '',
        }
        this.headingRef = React.createRef();
        this.headingHoverRef = React.createRef();
        this.searchValue = React.createRef();
    }

    headingStart = (e, index, item) => {
        this.headingRef = index;
        this.setState({
            value: item,
            styling: true,
        });
    };

    headingHover = (e, index) => {
        this.headingHoverRef = index;
    };


    headingEnd = () => {
        let data = [...this.state.datas];
        let copyheading = data[this.headingRef];
        data.splice(this.headingRef, 1);
        data.splice(this.headingHoverRef, 0, copyheading);
        this.headingRef = null;
        this.headingHoverRef = null;
        this.setState({
            datas: data,
            styling: false,
            value: '',

        });
    };

    handleChanging = (e) => {
        let newValue = e.target.value;
        this.setState({
            newItem: newValue
        })
    }

    handleClicked = () => {
        if (this.state.newItem !== '') {
            this.state.datas.push(this.state.newItem)
        }
        this.searchValue.current.value = ''
        this.setState({
            newItem: "",
        })
    }

    render() {
        return (
            <div className={"DragandDrop_container " + this.props.className}>
                <h1>DRAG AND DROP</h1>
                <div className="input_box">
                    <input type="text"
                        className="input"
                        ref={this.searchValue}
                        onChange={(e) => this.handleChanging(e)}
                        placeholder="Add items in your list"
                    />
                    <span className="add" onClick={() => this.handleClicked()}>+</span>
                </div>
                <ul>
                    {this.state.datas.map((item, index) => {
                        return (
                            <li className={`draggable ${item === this.state.value ? "opacity" :""}`}
                                key={index}
                                onDragStart={(e) => this.headingStart(e, index, item)}
                                onDragEnter={(e) => this.headingHover(e, index)}
                                onDragEnd={(e) => this.headingEnd(e)}
                                draggable >
                                {item}
                            </li>
                        )
                    })}
                </ul>
            </div>
        )
    }

}

export default DragandDrop;

