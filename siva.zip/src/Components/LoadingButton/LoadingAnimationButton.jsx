import React from "react";
import "./loadingAnimationButton.css";

class LoadingAnimationButton extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            Loading: false
        }
    }

    // ==================================================

    handleClick = () => {
        this.setState({
            Loading: true
        })
        setTimeout(() => {
            this.setState({
                Loading: false
            })
        }, 4000);
    }

    // ================================================

    render() {
        const LoadingOne = <div className="btn-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        return (
            <div className={"Loading_Btn " + this.props.className}>
                <button className={this.state.Loading ? "Btn_share_true" : "Btn_share"}
                    onClick={() => this.handleClick()}>
                    <div>
                        <div>
                            <h3>share</h3>
                        </div>
                        {this.state.Loading ? LoadingOne : <i className="fas fa-share-alt"></i>}

                    </div>
                </button>
            </div>
        )
    }
}

export default LoadingAnimationButton;