import React from "react";
import "./main.css";
import CountdownTimer from "../CountdownTimer/countdowntimer";
import DragandDrop from "../DragAndDrop/DragandDrop/DragandDrop";
import JavascriptDnd from "../DragAndDrop/DdnAnimation/JavascriptDnd";
import Navigation from "../Navigation/navigation";
import AccordianFirst from "../Accordians/AccordianFirstTask/AccordianFirst";
import Accordian from "../Accordians/AccordianSecondsTask/accordian";
import HorizontalAccordian from "../Accordians/HorizontalAccordian/horizontalAccordian";
import Stepper from "../StepperCom/Stepper";
import LoadingButton from "../LoadingButton/LoadingButton";
import LoadingAnimationButton from "../LoadingButton/LoadingAnimationButton";
import SelectorBox from "../selectorBoxs/selectorBox";
import AnimationSelector from "../selectorBoxs/AnimationSelectorBox/AnimationSelector";
import Table from "../TableCom/BasicTable/Table";
import Customization from "../TableCom/Customization/Customization";
import DenseTable from "../TableCom/DenseTable/DenseTable";
import DynamicTableApp from "../TableCom/dynamicTable/dynamicTableApp";
import SortingAndSelecting from "../TableCom/SortingAndSelecting/SortingAndSelecting";
import AreaChart from "../Chartjs/LineChart/areachart";
import InterpolationModes from "../Chartjs/LineChart/interpolationmodes";
import Linechart from "../Chartjs/LineChart/linechart";
import LineChartAnimation from "../Chartjs/LineChart/linechartanimation";
import LineChartBoundaries from "../Chartjs/LineChart/linechartboundaries";
import LineChartDatasets from "../Chartjs/LineChart/linechartdatasets";
import ScriptableOptionsLineChart from "../Chartjs/LineChart/ScriptableOptionsLineChart";
import BarChart from "../Chartjs/BarChart/barchart";
import Barparsing from "../Chartjs/BarChart/barparsing";
import CreatingBarCharts from "../Chartjs/BarChart/creatingbarcharts";
import DensityChart from "../Chartjs/BarChart/densitychart";
import BarChartBorderRadius from "../Chartjs/BarChart/BarChartBorderRadius";
import BarBorderRadius from "../Chartjs/BarChart/barborderRadius";
import StackedBar from "../Chartjs/BarChart/StackedBar";
import FloatingBars from "../Chartjs/BarChart/FloatingBars";
import BarChartHover from "../Chartjs/BarChart/barcharthover";
import PieChart from "../Chartjs/PieChart/piechart";
import RadarChart from "../Chartjs/RadarChart/radarchart";
import PolarAreaChart from "../Chartjs/PolarAreaChart/polarAreachart";
import Doughnut from "../Chartjs/DoughnutChart/doughnut";
import Delay from "../Chartjs/BarChart/Delay";
import Drop from "../Chartjs/LineChart/Drop";
import Loop from "../Chartjs/LineChart/Loop";
import ProgressiveLine from "../Chartjs/LineChart/ProgressiveLine";
import Scatter from "../Chartjs/Scatter/scatter";
import CustomTooltipContent from "../Chartjs/LineChart/CustomTooltipContent";
import LineSegmentStyling from "../Chartjs/LineChart/linesegmentstyling";
import Implementation from "../Chartjs/BarChart/implementation";
import LineChartUpdate from "../Chartjs/LineChart/linechartupdate";
import AnimationLineChart from "../Chartjs/LineChart/animationlinechart";
import LineIndexAxis from "../Chartjs/LineChart/lineindexaxis";
import UpdateChartType from "../Chartjs/LineChart/UpdateChartType";
// import LearnFilterAnimation from "../LearnFilterAnimation/LearnFilterAnimation";

// 

import { BouncingBall } from "../Animations/BouncingBall/BouncingBall";
import { ButtonHoverEffects } from "../Animations/ButtonHoverEffects/buttonhovereffects";
import { ClippathButtonHoverEffect } from "../Animations/ClippathButtonHoverEffect/ClippathButtonHoverEffect";
import Clock from "../Animations/Clock/Clock";
import { Effect } from "../Animations/GlassmorphismEffect/Effect";
import img1 from "./shoes.png";
import img2 from "./shoe.png";
import img3 from "./shoee.png";
import { LiquidLoader } from "../Animations/LiquidLoader/liquidloader";
import { Loading } from "../Animations/Loading/loading";
import MediaIcon from "../Animations/mediaicon/media";
import Pepsi from "../Animations/Pepsi/pepsi";
import PepsiImage from "./can-pepsi.png";
import { RadioButton } from "../Animations/RadioButton/RadioButton";
import TextTyping from "../Animations/TextTyping/TextTyping";
import HeaderNavigation from "../headernavigation/headernavigation";
// import NavigationLeft from "../NavigationLeft/NavigationLeft";
import profile from "./profile.jpg";
import Netflix from "../Netflix/netflix";
import { ListView } from "../listcomponents/ListView";
import { SampleCompOne } from "../listcomponents/samplecomp/SampleCompOne";
import DragDrop from "../DragDropList/DragDrop";
import Dnd from "../DragDropList/dnd/dnd";
import SortableComponent from "../DragDropList/demo/demo";



class Mian extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    render() {
        let data = [
            {
                title: "Home",
                active: true,
                viewbox: "0 0 576 512",
                svgpath: "M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z",
            },
            {
                title: "profile",
                active: false,
                viewbox: "0 0 448 512",
                svgpath: "M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z",
            },
            {
                title: "message",
                viewbox: "0 0 512 512",
                svgpath: "M256 32C114.6 32 0 125.1 0 240c0 47.6 19.9 91.2 52.9 126.3C38 405.7 7 439.1 6.5 439.5c-6.6 7-8.4 17.2-4.6 26S14.4 480 24 480c61.5 0 110-25.7 139.1-46.3C192 442.8 223.2 448 256 448c141.4 0 256-93.1 256-208S397.4 32 256 32zm0 368c-26.7 0-53.1-4.1-78.4-12.1l-22.7-7.2-19.5 13.8c-14.3 10.1-33.9 21.4-57.5 29 7.3-12.1 14.4-25.7 19.9-40.2l10.6-28.1-20.6-21.8C69.7 314.1 48 282.2 48 240c0-88.2 93.3-160 208-160s208 71.8 208 160-93.3 160-208 160z",
            },
            {
                title: "photos",
                active: false,
                viewbox: "0 0 512 512",
                svgpath: "M512 144v288c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V144c0-26.5 21.5-48 48-48h88l12.3-32.9c7-18.7 24.9-31.1 44.9-31.1h125.5c20 0 37.9 12.4 44.9 31.1L376 96h88c26.5 0 48 21.5 48 48zM376 288c0-66.2-53.8-120-120-120s-120 53.8-120 120 53.8 120 120 120 120-53.8 120-120zm-32 0c0 48.5-39.5 88-88 88s-88-39.5-88-88 39.5-88 88-88 88 39.5 88 88z",
            },
            {
                title: "settings",
                active: false,
                viewbox: "0 0 512 512",
                svgpath: "M487.4 315.7l-42.6-24.6c4.3-23.2 4.3-47 0-70.2l42.6-24.6c4.9-2.8 7.1-8.6 5.5-14-11.1-35.6-30-67.8-54.7-94.6-3.8-4.1-10-5.1-14.8-2.3L380.8 110c-17.9-15.4-38.5-27.3-60.8-35.1V25.8c0-5.6-3.9-10.5-9.4-11.7-36.7-8.2-74.3-7.8-109.2 0-5.5 1.2-9.4 6.1-9.4 11.7V75c-22.2 7.9-42.8 19.8-60.8 35.1L88.7 85.5c-4.9-2.8-11-1.9-14.8 2.3-24.7 26.7-43.6 58.9-54.7 94.6-1.7 5.4.6 11.2 5.5 14L67.3 221c-4.3 23.2-4.3 47 0 70.2l-42.6 24.6c-4.9 2.8-7.1 8.6-5.5 14 11.1 35.6 30 67.8 54.7 94.6 3.8 4.1 10 5.1 14.8 2.3l42.6-24.6c17.9 15.4 38.5 27.3 60.8 35.1v49.2c0 5.6 3.9 10.5 9.4 11.7 36.7 8.2 74.3 7.8 109.2 0 5.5-1.2 9.4-6.1 9.4-11.7v-49.2c22.2-7.9 42.8-19.8 60.8-35.1l42.6 24.6c4.9 2.8 11 1.9 14.8-2.3 24.7-26.7 43.6-58.9 54.7-94.6 1.5-5.5-.7-11.3-5.6-14.1zM256 336c-44.1 0-80-35.9-80-80s35.9-80 80-80 80 35.9 80 80-35.9 80-80 80z",
            },
        ]
        let listContent = [
            {
                heading: "iphone",
                description:
                    "The iPhone is a smartphone made by Apple that combines a computer, iPod, digital camera and cellular phone into one device with a touchscreen interface. ... The first-generation iPhone came preloaded with a suite of Apple software, including iTunes, the Safari web browser and iPhoto."
            },
            {
                heading: "windows",
                description:
                    "an opening especially in the wall of a building for admission of light and air that is usually closed by casements or sashes containing transparent material (such as glass) and capable of being opened and shut. b : windowpane. c : a space behind a window of a retail store containing displayed."
            },
            {
                heading: "macbook",
                description:
                    "The MacBook is Apple's third laptop computer family, introduced in 2006. Prior laptops were the PowerBook and iBook. In 2015, new MacBooks featured Apple's Retina Display and higher resolutions, as well as the Force Touch trackpad that senses different pressure levels."
            },
            {
                heading: "android phone",
                description:
                    "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
            }
        ]
        let listContentSecond = [
            {
                heading: "Web design",
                img: <img src="https://img.icons8.com/ios/50/000000/web-design.png" />,
                skills: [
                    "javascript",
                    "Reactjs",
                    "Nodejs"
                ]
            },
            {
                heading: "Coding",
                img: <img src="https://img.icons8.com/ios/50/000000/laptop-coding.png" />,
                skills: [
                    "html",
                    "css",
                    "javascript"
                ]
            },
            {
                heading: "Devices",
                img: <img src="https://img.icons8.com/ios/50/000000/multiple-devices.png" />,
                skills: [
                    "html",
                    "css",
                    "javascript"
                ]
            },
            {
                heading: "Global",
                img: <img src="https://img.icons8.com/ios/50/000000/global-warming.png" />,
                skills: [
                    "html",
                    "css",
                    "javascript"
                ]
            }
        ]
        let horizontalAccordian_listDATA = [
            {
                heading: "iphone",
                description:
                    "The iPhone is a smartphone made by Apple that combines a computer, iPod, digital camera and cellular phone into one device with a touchscreen interface. ... The first-generation iPhone came preloaded with a suite of Apple software, including iTunes, the Safari web browser and iPhoto."
            },
            {
                heading: "windows",
                description:
                    "an opening especially in the wall of a building for admission of light and air that is usually closed by casements or sashes containing transparent material (such as glass) and capable of being opened and shut. b : windowpane. c : a space behind a window of a retail store containing displayed."
            },
            {
                heading: "macbook",
                description:
                    "The MacBook is Apple's third laptop computer family, introduced in 2006. Prior laptops were the PowerBook and iBook. In 2015, new MacBooks featured Apple's Retina Display and higher resolutions, as well as the Force Touch trackpad that senses different pressure levels."
            },
            {
                heading: "android phone",
                description:
                    "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
            },
            {
                heading: "android phone",
                description:
                    "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
            },
            {
                heading: "android phone",
                description:
                    "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
            },
        ]
        let AreaChartData = {
            type: 'line',
            data: {
                labels: [1500, 1600, 1700, 1750, 1800, 1850, 1900, 1950, 1999, 2050],
                datasets: [{
                    data: [86, 114, 106, 106, 107, 111, 133, 221, 783, 2478],
                    label: "Africa",
                    borderColor: "#3e95cd",
                    fill: false
                }, {
                    data: [282, 350, 411, 502, 635, 809, 947, 1402, 3700, 5267],
                    label: "Asia",
                    borderColor: "#8e5ea2",
                    fill: false
                }, {
                    data: [168, 170, 178, 190, 203, 276, 408, 547, 675, 734],
                    label: "Europe",
                    borderColor: "#3cba9f",
                    fill: false
                }, {
                    data: [40, 20, 10, 16, 24, 38, 74, 167, 508, 784],
                    label: "Latin America",
                    borderColor: "#e8c3b9",
                    fill: false
                }, {
                    data: [6, 3, 2, 2, 7, 26, 82, 172, 312, 433],
                    label: "North America",
                    borderColor: "#c45850",
                    fill: false
                }
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'World population per region (in millions)'
                }
            }
        }
        let InterpolationmodesData = {
            type: 'line',
            data: {
                labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
                datasets: [
                    {
                        label: "Cubic interpolation (monotone)",
                        data: [0, 20, 20, 60, 60, 120, NaN, 180, 120, 125, 105, 110, 170],
                        borderColor: "#57bdec",
                        fill: false,
                        cubicInterpolationMode: 'monotone',
                        tension: 0.4
                    },
                    {
                        label: "Cubic interpolation",
                        data: [0, 20, 20, 60, 60, 120, NaN, 180, 120, 125, 105, 110, 170],
                        borderColor: "#d81da0",
                        fill: false,
                        tension: 0.4
                    },
                    {
                        label: 'Linear interpolation (default)',
                        data: [0, 20, 20, 60, 60, 120, NaN, 180, 120, 125, 105, 110, 170],
                        borderColor: '#1dd84c',
                        fill: false
                    }
                ]
            },

            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Chart.js Line Chart - Cubic interpolation mode'
                    },
                },
                interaction: {
                    intersect: false,
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true
                        },
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Value'
                        },
                        suggestedMin: -10,
                        suggestedMax: 200,
                    }
                }
            }
        }
        let linechartdata = {
            type: "line",
            data: {
                labels: [50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150],
                datasets: [{
                    label: "data",
                    fill: false,
                    backgroundColor: "#3c85d3",
                    borderJoinStyle: "miter",
                    borderCapStyle: "bevel",
                    pointStyle: "cricle",
                    borderWidth: 5,
                    pointHitRadius: 1,
                    pointBorderWidth: 5,
                    lineTension: 0.2,
                    borderColor: "#81c9eb",
                    pointRadius: 5,
                    order: 0,
                    data: [7, 8, 8, 9, 9, 9, 10, 11, 14, 14, 15],
                }]
            },
            options: {
                legend: { display: true },
                scales: {
                    yAxes: [{ ticks: { min: 6, max: 16 } }],
                }
            }
        }
        let LineChartAnimationData = {
            type: "line",
            data: {
                labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                datasets: [
                    {
                        backgroundColor: "#ff638480",
                        borderColor: "#ff6384",
                        borderWidth: 1,
                        fill: true,
                        data: [10, 7, 9, 5, 8, 3, 4, 2, 1, 1]
                    }
                ]
            },
            options: {
                animation: {
                    x: {
                        duration: 5000,
                        from: 0,
                    },
                    y: {
                        duration: 3000,
                        from: 500
                    }
                }
            }
        }
        let LineChartBoundariesData = {
            type: "line",
            data: {
                labels: ["0s", "10s", "20s", "30s", "40s", "50s", "60s"],
                datasets: [
                    {
                        label: "car speed (mph)",
                        data: [0, 59, 75, 30, 10, 55, 40],
                        borderColor: "#67a4dd",
                        pointBackgroundColor: "#842beb",
                        pointBorderColor: "#72dfd9",
                        lineTension: 0.4,
                        backgroundColor: "#3b8dda6e",
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointBorderWidth: 4,
                        pointStyle: "circle",
                        borderDash: [20, 10, 60, 10],
                        borderDashOffset: 0.0,
                        borderJoinStyle: "miter"
                    },
                ]
            },
            options: {
                animations: {
                    tension: {
                        duration: 1500,
                        easing: 'linear',
                        from: 1,
                        to: 0,
                        loop: true
                    }
                },
            }
        }
        let ScriptableOptionsLineChartData = {
            type: 'line',
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july", "august", "september", "october", "november", "december"],
                datasets: [
                    {
                        data: [75, 45, 8, 50, 16, 72, 45, 87, 75, 96, 89, 55],
                        pointRotation: 3,
                        pointBorderWidth: 8,
                        borderColor: "#4DC9F6",
                        borderWidth: 3,
                        pointStyle: ["circle", "rect"]
                    }
                ]
            },
            options: {
                plugins: {
                    legend: 'false',
                    tooltip: 'true',
                },
                elements: {
                    line: {
                        fill: 'false',
                        backgroundColor: "#ff00bf",
                        borderColor: "#ff00bf"
                    },
                    point: {
                        backgroundColor: "#ff00bf",
                        hoverBackgroundColor: "00ffff",
                        radius: 10,
                        pointStyle: ["circle", "rect"],
                        hoverRadius: 15,
                    }
                }
            }
        }
        let BarChartData = {
            type: "bar",
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        lable: "Population (millions)",
                        backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                        data: [2478, 5267, 734, 784, 433]
                    }
                ],
            },
            options: {
                legend: {
                    display: false,
                },
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        }
        let BarparsingData = {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb'],
                datasets: [{
                    label: 'Net sales',
                    data: [
                        { x: 'Jan', net: 100, cogs: 50, gm: 50 },
                        { x: 'Feb', net: 120, cogs: 55, gm: 75 }
                    ],
                    parsing: {
                        yAxisKey: 'net'
                    }
                }, {
                    label: 'Cost of goods sold',
                    data: [
                        { x: 'Jan', net: 100, cogs: 50, gm: 50 },
                        { x: 'Feb', net: 120, cogs: 55, gm: 75 }
                    ],
                    parsing: {
                        yAxisKey: 'cogs'
                    }
                }, {
                    label: 'Gross margin',
                    data: [
                        { x: 'Jan', net: 100, cogs: 50, gm: 50 },
                        { x: 'Feb', net: 120, cogs: 55, gm: 75 }
                    ],
                    parsing: {
                        yAxisKey: 'gm'
                    }
                }]
            },
        }
        let CreatingBarChartsData = {
            type: 'bar',
            data: {
                labels: ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
                datasets: [
                    {
                        label: 'Density of Planets (kg/m3)',
                        data: [5427, 5243, 5514, 3933, 1326, 687, 1271, 1638]
                    }
                ]
            }
        }
        let DensityChartData = {
            type: "bar",
            data: {
                labels: ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
                datasets: [
                    {
                        label: "Density of Planets (kg/m3)",
                        data: [5427, 5243, 5514, 3933, 1326, 687, 1271, 1638],
                        backgroundColor: "pink",
                        borderColor: "red",
                        borderWidth: 2,
                        hoverBorderWidth: 2,
                        hoverBackgroundColor: "darkgray",
                        hoverBorderColor: "green",
                        indexAxis: "y",
                        barPercentage: 1.1
                    }
                ]
            }
        }
        let BarChartBorderRadiusData = {
            type: "bar",
            data: {
                labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
                datasets: [
                    {
                        label: "data 1",
                        data: [-12, -25, 13, 10, 25, -9],
                        backgroundColor: "#e6c298",
                        borderWidth: 2,
                        borderColor: "#ce9d65",
                        borderSkipped: false,
                        borderRadius: {
                            topLeft: 50,
                            topRight: 50,
                            bottomLeft: 50,
                            bottomRight: 50
                        }
                    },
                    {
                        label: 'data 2',
                        data: [20, 21, -27, 3, -8, -37],
                        backgroundColor: '#b4b9d8',
                        borderWidth: 2,
                        borderColor: "#8e98da",
                        borderRadius: 5,
                        borderSkipped: false,
                    },
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Chart.js Bar Chart'
                    }
                }
            },
        }
        let BarBorderRadiusData = {
            type: "bar",
            data: {
                labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
                datasets: [{
                    label: 'data 0',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: '#bd539d',
                    borderWidth: 0,
                    borderRadius: {
                        topLeft: 50,
                        topRight: 50,
                        bottomLeft: 50,
                        bottomRight: 50
                    },
                    borderSkipped: false,
                }, {
                    label: 'data 1',
                    data: [20, 5, 10, 15, 12, 13],
                    backgroundColor: '#00ffbf',
                    borderWidth: 0,
                    borderRadius: {
                        topLeft: 50,
                        topRight: 50,
                        bottomLeft: 50,
                        bottomRight: 50
                    },
                    borderSkipped: false,
                }, {
                    label: 'data 2',
                    data: [20, 0, 30, 0, -5, -10],
                    backgroundColor: '#fc70d2',
                    borderWidth: 0,
                    borderRadius: {
                        topLeft: 50,
                        topRight: 50,
                        bottomLeft: 50,
                        bottomRight: 50
                    },
                    borderSkipped: false,
                }]
            },
            options: {
                scales: {
                    y: {
                        stacked: true,
                    },
                    x: {
                        stacked: true,
                    }
                }
            }
        }
        let StackedBarData = {
            type: "scatter",
            data: {
                datasets: [{
                    label: 'data',
                    pointRadius: 4,
                    pointBackgroundColor: "#6f1ff1",
                    data: [
                        { x: 50, y: 7 },
                        { x: 60, y: 8 },
                        { x: 70, y: 8 },
                        { x: 80, y: 9 },
                        { x: 90, y: 9 },
                        { x: 100, y: 9 },
                        { x: 110, y: 10 },
                        { x: 120, y: 11 },
                        { x: 130, y: 14 },
                        { x: 140, y: 14 },
                        { x: 150, y: 15 }
                    ]
                }]
            },
            options: {
                legend: { display: false },
                scales: {
                    xAxes: [{ ticks: { min: 40, max: 160 } }],
                    yAxes: [{ ticks: { min: 6, max: 16 } }],
                }
            }
        }
        let FloatingBarsData = {
            type: "bar",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: 'Dataset 1',
                        backgroundColor: "#FF6384",
                        data: [39, 98, 50, -50, 80, -90, -30],
                    },
                    {
                        label: 'Dataset 2',
                        backgroundColor: "#36A2EB",
                        data: [-90, -65, -78, 55, -41, -81, -45],
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Chart.js Floating Bar Chart'
                    }
                }
            }
        }
        let BarChartHoverData = {
            type: 'bar',
            data: {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
                datasets: [
                    {
                        label: "Dataset #1",
                        backgroundColor: "#ff638433",
                        borderColor: '#ff6384',
                        borderWidth: 2,
                        hoverBackgroundColor: "#ff638466",
                        hoverBorderColor: "#ff6384",
                        data: [65, 59, 20, 81, 56, 55, 40],

                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        stacked: true,
                        grid: {
                            display: true,
                            color: "#ff638433"
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                        }
                    }
                }
            }
        }
        let PieChartData = {
            type: 'pie',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                    data: [2478, 5267, 734, 784, 433]
                }]
            },
            options: {
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        }
        let RadarChartData = {
            type: 'radar',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: "1950",
                        fill: true,
                        backgroundColor: "rgba(179,181,198,0.2)",
                        borderColor: "rgba(179,181,198,1)",
                        pointBorderColor: "#fff",
                        pointBackgroundColor: "rgba(179,181,198,1)",
                        data: [8.77, 55.61, 21.69, 6.62, 6.82]
                    }, {
                        label: "2050",
                        fill: true,
                        backgroundColor: "rgba(255,99,132,0.2)",
                        borderColor: "rgba(255,99,132,1)",
                        pointBorderColor: "#fff",
                        pointBackgroundColor: "rgba(255,99,132,1)",
                        pointBorderColor: "#fff",
                        data: [25.48, 54.16, 7.61, 8.06, 4.45]
                    }
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'Distribution in % of world population'
                }
            }
        }
        let PolarAreaChartData = {
            type: 'polarArea',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: "Population (millions)",
                        backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                        data: [2478, 5267, 734, 784, 433]
                    }
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        }
        let DoughnutData = {
            type: 'doughnut',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: 'My First Dataset',
                        data: [300, 100, 50, 50, 50],
                        backgroundColor: [
                            'rgb(255, 99, 132)',
                            'rgb(54, 162, 235)',
                            'rgb(255, 205, 86)',
                            "yellow",
                            "yellow",

                        ],
                        hoverOffset: 40,
                    }
                ]
            }
        }
        let DelayData = {
            labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
            datasets: [
                {
                    label: "Dataset 1",
                    data: [18, 23, 51, 32, 22, 33, 13],
                    backgroundColor: "#8a2be2"
                },
                {
                    label: 'Dataset 2',
                    data: [52, 23, 13, 32, 23, 11, 32],
                    backgroundColor: "#e22bca"
                },
                {
                    label: 'Dataset 3',
                    data: [63, 12, 33, 44, 23, 21, 32],
                    backgroundColor: "#2be27d",
                },
            ]
        }
        let DropData = {
            type: "line",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: "Dataset 1",
                        animations: {
                            y: {
                                duration: 2000,
                                delay: 500
                            }
                        },
                        data: [20, 80, 30, 20, 30, 65, 10],
                        borderColor: "#ff00ea",
                        backgroundColor: "#00fff2",
                        fill: 1,
                        tension: 0.5,
                        pointStyle: "circle",
                        borderWidth: 3,
                        pointBorderWidth: 8,

                    },
                    {
                        label: "Dataset 2",
                        data: [50, 70, 60, 10, 30, 20, 60],
                        borderColor: "#eb672a",
                        backgroundColor: "#df3bc9",
                        tension: 0.5,
                        pointStyle: "circle",
                        borderWidth: 4,
                        pointBorderWidth: 8,

                    }
                ]
            }
        }
        let LoopData = {
            type: "line",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: "Dataset 1",
                        data: [20, 80, 30, 20, 30, 65, 10],
                        borderColor: "#eb672a",
                        pointBorderWidth: 4,
                        tension: 0.4,
                    },
                    {
                        label: "Dataset 2",
                        data: [50, 70, 60, 10, 30, 20, 60],
                        borderColor: "#ff00ea",
                        pointBorderWidth: 4,
                        tension: 0.4,

                    }
                ]
            },
            options: {
                animations: {
                    radius: {
                        duration: 400,
                        easing: 'linear',
                        loop: (context) => context.active
                    }
                },
                hoverRadius: 12,
                hoverBackgroundColor: 'yellow',
                interaction: {
                    mode: 'nearest',
                    intersect: false,
                    axis: 'x'
                },
                plugins: {
                    tooltip: {
                        enabled: false
                    }
                }
            }
        }
        let ScatterData = {
            type: "scatter",
            data: {
                datasets: [{
                    label: 'data',
                    pointRadius: 4,
                    pointBackgroundColor: "#6f1ff1",
                    data: [
                        { x: 50, y: 7 },
                        { x: 60, y: 8 },
                        { x: 70, y: 8 },
                        { x: 80, y: 9 },
                        { x: 90, y: 9 },
                        { x: 100, y: 9 },
                        { x: 110, y: 10 },
                        { x: 120, y: 11 },
                        { x: 130, y: 14 },
                        { x: 140, y: 14 },
                        { x: 150, y: 15 }
                    ]
                }]
            },
            options: {
                legend: { display: false },
                scales: {
                    xAxes: [{ ticks: { min: 40, max: 160 } }],
                    yAxes: [{ ticks: { min: 6, max: 16 } }],
                }
            }
        }
        let CustomTooltipContentData = {
            labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
            datasets: [
                {
                    label: 'Dataset 1',
                    pointStyle: "circle",
                    pointRadius: 6,
                    fill: false,
                    borderColor: "#FF6485",
                    data: [-40, -15, -63, -18, -80, 8, 7],
                },
                {
                    label: 'Dataset 2',
                    fill: false,
                    pointStyle: "star",
                    pointRadius: 6,
                    borderColor: '#36A2EB',
                    data: [13, 67, 69, -16, 38, 68, 20],
                }
            ],
        }
        let ImplementationData = {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
                label: '# of Votes',
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        }
        let LineChartUpdateData = {
            type: 'line',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: "update",
                        backgroundColor: 'rgba(255, 99, 132, 1)',
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                        ],
                        data: [5, 17, 9, 12, 2],
                        lineTension: 0.2,
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        }
        let LineIndexAxisData = [
            { y: 1, x: 12 },
            { y: 3, x: 14 },
            { y: 4, x: 20 },
            { y: 6, x: 13 },
            { y: 9, x: 18 },
        ]
        let configline = {
            type: "line",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],
                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        ticks: {
                            color: 'rgba(230, 34, 77, 0.993)',
                            font: {
                                size: 16,
                                lineHeight: 1,
                                weight: 'bold',
                            }
                        },
                        beginAtZero: true,
                    },
                    x: {
                        ticks: {
                            color: 'green',
                            padding: 0,
                            font: {
                                size: 16,
                                lineHeight: 5,
                            }
                        },
                        beginAtZero: true,
                    }
                },
                maintainAspectRatio: false,
                responsive: true,
                tooltip: {
                    // titleColor
                }
            }
        }
        let configbar = {
            type: "bar",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],
                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        ticks: {
                            color: 'rgba(230, 34, 77, 0.993)',
                            font: {
                                size: 16,
                                lineHeight: 1,
                                weight: 'bold',
                            }
                        },
                        beginAtZero: true,
                    },
                    x: {
                        ticks: {
                            color: 'green',
                            padding: 0,
                            font: {
                                size: 16,
                                lineHeight: 5,
                            }
                        },
                        beginAtZero: true,
                    }
                },

                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configdoughnut = {
            type: "doughnut",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],
                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configpie = {
            type: "pie",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configradar = {
            type: "radar",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configscatter = {
            type: "scatter",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [
                            { x: 50, y: 7 },
                            { x: 60, y: 8 },
                            { x: 70, y: 8 },
                            { x: 80, y: 9 },
                            { x: 90, y: 9 },
                            { x: 100, y: 9 },
                            { x: 110, y: 10 },
                            { x: 120, y: 11 },
                            { x: 130, y: 14 },
                            { x: 140, y: 14 },
                            { x: 150, y: 15 }
                        ],

                    },
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configbubble = {
            type: "bubble",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: ['Deer Population'],
                        data: [{
                            x: 100,
                            y: 0,
                            r: 10
                        }, {
                            x: 60,
                            y: 30,
                            r: 20
                        }, {
                            x: 40,
                            y: 60,
                            r: 25
                        }, {
                            x: 80,
                            y: 80,
                            r: 50
                        }, {
                            x: 20,
                            y: 30,
                            r: 25
                        }, {
                            x: 0,
                            y: 100,
                            r: 5
                        }],
                        backgroundColor: "#FF9966"
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configpolarArea = {
            type: "polarArea",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let monthArray = [1, 2, 3, 4, 5, 6, 7];
        let config = {
            type: "line",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                plugins: {
                    tooltip: {
                        backgroundColor: '#f300b6',
                        titleColor: 'black',
                        titleFont: { weight: 'bold' },
                        padding: 20,
                        titleAlign: 'center',
                        bodyFont: {
                            // font: {
                            size: 16
                            // }
                        },
                        bodyAlign: 'center',
                        titleMarginBottom: 15,
                        bodySpacing: 7,
                        caretPadding: 5,
                        cornerRadius: 2,
                        multiKeyBackground: '#cfdd50fd',
                        boxWidth: 100,
                        displayColors: true,
                        caretSize: 30,
                        boxHeight: 20,
                        usePointStyle: true,
                        callbacks: {
                            beforeTitle: (context) => { return 'beforeTitle the title' },
                            title: (context) => { return `month ${context[0].label} month : ${monthArray[context[0].dataIndex]}` },
                            afterTitle: (context) => { return 'afterTitle the title ' },
                            beforeBody: (context) => { return 'beforeBody the title' },
                            afterBody: (context) => { return 'afterBody the title ' },
                            // beforeLabel: (context) => { return 'beforeLable the title' },
                            // afterLabel: (context) => { return 'afterLable the title ' },
                            beforeFooter: (context) => { return 'beforeFooter the title' },
                            footer: () => { return 'footer item' },
                            afterFooter: (context) => { return 'afterFooter the title ' },
                            labelPointStyle: (context) => {
                                return {
                                    pointStyle: 'circle',
                                    rotation: 10
                                }
                            },
                            labelColor: (context) => {
                                return {
                                    borderColor: '#e8e8f1',
                                    backgroundColor: '#00e1ff',
                                    borderWidth: 5,
                                    // borderDash: [2, 2],
                                    borderRadius: 10,
                                };
                            }

                        }
                    }
                },

                maintainAspectRatio: false,
                responsive: true,

                title: {
                    text: 'Dynamically change tooltip background example',
                    display: true
                },

                scales: {
                    y: {
                        ticks: {
                            color: 'green',
                            font: {
                                size: 16,
                                lineHeight: 1,
                                // weight: 'bold',
                                family: 'sans-serif',
                                backdropPadding: 10,
                            }
                        },
                        beginAtZero: true,
                    },
                    x: {
                        ticks: {
                            color: 'green',
                            padding: 0,
                            font: {
                                size: 16,
                                lineHeight: 5,
                            }
                        },
                        beginAtZero: true,
                    }
                },
            }
        }

        let filterdata = [
            {
                id: 1,
                title: "The Batman",
                genre_ids: [80, 9648, 53],
                img: "https://www.denofgeek.com/wp-content/uploads/2020/09/robert-pattinson-the-batman-warner.jpg?fit=1200%2C680",
            },
            {
                id: 2,
                title: "Uncharted",
                genre_ids: [28, 12, 10751],
                img: "https://assets-prd.ignimgs.com/2022/01/13/uncharted-poster-full-1642086040683.jpg",
            },
            {
                id: 3,
                title: "Spider-Man: No Way Home",
                genre_ids: [28, 12, 878],
                img: "https://cosmicbook.news/images/spider-man-no-way-home-poster.jpg",
            },
            {
                id: 4,
                title: "Turning Red",
                genre_ids: [16, 10751, 35, 14],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTEhMWFhUWGBkaGRgXGBcWHRgeHxoXFxsYGCAaHSggHR0lGxsfITEhJSkrLi4uHR8zODMtNygtLisBCgoKDg0OGxAQGy0lICYtLS0tLS8tLS0tLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAFBgMEBwIAAQj/xABJEAACAQIEAwUECAIHBgUFAAABAhEAAwQSITEFQVEGEyJhcTKBkdEHFCNCobHB8FKSM2Jyk6Lh8SRDU4Ky0hUWY3PDVIOjs8L/xAAaAQADAQEBAQAAAAAAAAAAAAADBAUCAQAG/8QANhEAAQMCBAMHBAIBBAMBAAAAAQACAxEhBBIxQVFx8AUTYYGRocEiMrHR4fEjFBVCUmKSwgb/2gAMAwEAAhEDEQA/AHBsBcvOW2B59Y2rjF9m3ALBs3ltTUrADaqfE+JKimTUzEYaINq7VWoMfO5wEYtpSiQbttkMGff/AKVE9wzCqzkAs0MqKijd7jMQqL5k11i+IZ3JNRcTa4uGm2gfvLzC6uhzrlVEWYMaM0aaEk7ikcHhRNNkOiuY2aWCHM0fV/BPxTnRcWiQoud2O7YkC6jrcUkGDqN4OhIkDmaI4i4AknYDWl/iPH764ReG4bDtbTKijvZa5buBs7hTzUmIzCRJ5QAf4zwq+uHLZCcoB1Bg5SDBHTTaiY7ACGRrW1vr4XAqeA58OdEsFjpJWEzUqDbattOf7Qy1jBcbKioX5Kb9m258grOCDyhoPlVlLm4IdGUwyvIZT0INDux+OXC3MRjRhrrPeyobaKpsuDDXMpCeBhBYLqI8Jn2gTu4s3Vs33TIbi3JU/dRb1xbIPUi34Z5hQaZxvZrYI6itR7oWA7RnmmDJG2PtYnxqLKbDYdrhAWT6Ubs9nLoEyPShnA+IBbkaCnu1iwRpSmEhjeaPTHaOJnhNGiyzD6TS1rh1xXmbt2zb9Yz3f/jrHFFbH9PWL+xwlr+K5dc/8ioo/wD2GseUVWyhgyhSYnmYl5FK/AAX1VqRVr6i1MiUNzlQjjXASpFt1Olur9nhdxtkM9NAfgTNDL042EC5shgtV2tqil3hd1NXtuo6lTHx2rlLFCdJROMwtdFRWzRnD4fuEN5x44+yU9SQAxHkTp8elWgUwyBmAN1hIHJR59Tz6etKnEOI3b1wgAszbD9TRI2l9zopmOxbIqxx3Olf0u+KY0k5pnQfoQfwqbhtks+eGKtB8Mb9TJAHvNDrXDL5uKjJE9Tp8RTpw3LZVA6FtWUBEZ4yDxEAAnqSelEleGt+m/LrrxUuCMvdV9udutUz9m8W4dbZw32UE953qMAd4gefwoh2lvWRbh7bMrgg5VzBf7XMf5UAs8UslFxOHmA+ViEZQ8QXtt4dWCnMOY05HW/x3j9qUUs9lGks1xLlrQfdUsBqTG2oHSRU8xOLqZfLf59RTXRUO9aLh1fGxHtZZ7jLfc3EVcpS4pKsDyBKkbaHl5Vf46ma4G5siE+uUKT74n31J24RRbS5ZQqyXMtwBSuhXMC4Ye+TRPhGFXF4Z5WL9sSpmcwAAKHWNwY9R1NMvP8AjD/I8etF7AvZHiHMdoRamnQulM2657urrJXPd1gPV50F1VFup8HhC7qg3YgD3kCuxbor2cWLwb+EO3wQxXsyHIzJG5/AE+gXfariBtOltDmsWkC5AJJYCPFyPi1NBhxu6zTlUTooaPlpr0getUyb1/ElSTLMfd/ptR7/AMryYV7bOPusSSPcNvhRqNaAHL5oZ3OJbol7CFmu/wC0KCNdSZK/2QD4vjRG6SrC2GYA6gNFvNzBQqSAQRsdxvRu/wBlLht+G3D9FI/M8qqW+yWJFq5dcsptIWyOoYEDXQDSNzI105V7O1y8GOaNzvVF+DYgXluYa8IzggyQ0aeFgeeXQjn+NZ7j8KbbvbaMysVMdQSDHwpm7O8VY3WV1lGEhhoVOwiPLSPWqHbID65ejrPvhSfxrbag0QcOzLI9oNiMw8L068EsuKjirFwVDFMArMjbr9TYriKoJpF49x4O2+nSp+0fFfAY51nePxQDgdTBM7+lJT1kdTYKj2Y1kLe8OqP3cZOxipMFcfMqjUsQN41JgUtG/JAXQnbz9aL8NxxtOjEAlGG3kZpR8NKH+1dZic1R/RWrX8PawNhsSyd9eUSWYlvEYWdSYA0k7wKWU+kq5KsSHVj7BUAHqBAke+aKYbtRavLIgyNunkRQ/Bph0vM62lBEEaCAdZIHI1UM7Bo7rnqfNfLCJxqZW1PVhsPJGO0XA7TWGuWFZP8AeG0pKgmJJyzAeOY1pDfGsSBuNAJ5AaAekU08a7VpattO5BAE6k1meMxTwDy60pif8rhlPuaDlsq3Zj3Qxuzi9bHenPWyZ7WMA+8Aacuz3FsywTWOvxBYBG+nM0y8K4gEZGXSTBH4zQshYQ4JjEubiIy00X36bcXmxOGtjZLGb3vccflbFZ6gpm+kzFF+IOOSW7Cj+6Rz/ic0t2xVF5UTCN+kef5KmtrVuxZJIAGpqG0tMnZbh4u3grezBLf2VifixVfRjQQC9waN1XaMjM3pzRHhXC7Vq1399sqRI3Bb05hTyiGPkNw3FPpAYSuGtrbXqQCfXpPx9aHdteMvib5yz3akhByI2Le/8iKHWeFjQsdIB9/T9PfToLWCjNOO5UbE4uRzy2M8zueXAeA51V2x2qx7NIvNryAX8ssUxYPFsym5cS2LkeFvYVm/rqNJ31Ea7ivdmuy9/Ez3aFFtjRnBAbWCnWdTr/V86YL3YRbwFlrpm2SLj24AMwQsEGWH8WkCBrGikszTZ1/dagfiGVLXHTcnoJD4jf724QrTAljH5/Cq/ZZFN8KxE3LZCnz0Me8V3xDhD4K/cs3nmdQR99Y8LAb8yI5EHegV+yVcAH2RIM6yBJ22g6UTIHNLQbEJTvnRyNeRcHT2T7bwwW4kyCpOYH8fdtTFbsZWzBC6k5gUMPbaILLqNCN4M77zpmmH7R3M9rvfZRcrf1vExzbbiffFaDwviGg1kHY1OnjkjpXrrrVWsNLDiA7L78t/A7/0VLxvEBjaQ22W2W1Z99PFlUSSASBO0+dGMd9XZUZRnuJJVZGpj2ddNfPy5TQ/iNxLluHQOOhqDhNi3bYFLSDQiQ5cr6STHTSli6ozcOuPlysmRCCCP49qcbq3icStxbv2d5naTczq0nw5Ydm8MBdNzptQD6M2tBGcN4yQI0kKCFCxzLNOp5Vx2g7RjB31KMxLmXXNIA2mDt6CJ1ozYwOExii6s27j6lrRC5ttSCCCQQCDE/jRquERzVAdeuum3V+KVytMoAIOQEU0pWl/byrtRUu0HZ3uwbts5rc6jmk8j110n/Wl0rWj8UyWbDIbktd8ALFRLEQBoAJ0rP2t61hjjSpV/BSmZprcj1p0CoAtXMO4SzfuTH2cCepKj8prv7BIW5mBMHMIhQRIEc65a5ZzfVmcMXYGFEj2hCzyzA/A+6jxtcXCyS7TxELsJLG1wzUy38SAacbV6KufR/wXNcfENMQqrOhmAWP/AE++acU4TeW5ay3QuGS0yNZ1IdyNLoAMF83izNJn3GvnBGVEVZACjfYeZ95q9iMfluJpKRuNdevwrck5a4kclGGEa9rRrS/C6+9p8a2Hsd5astdYfcUwTqB0J5zoJ0q24KhgwMG0rjMPEudTmttoJZSOg0KyJqzhsQLilgND1HzoZ2iukYW/l0bunyx1KkAjz1rILSynuh5Hh5JJ5LHuyUtiABEHTTlqrCJ5Qfzqtx6/3l+642LtEdJgfhFXuAXFR77BSvdoVynWHLZPgDHwNB74pp33L2CYXd5Idvp9Ln8hULgqGKsXagozUKUXTbhuNPeRs58QK7bRQrH3gWk7gmPia4wVq4ZyCdNeW+wFQYvDuGMg6Dc0MAAo5c7IKCq4tXyGmdf2KuYTHnNBNB7oiu8G/iFbcwEIUeJc1wbVMnE8IWUlCQSJ0Ma8tvOljD4i8zAC44JIGjN8+lOnDr6skE15OE2g5uCMxmRPXcgcif1paHECMFrvJO4zAnEvZI002dfbj+UPNsgST8ZNUL2NJJE6GivFmEQDSs5rUDczalcxkpY6jdFZzbA7UzcJR37sDU5hHvkD86Ucp5a05diixxGGBGgvW2PTLIZv8KmiSMrSiBh8RlLnEaCvohXa+/nx+Lbl39xR6KxRf8KiqFoVAbrOS7e0xLH1Op/GrNkV2Q3K7gmUaAeAVqytMfAcVkXGR7Ywylfi5Yj4r8BQGytSjGixiUZ/6N7fd3P7LyCfcQD7qHA7/J5FUsXRkTXGwzCvoUPsKbl63bRZbxCOo10+H5Cn3gPAGsDPdtpdzkABmYSVJIyqEJJ323E0O7CYBRfvMw8aFVE9CIkepXfpFalhrcMHBIPdugZYJQtl8ag8xArE0lX93oOio0EYjiz0qehsvmAxNy4joy9y20KTKzzhlUg+6ouD4ZGu3bLWL9sWkDLie9bIxJ1XKDEyeYJaGJgxU+Cs3EsW0uYjvblsMO+uwGYFpAbXXKNJJnc6Vzjceluy91rttEX2r7iUXTZAdbj9AOfXahsIbIQ36uur+i04FzM1cvmfz48D6IJ9IvZ23icP3mX7WypZSNzpJT38vMDzrCcNDmBAIAjTTQkkb+/3VsP0e9p7uLGKt37nei0ZS4VCFlJYQQAI2nbmelZr2iOHuYgtYZRbdUJVRHISPI6ajrR4XFjzER57D+61CVmY17BK0jlx/rT0QK65LE70Z7L37xuG3bMrBbKfdt5ydtKEWwCSB57U4/R9wp7dxcVeWLJUgSYLagzrpGnMijYlzWxOr5c0DDB5laW119leXidxTla209D/AJ8vOvYziOMa3cOHs/0YUvEllVs0MF5jwkVqaXcPcSAqsQJ7sgSJ2Ouw/rDTpNA8XwdjcDZmtK6G2z22KMhzK6MD/DKlYM+161EZMyv238z+OtFbdI9zCAaHyHXosOvXM0tcJL6zPtTI1M+m1PvYLFBV19gs2UjoSdIG2s0T7S8H7mGvEX7T6eJUU7aTkAG+zAAiouzXB8Mt0raZ2QgMA+yzGgn2hzB+U05Pi45Yb18rpTC4d8UocCPn5rp+OStcfFwY2w2b7EI0iNmgPmPkVygH50GdZJPnT12h4cn1fNB8JDNlgHJBB9eW8wAfSl5b65gLZt29JHeW7d0nyIJn3/sCgBnYAzQW3+E2/wD/AEOD7IbWXM9zzWjQLBttSRbgLnW1LoFxbgTXF71yVUqIEAFogaTy84pevd2BnAfMDEzrPPlTNxTHu6ObkB1OVgpJEjbLO6kajyilnCIrgkjQmflVZjRE296L43E9qSYqR0wGQVs0Gp43Ot7G1BSg2ThxjENdwdq7bXOuZHuLIErlYMJ2kMfcQDyox2fxiMinDYm1qJFi6wDgwSRkY6RtKmPdSX2a48MK5sXZ7okkNvknefI/h79Hi1wjB3hmCIwOoIII156gj4Ck3hrbO01BX1OGk/1DBJG69Lj+Db1UvFu1N234Ev4V72ZVFpPGzMSFKeFjlidSdKO46+kHOwAgsZI2WCYnfl8aVrlvhuAud4AhvGcqKQzAkZTlHKY30G9KF/tNdbGMb4CwSuWcwRY0UbSTM5tzPkBWTHnu0WA9eS137YZAx7hmN6CgoOO2/ueF18xl0eMLM3bj3H6EsxIUeSyfWfSg18Uc4rhCrMQpCEyhIIkSYk89KDXxXWOrdWHQRxxBsemvOt68zqqF2q1WbtVzTbVDm1TM3fqoW3YuAD/03+VD8RaxL72b38j/ACrbeIOgOS2GUbnxPP51RZT1b+ZvnST8XGx1KE9eKbZDPIwVIaDtQ/tYi3C8QT/QXf7t/lU1vhOIB/obv8j/ACra8v8AWPudvnXwjzb+dvnXP9zZ/wBT6hDb2a8GuYeh/ax7CYXFLJWy8Tsbb/nFXSb/AP8AT3f5Hj/prVAfNv5m+dfTEbt/M3zrDsZE65YfUI7IMSwUDx/6n5KyLFcMxmf7Szc20yqSN+W/SqN/hOI3Fi5/dt8q2n3t/M3zrwHm387fOtDtCMaMPqEN2BmcDmeK8aH9rEbXD8SNe4u/3b/KmDs5bvo926yOgt4fEtLKyiTYuIu4ic7LWnAD+Jj/AM7fOhHa66UwGKIY+JbVsak+1etsdz/CjCixY1srw0NPqEvLg5YonHONOB3tx8Vk1oU8dmcIb1szZwuRELTcbu2bKUDGe9Vh7UltVB0jlSRapg4Jxm9YDi2RldcrBlVwRIPssCs6bxR3EA3RWxOeyjNeZH4I64LRuEdlcL3Zbui7G4yw7yLcBGIzWnUXJzCHUGQRpIgju1HYBnaziMFHgZSbVwlQQrE5gXGYDQzO41HmQ7F41r1pi5EhyAEC21VSoMBbYVRJzEmJJiZgUa43avG1lw5ud6SIILORvPtTOjMNf4jQGyM71rRWum1L8UOePE0Mb325m1NCPz8nZdNkoVusQM3hDZlhwZKkydtCQdtW6GDpuH6uStwrcdXCEQTmGUAiegbNJ0EeYpPxk4m4LNxLzNaCpaskNcyhLaqfCASWOUuWIJM+Ve7MnFsjKi3DbtO1sK+dRbYHW2DsrRBgidq0YDmc1oNhauh00uNEQSOc1udwBcbga7/k/OqIYG1cz37aKc+GvXE727a703lQOpa1maO8zLORp8EtJytVheyJv2mbG3jcvaEG4JFtTIUogiPEoGUBQZGuulC72sazcy4i1ibVxSf6SdSdSylm1J0OberFjjl+/phUdmbTOzPlAERmIMEDTwzy2rReScoYR1z9liOEgZnPDvHw4C1q8aW0prXjtdg7fD7F5MHbbvMUxXTUIqKqk5hoDqxy7gtMAEUg4PsLjGTN3RnkM9oeXNq0ntGHs2VtS96+WVnPicljAkx5SPIUW4Bw+7lD35WBoogx5sZ/AU+yEDmUPuA4DvDoNv6681jl3sviLMm7YuWwzKoYANEkAmVkKAOZrYuEG33SosABYgcgBFEePXFXD3ZP3GHxFZxwXtIg1B12I9DrUztSAuDaX1RsNE2OoG/wnXhnBmskgXWKM0hMohNNQvqdY2GulFPq4KwxPQ7CdfSgI7VWjlIPWuf/ABwsTlBM6jkKhOa83I4fKbET3WXHE7Flc6XvtAIMProTrPIiak4fcwghVS2sbAKB+VB8dw571xndiAQBlB0gGY+NQ4fs0FbN3jTpz6U05zHNFTel7WqixwkWd61CZOJIty21sM6hl1jeAddD05jpSzgsXhMrJiLSO6kqLmUBj4iFyN7SDnoeu+tF2wJIjOwidj13+NVcX2etuJMg9Rv7q1BMGW2Qp8CyQh//ACpSu9CQSPbXbZXW7JYe7P2lyHthvCVkjUHUqZbLH4Uudq+xn1VO8wzNcVCFdCAWAIkMCsAiSBsN6P4RLlkIglggYDXWGA0M+Yovhcc4LsULAssACTGQCfiD+FOMxBJuajdTZexcPkIawCv529lj1ngl+60dy0kE+yduc6aa028B7A4hiMwa2mgK5so/w+L8q2DBAZRKxI2q0IpwuDkjBAMPUC6Sbn0c4VjbaINsQIgTOp023+FXb3YLCPq6knTxCAdNtQKaS4FUr3ERstcLwNVpmGaXZ2tFaEVpeh1HmgC9hVVXVLpKMCO7YArzjz3571mHaHsXi8MTntl1/jQFh79NK26xjHJ/yrjtFeYYdoF0yP8AdSG92XWstDHXCfjxE0X0GhBX5kvqQSCIIqoaK8XJNxyc2/3zLe+aFmis0XZxdfou1wBjqza/GhnFuG3LQ5kddT8afReAoHx/jCKpAgk0licLCxut1vB47ESSC1RwSUuKg679aI8Lu22cC40KdzpQu6ysddK4wNmwt1rmIDMoWLeWYDayzQeWkTpvU+CHM8AkU8dFbxRyRFwaSeAuegnTE9nI1t3EI6Nv7qDYTDtcfuxEyZJMRGhmlrg+Kx7PctIxuCPsfC2bcaMQYAVZ1J5DroZTg2Otw1tXzpuIOo+9BPz1piWFpc0saaHWl/6PNJQvc1jhI8VGlRQ8/Ecq8NbJmPBbVpC964DAOg2HSle5jFkx/nQ/D8YvjG/7RD4ZZkMjKSYI1VtSZjfSJ0mI+fVrfe3GtKUtMZVNgNBMDkJ26VrEQsyBzKDw1POq5g3SmQtkDjUVrSjeXpf43VtsSWMDn6/hQb6RAyYFAxM3MQp6SLdu7P43BRzC3ltsCBQH6ZMeLgwSqdlvPH9pkQH/APGfxr2Bj/yVOoB/XyvdqOc2MNAsSL+dfhZ5ZrSOyf0aYvEL3l3/AGe1EhriksfMJIMeZI8ppK7M8VbC4m3iEVXZGkK2oOhH5HetdTiGJ4pwe8bgm8L6AKgKBlLW4AE6rDNuT7NUw1prX0U90s0YbkoASBmN6VNNPfdS8D4LascOt4hGLMboLmQywrshCQPZJA15/hTVaN1LuO7vl3RtiJjwgtp/zHSoeynDUs4FcNimWNyHIXSQ3Xk36VI3EV/2jEW7qr3o7vDkx9owWFZAfbl5iJBCyJBmixxtAB63/aRxM5dI9pOa58xVpHLT3XPHLSjH8NuwBdLXVbqVNl5nyViI6ZvOqvbXArYs3rqtl77FWLhInRvs7R265B8TVziVtXxdq8M5e0pLqAxBAzABC0ICzPO4JCCfZ0Cdo7+LbBJYuYa7dbPbbvEKmFVg4W54i3eaBSQGB3nWKIXDigNYczKeHl9R9v2mS3eDY+/ZdQV7hXkwRqcpEHlAoR2pXEWsMi2Lc3mxBtLAHiUrcKsSYA0Ckk6DWlzH8ZuXcTjGOGv2TicCcPazqD9p44LlCQi+KZPQ+QpvTiRYYVXLPctQ9xsjBWIQ25BPhlsxaATEUN87WDVEjbKC0gHb2B69F1heDvbtqjNbN5kAZc2pMePJIBMmTMCgGJ4utlQMxdSJU7k+R6nUa856yaY8Rwuy73rzle7dcxueE5ciqIM7BcrGOUnnNZfhVzeKTB1UEZco5ADXLA5axQZsWYRpva+vH9inrqn+zmGYmrq6VFNK13/o+C64niruIGUnKn8PMieflUOE4BaGmUfvrRzhWD724F2A1YjkKcLBsWVgKoHU7+8mppfNiPqc6gVSd8UBy5czkk2OGqvL8Kt9yBVviF1TcJT2eXTblULN+/lU55uRWqO1xIBpRfLVjMwUDU7UZ/8ALrR7az76Bm6yEMh1H7NXrfag7FDNFi7mhzoUrMQaGLzXGKwT2zDCPPr6VHk51cucet3FKOrDoehqgj+dClDQfoNR+F1neU/yCh/K7K19w9wqZFez6a19UTWWSELu10cwfF1Oh0NXrmJAEz7qU2WrGGxIHtz6/OqMWKJsUnJg2m7fRErju+5gdBUuHsVzhLgbYg0QtW6YF7peR+X6dFJYsxS/287QLhbEEZmcEKNB79509KZyYWSYrHPpKxIvXEuKxZAChkEQ0kmAdRII386ZoWtsgYXJJiGskOtaeJArT0vyCz7HXCzFjuTP7ih5q9iBVKtM0TWKFHL9D8c45lGVd6UsTeLGWOvrUXHcQe8OtCbl8+v7/GpjnlzyXKzgomRRDKLkIm18DmNKv9n7X1i73atAAlm6Db3kmk261wmF+PIUV4PiXwrd4pLFhDidxvp6V4NYXAv0Rp5JCwiMfVstG4674PDzgredp8ZgM5HUTpv8KVh26xjZRbDs7EeGFaPURXm7ZrH356R/nVDD9r4usxtFQY8Qgk77gfpNURKwCjbDyXzrcLMamRlTxOp5rQ8XwpcRaV7gW3fyjMV2zRsRzFZ9fv5WZToykqfUGDV2720XKcmZj6EfEmlbGJcuFrmch2JJHLXlSmJEbjVtjuqXZgxEYIkH07Dh4Dw8EcW8J/Y/OlX6SLg+tWkH3MNaB/5zcv8A5XRVzD3HG/Kg3bu5PEMQB9xltf3VtLJ/FKLgxdx66ss9sPq2MeJPoKf/AEhuDQllCgliQABuSdABX6a4B2adLFpMRcLMkNlQlVBEEBogXMp2kRImK/N3A8Stq9buNMIytpB2IOxFfrlXkAjY09E2pKh46Rwa0Deqqvw+0whlzc/Fr765v4PSUkHpO/lQBHfvjc724T3rKFzHJlDlAuT2dhvE6701kxqa03I+oA0SL+8YA4nVUuFMrJmHM7/CueKcQNkJFtrhdoABURALFmLHbSNJMkabkUext/PhVbXxMSJ6HUfhVnjFi4zWii5gM0wQIkCNz615p/x1C89o74tPFDixv4m33tkKiBwQzB8xIBGgEQMp360VujDB1tN3IuMJVPAGIHNRuQPKh+Cci+qMIbWRp/ATy8qVfpOtTiLX/tj4hyQfXWgukyxmRwrf9BMRxGSVkTXUBB+T4I3x/sUl3M1q46MwhkLtkcDkwB/OR5UlNhGtsyusMDBB3BrRuxvEHvYVTckspKEncwAQT55SJPM0H+kKyA1q4N2DKfOMpX8z+FKYuBr4hNHw02pX2PJUOz8VJHOcNLe9K71HjuCOKW+FYzus5AljAH+fxqG9dZzLGf0qHvByFfe8qU55IDdlfEYDi4C5U9sxpUwqj3lWEegkLzmld3BVVqsXtqoX7oGpIHrWg1ajCsKoqzb0oPZ4hbJgOp99X7d6uObRdc0kK8proNUKNUiJJoVEuRxU4tk7VYXh7sNqu8Ow4EUdsIKoYeDNqps2LLPtCUWFy17J/UUQwXEXYZmIGvMgfgBR3EYEOKX7mCaw5gwp6LNOGNzB4LLZ2TihAzIpiMXmUJJGfTN8vOs24/aKDE4a8wIVA6NEE+yVMcjqU05TT8mFu3coGiAhiW9qQZEADSs4+kLF2zduqGLHMoLKNPCsFZ568uWtFD3UvvZT34ATTxZPua8GouQAamp2BpQ1tpY6HPMTVM1cxFUjR49FSxf3LQcTxW1f8StB5qdx86otcFLf/g17lauiOeR9/hXS2sau9m6R5o3ypd2DzGrT5LUWP7loDxUbEX9f2mDv/OuvrI60vD60d7F3+7f5VOvD8Uf9y49VPyrBwThqmGdpxP8AtujHfA19FxaDHheL/wCG38r/ACrj6li13s3Pcrn9K4MIToUQ9oBoujvegV9+s0DW3if+Bd/kf5VNcsYhAC1i7rt4GP5DT317/RP4Lv8AukI1cB5pj4Nb73EWrZ+/cQfFwv60i8VxXfYi/eG1y7cf+Z2b9aZ+zN+8uIS49m4qWlu3SzI4A7u1cujcdUFJVqm8PCYmnNv8KRjsWzEzNLDYA+5H6Cu2K/WPZXFd7g8Nc5tZtk+uQT+M1+S7Jr9J/Q9xAXeG21mWtM9s+XiLr/hYD3UaL7iEtjhWFruB/P8ASZ8Nw0K5YmfEzAdMxLa+hJoF2t4rmzYS1JJEX3GgtqRPdz/xHUjQeypzaEpmN4XHFr122wAysAhE6jIjEGdzJJ05emtfjuCB8YG+jfkD+nwrT7MORJQ0Mre906ouOx/9AR0dvyWuO1HG72H7tbFgXXfOfE+QKFyydFOYyw009asdmEy2mH9c/wDStDe17P3lnIjMe7u+ypb71noPKstdSEEcEWUB+KNdCf5S/wBmeJ373EEa+qqz5vCsgAC0wG7Ek6b1P9Jwi9ZPW2/4Mvzqt2cwN8Y+3cu2nSc/tCNMjDn607cV4FZxD23ugnu8wABgENlJDaT90bEc6BldNC9u9d/Ipt748Nio3bBu1/8AsOPFUewWHKYQEgjOxcT0gKD7ws++lv6QeJq99LKme5U54/jfKQvkQiz6XBRPtH2wW2ps4IC4/sm4INq1Gm+zuNsg0EeIjQFBNsiSSSSSWLGSxJksx5knWg4uVkcXcNN9D1xPBMdnYeSfEHFPFBUkeNfgceOmhUpf971XxOLW2MzGI61IiGKs9kOGJicW3ejMtkKVU6gsZ1PWMvx9Kmwxd68NV7FTiCIvQReMmM3c3in8fdtljrMRFGcDiVdQykEGoPpF7eYvC4wWbLCzaUkT3asGg5SWLKxOoOixpHWakwt+3dK4iwhS3fUuVIC5WV2tu0AkKCRm3601iMIxsedn93p+VNwvaL5Ze7kAFq8rVv5K/d9mgh+qWU+tcQD3QzMLVhSAIU5S9wkgRm0AnXodYYu8w8QbwJPJVdh8QI+FD+P9kXxeHKoBcy7ZD4l1LAlXKmfE2h3BkbV7DRujOZzfne/nRZxc7ZIsjHUvyrY0FedPyj/COBcK4nhe8s4YWD/VCW7ibw0oSCDEiZB6Up4Ww9q7csXDme02UnbMN1b3qQY86s9g8Le4Wl5Wssbt3IJuHKFVM0aAEkyx0kCANauMmZ2uOZdzLECOQAA6AAAVvHTRPaAPuQ+zIcRC8l/2kca3Ullat2RBqurAV0cQKl5VScC5G8PigKK4PEg0ofWKt4bG5TrrRI5SwpCbCVFk72zXrtkMINC+HY/P/qKKo1V4pQ8WUaRjo3X1Qy/YuEZFbLOhPOPKsf8ApDvWBeNrD6hSS7AyC8KrAeQC/EtWz8atObT93o2UisD4zYSy7Agu3vVfzk/4detdfayrdmEGrj6DjxPLav8ABCLaEMzjwry2zN91f1MawDzioTg0fxW3RQd1d1UqeYGbcdD08wa5xt9m3O2wEAD0A0HuoeaMzRCxQJdWq/VuJt2lBZhAHUt86S8dfzuSCQOQzMNPjRntZiPAqzq248qUu/E1P7RxLq92Ci9lYJnd97S58Nlejzb+ZvnXdh1BGdmidTmb51SRwddPwrsLO5qWHuB1Pqf2qhhadR7I5jeN2cuSxbP9olhHnvJNUnuaSCQeuZvnVGANqnvXfAKO/FPkNXH0sEu3BxRUDG863J5orY4vZZMt5GDR7SkxPXeR6UJe50LfzN864VQaicRz92lYkxMjwMx06vxRI8JFGTlFK7beSr9ob+TA4x5J+xK+0T/SPbs8z0c/CsWStU7dYnLw67v9pesp7ouXT+NsVla1awFf9OCd6/mnwouOoMU4Dag9q/Ks2jTF2d49iMI+fD3GtkxmiCGA5MpBB58tJMUuW6u2DRXGlwmsOA4ZXCoWp9m+3t57x+sKG7xgcygqVIVVEAcvCPOa01+NFVi5Zd5G9vJBHmGZYPpI/Kvz3wXB3Lz5bYlgC2m+munn0rXOx2Iz2ArvmI2mJ/MmsxSuqQV3tDAQ92HMFKagItw7jnchibFxsxnKptll3jNLhZiJgnXrvXwduszZLeEu5v8A1HtKPeUZ/wAqgxumgqnwLBDOzRz3rrZXj6Qk3YSFwMj6+vkjlu5fuuty5kt5VYKtslyCxUlizKAfZEDKOczOnGN4cboIv3rl1T9xiqp0IZbYUOPJ8wr5jeLWbI+0cLtv5kKPxNVeIcVUCQQfQzXJ5S1pJKBFhszgGhVuIWUUQABG0aUCuKPKosVxEsd9Kp3MaBUYipX0cMLmChKtMK4wbvZum7ZyywAZTMGNjpsaoXOICuTjtgo8RIA9TpXmlzTmajvia9uV2iKY7g78SuBry21CmSVGbXTbN94gDaKpdtc2GVLNm03dW1EEAnOeUkDl+ZJp34baFtFUchqep5mrveg71ZiYYxV2p15+FF85LI17voFGiw6PQ2WPcOxl65bMIUuH2QQTqPzrSOxHDcUoW5iTDRG4lhyzAVa4uiDI4AlWE+hka+80VwuLEVrOsuJy2V/EWEuLldQwPWkntHwo4chlko208j0NOlq8KHdo8IMRaNqSJI1WJEdJBoM0Qlb48V7B4h0EgB+3cLOMXxNUEsfPrp1gUMbjylohh0kRPpNaPw7s3ZtWWUqD4WzMdS2h1JrG+3GIS21u2hGYEExyG00u3ANNiblUndrZTUNAA9T1yTbhMZm50Vs3JFKXBS2UE86YbDR6VNe3K6isvbmaHI/wjGFWjlTjhrsis9tOZB/EU48Kvyo1prCuIdRQe0YR9wRkNWRfSdw/urpuLbBnWSC2/kTl/D51qqvSZ9J9s9wtxWK5SQSCQNeTQY+P5xVPUJHCuLJOaxTE4m4uhAU/+2in/pqmcc/9X+RP+2rbODmRyBOqtqQG57SYYb+YXpVY8Pu/dRmHVIcfFTHuorNEbEUrdbrd4bevMHY77DoK7udl3AJB19NP1pqwyADzqrxbiPdoaVxGFiawufdch7Qnc8MjAASHiMO6mCIPlRnsr2et4kG9iRnQEqlqSFMaM1wD2jMgKdNJ1nQJicaWYmZmi/ZbjPcIbbDw5iwI5SZI+OvvpTBCOOWsnC1eKrdpxYh+GpHrUVpY0396cwrXEOGcOufWEweS3fwwm4lsFFMCSrD2W2iRqpIneCI+rtc7u2pguyqD0kgT7hrTKlrCJ32LyLaF0Zbl0DxXJ+6o8zz028tIE47w+U8JtwQVeQYPItB2+NN4jDd+9rxSm/iK7eVfA1tVSsHiX4eNzCHGmlb0NL78aW52B1l4bwbhLvcwyhL16z/SF8zOCeeYxBnkh0kbaUuce4UcLeFtGZrbDMmY5mWNGQncgaEE6667SWnE2rGFuviBZUXLo8V1ROcaHfz0J6wKVeNY83rwubBFKqPUgknzMD4VrGuidF3ZAzbU2/ii12VHiP8AUd4C4sIuXbmnmD9XC9rpQ+kq8RhcMke3evOf+RLSr+NxvhWdpTt9KGIJuYVP4bBf3vdu/wD8otJSUeBuWFo8B+0vOc2IkP8A5H2t8Ka3VuzVW3Vu1XHp3Dpn7GcY+q4lHPsmVb+yefuIB91abie0WBssxGTOYLFRB1BgmKyHhLAXBmGYayPd+zVPEXTcukkiTv6A6CBpFci3RMcQ0tO5F/ELbbXHbOInumDEcudEL2JXD4drjchMDqdhWNYa89hkdH1IJB9DBVgPcfQimjj3be1dwndqYvNGZY00OoH511ut0q8DKA3TdK/GeI3MS5JaYIO8elW8BxJkhJMHQg6QRp8aVxinDkxMnTkeXU9avWsazNmczmby33rMjAW0WoZnZ83Xgm23fnrQrtBxDulkk1cw1zXqRNLPbQllU8gZ/SkYmB0gadFUxUjo4HPbqpcLjL11cygR50bTB4lClwANDKeY50m9m+MG0wQqWDHQDeTWocLxxIyG222nsnT40+7DsbsosWOmePv/AAme1xEFZH+nlXm4kBrQ2VZQSMp5g8qqWkBJGkAwCZ10mvOqVhtBsr/EuK50yqM35dd6+4LiN0gQp+P+VV8KiqSrPAHoNKnscVwtpj4s3MRLf5VggDVFGZ1miqOcKxD3J8pkL4jp6Vd4VjFdZnxcwdx5UvntqoJyW2I84FUm7VPnLpZQE6ydT+AFY76Ju6MMDiZP+HwnXEYHvLdxXcw06L4Y5iSNT+tYx2l4Kl26qhQCreIgdDt5zTPi+PYm5M3MoPJBH47/AI1Ss2dZoT8X/wBBfim4OyCLzEU4DrrwUeGw8aDar1vTWuQvIVLMfrU0qu91VLa3pq4OfDSvhxJFNeBTKtFhH1KXjz9ICvI9JP0rcSyWFtgwXJnzAj46kU3PcA1rIPpN4mLuJyqdEAH51SYVNijq+qR7tQEVNcqGmW6Ls1yv1DexeWkrtXxWWidKgxfH2djuDy0pe4i4ZoLyesGKQxMve0A0T3Z2BML+8frRWk4gvPb0NFuGICyl9EJBPmPL3UsYG34pceBd/wCseQ/Wpr3FyWhTAj/T9+VCDai6rPdWwstJ42+GxdruXJC/dKnKVIBGnLY0nYfslhlufaX7jIkFQCAT5MfdQfD8QaQcxgedT8R4kuTOPbWOe486ebic33AVUc9miMfQ8gdde6d8dx221vuQoyAADX2Y2+FLmM0BZTMbrzjqKUH4ozSQ3pV3hnEWLIgMkkKPMkwI/CgS1eauTmGjjgFGG1an5QP6RbxOOZT9y1h09CLNtmH87NQLC3MniBOaDliRl5TPWNo9eVXu2OI7zH4t5kHEXY/sh2VR7lAFCEqk61l8ux2f6uN/W6IW8Y3RP7u3/wBtW0xbfw2x/wDbt/8AbQ62J0FFQ/d+FTD/AHmG4P8ACp5AcyNzO4igPVSADgr2Ge6CCRlG/wB1AfymhOOtkMSDrMiOlXMMhY6b7knl1JJq9xHhwa2pXUx0OvlqAaxG69Ezi4Q6MHcIDYxJJkkn00/0qLHtqCvqDP71rq54ZBH4xVe64IjnRwLqS40aQrNoz56fOat4f8dPXeheHOgH791HeFcOuMQXARRrroT6DeuPFESIlyJ2L0HQ+tdY7CrcUg866XD2gJJYTzrt7JGqnMPLepzmEGoVtjwW5TdLWF4FctXlceJQT6jQ7injhuPKtJBiAOXU0Lt4pdKs276/v1ojsTIdaJdvZmHH2kjwqPkFHH4wYMW510zEenKedD3xNwtOeM38I93OqgviK7+sCBrtNBdNKd01Hg8M06V53/hdm2W8TST1Yk/nUq2f0qMYqDFfTi138tfKliHHVPsLWijbKXJU6gaH99KrDEjrXNzGrHUbVzKVsvCIJHxrsPEUJOOA2/fKo/8AxLc9N/30ruR3BDL211RsvXlu7Degh4hMQdxVrC49EMuQAeteETjYLD5GNbUlNfDsL948qYrFwACkq1xuCI/1FWrvGtNDBPKitpGpssEk5qpu2HFLmRrVhGLmJIB0G8g/hWU8S4TfXxMrGfIn/Wn58e2ssdfOql7iLbE6VtmK8EUYFzW0BWa3LLa6HSq2U9DWh4h0IOa2reoqlkw//BT4U0MW0bFKSYCQ3BCC4zjLsx1PuqquIk+LOf31r1eouRosud64mpO6ONjStpbY33PvnX4UJxF+Odfa9QmtFUy+QgEri3jGGgO9T4jEfYvO/h19+lfK9W8ozBDfI7unGugP4QtMSw56Uf7FXAcZhwTIF1XPojd434Ka+16jBoqp8kr2sN9kotcLEs2pOp9Tqa+pXyvUUqfHsieFORc/3jovl/E3rrA9SdxX21XyvUB6rYZG8Db8KjkZZj5AlQPdBPvHSp+KcTWVJJgHQLHLzI0r7XqywLeIkIb6/lBrwtXW1DrPOZ/SqPEeGvb1jMvUD842r1eowsaKeWh8ZcdVb4Fgx/SMNvZ/U0Uv4odT8flpyr7Xqy65RoxkjsoBimIidf3oKuYK8dzv6T+9K9XqwQKI8TyXKHjEqQ40B39aqYfG9a9XqCWghMl5a+gVlMb510cTX2vUItC22RxXTY471GcWeu9er1eDAiZyufrDaxXxb5Ner1eoF2p4qQM1cviEGky20L4jXq9W4mB9a7XQMXM6LLl3IHqRp4rq1autAP2Y/qjM3yFEMFg1UzqW/iJk/E16vUu6QuHAeHVfUp2PDtY4VqTxOvlsPIBXJAr62KA3Pxr1eoFE0CVC2L0qhiMZrzFfa9W42iqy8qA4xh/lXBxNer1HDAgSPK//2Q==",
            },
            {
                id: 5,
                title: "Sonic the Hedgehog 2",
                genre_ids: [28, 878, 35, 10751],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFRYZGBgYGhgYGhgaGhgZGBoYGBgZGRgYGBgcIS4lHB4rHxkYJjgnKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHzQrJSw0NDY0NDQxNDQ0NDQ0NDQxNjE0NDQ0NDQ0NDE0NDQ0NjQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAADAQIEBQYABwj/xAA7EAACAQIEBAQEBAUEAgMBAAABAhEAAwQSITEFQVFhBiJxgRMykaFCUrHBBxTR4fAjYnKSgsIWQ/EV/8QAGQEAAgMBAAAAAAAAAAAAAAAAAgQAAQMF/8QAKxEAAgIBBAECBQQDAAAAAAAAAAECEQMEEiExQSJRE2FxgfAykaGxBRTR/9oADAMBAAIRAxEAPwDyEClArhS1ZBpFdFPpDVEEIpQtKaUVChAKULXKK6ahAttcpkfQ7HtRLgynTY0DNRYJQHppWkFacQXw7Fc0LOZpc+lMmgjFqRrKSaJwxWYAHQga6ZgfagF+5EbDXbselBXbT704rP6+nWmt7fYvtSGlqeraQdp+lILRieXX+tLbGmtCm7LdEnMQq8xr9JijYO5mYT3j9qBdQhdeVLhregM7kimoykpIwkk0yfYYhRP+4n7/ANaKmGmWmNROmwjUDrTAAsTr2H2WadbcnUsd4AE7nU+2optLpC7vtAsYNJAMHr+lVl5NdauCp1LTEyO59BtTMPg1JJbQD7dB3NSeLcFDIorkrFw/ln/N+VJewugkR19KvjhtRpCnYenbqasU4b8QDKJECJ6DT3M/rWU9KnHguOppmGa0Rzp9h60vEPDpWdDoJMameQ7Hb2rNPbKMQQRGmxj261zMmCUWPQyxkuCx4SCSYE+uw1r0kWpRWkkKsBQYU9SevpXnPBrckdyBXp7aIqZfKOWs/bnXZwKoI5OqdyYFwuVTdcqsSqx8S4O4A8qe+tVvEsEl1ILIw2BEqyHlmBAI9RIqybDoxBJtoOYJYMe+QAtHehY23bWMjrc/MFlSPYgT9aPhun/XAlByjyjyzF4coxDaMuhFRwa2Pi7hDOov2hnVR/qFR5lA/E67gd9qx62zXF1OPZNne0+VTgmMFOApMtERCTS5szppCulGaz0oTHlVEQ0LTpFKgrvh1CNoCKUUq0lWWdSRTgKSoQ4iuFKadyqEG0lK1IKhBKNZuQeo5ihGuFFF07RTVqglxRy50yDU3BpnXKY0Mjr3jtpQ8RbUAR7/ANBW7ja3GalztIwpwpAKVVM6VSCYexcAENz0nvTAYNcToQadZUHQif2rTnhIDjkkYm5KD1oOHchdO/1Jrry5RB7GlwfzVqm3NAUlEmW7hLDqJ9JOkmjI8SI3OpHrsO1QlueYnpoPbn60VLh5j+tOY5K+TCUSVeumOmnL/N6l4Oy0a+VTtpLN0jqaBhbWY+YaDXqe2lWKPlAYEyp0jcTIOnpW9+WLSkl6UK0wNGKg+Yx5jHIDlV5gsQjr8mXKB5ZMgKdu9QEGmjHf1FE+KVZQQTOgK7eh7VHJGaZcEloKQBJ3gt2mqnifDEiWEESZMGTzB6VItXEBUhhpy5jqCOvSpFwggOBnnNznQbyedC0vIe5+CL4W4MFYXCJgkjprsRV7jEBeeUajWdfen8GeUJmRyMFRE7Cdag8RdpHwwepbXf8ALtoaqPMgMkvTYS+qR5rRdohSWYKP+KrqzepgVW3VaSIBEbRGvQ/1oxxT7NkkakFoMb7SP71ExF0gk7oSDl5RygzIIrRR2sW3JkO9iLlsZ7bMrLLIYBKkfhbkykSCDoQax+IvB3uMqLbDHNkScik7hZ1AmdOW1ariF3yk7wGH9jWMtnU1zf8AIJcM6mhb2tAyacu9Jctmn27ZIJrlM6HgUmhus608JT4qyrAhTyrpNFtgAzQnbWoX2MWmU8CkAqwjlFdGlLNOQaVCrGrSkUtGtJM1RLIxrlp/w9TXRVksGwpQtPIp2WoRsl8KIzMDsVP2oN/en4BgHE7Hy/Wm4wwzTyMU5ipwoXaqRHNdS2UZ/lUnvTnQqYIIPQ1m68GtMRRNEw9zKw6GhrvNNdZIo4yrkFq+AuLbzUzDPBkUK5POnI1aRn6myOPpom8PiQzHaprkaxoOnOq2x+9S0knae9MQl6Raa5ssbRiIj6fWaObuVsxEj2gdzUdXVV8wBOw3J22FSsLw+4+raSNh09aPLmUVyZQwubBvxFlGYMIJAzZtI6Mv7io9vjxUkbiTB0BHYETP0q4/+Jq2rJJPc8/eqXjHhg2wWSRH4SZn0NKPVSvoajp4pUWWHxmcggDNEBpgn/aY0JnrVxhEUl5jMpGZZIWdII/KxiOhrz/CX2Ug+n27c69H4IwvIGESBDcj2k8wNYmnMc9yFMuPay64OxCtoZ1DSQRI/eOfah3LLBuRUkQQTqD1H71LwdjK2UabttAnmT3opw2aCGFsSYDGCw2BC7ntRqai7YjqZNRqPY3B4dlsXmV1ny5QQsAz8snTUaVU4y3Np2u2PguoBZ0CqHUnYJIV/UaiicU8TWUIsaFV0YOqqWb8xzLA7DSs14g4rYNsLhme0GYC7h2zFWMyty0ZZV1GsEb0Fyvc127+xNPhk19v3IHiHIls5LyXQ0L5QysNJkqe2kg1l7CzUvilzM0ch+vOo2HQg1ztZk3Sr2OxpobYi4oxApEOUetDvXMzU/EDYDpSdDI13g12aQKEWmj4cVOimCJO1Ny0642s12c1ZaGGupKWrYQ5RSrTQaSagI4Cio0UGaeTpVEYQvrTAtMmiI2lVRKo5hXLXZqYHqyBWeB3omPIaHH41n/yGh/SobNNScOhdGUbp5wO2zD9K3wum17gNeSfwVZEdKt8Vw9biwdDybof6VS8EeDFam1Ua2hvlmKv2WRyjCGXf+o7UxlrX8V4X8VcwgMiO0nmFIlfoayNxevrWri0k/cyUk20vAK/TVWlflTQariwvBLsCYqytgAa6n9KrLNWGPw1y3YS4RC3c4U84QDMY75hBpnHJRi2xecd0kvct/DllbhZvmKuF7QVPmHuI963eGwIUDasn4Jsgs5X5V+Cs7a/CLH18xNbVX19KwzSckn8g8SUW4r3JKWx0qu47YU2m05TU9Xqm8SY4JZcnofqdqzb4o2rk85s4SR3Df2it54ftjJqF00AUb7kg9dayHD0YgSJJ36TW54Th8qjUCYgdOpHaurGKjFfRHMnNykye+KCAMZE6A7kadeWs0TheHtMk3gVuO4ylxmLAxIg7jv6VV8beCOYjtBHOB1pOD8QtZ8t9XJLKy3gSWWD5RB5TofWo4twdX9uxTLG5q6r5mQ/iDmXFMjZiFkKz/OysZ8zfiWQY9TFUlniKqrKEBlCoZtcskEsNNSNQPWvRv4t4NHw9m8oLFXK5wdVV5YIwOsEgR0gjnXlQQbUhkzzStccUdXFCLgkGUKR3p4t6moxWDUuy0mufJt8jCVERLJza06ZNFxIgzQLSmarwHfBxTc0wPBo+eAaGADURX1BXDrNIDTntwKeloxRJ8BIjzTjSxpShasobXU5q4VCChaVxpSK1OZqogGnqdKRhrXLVkFFNpxWuuLFWQZVt4fsBjddmyi3bzRzZmdEVR/2J/8AGqxUqZwrDs11FVczFvKO8T+k1rh5kgMjVMaJS4QBqDt2rXYG6HQMD61R8WQZlcD5hMxTcK7LqpjtyNFlklJpoKMXKKaNtwa4vxEVz5HJRjpoHUr9JIrOcK4C5xIwN5GAW47NcAiLQQ7EiIJVSD3NMs8SZSCUBjvINXGL8bMyFGEZhlkfNE/KW3IrSGSMkk30K5ceWEm4K7/j5mM4zw4WbhUEsBMMYE6xyqBFWXEuIC5oV0EmaDwrhd3EPltW3frlGg9WOg9zQOcWxmMJKKsdwvDFnGb5Z9ielenYzBfzfDzhrZX4qZWUNpKgiVU+wqjv8ACIttmCupDlVMhdIAZuZ9KkYIOhGXcfi3/Wq/2Ip0+ismmlKnF00S+F8IbCYdLba3Wc3Xy6hQFyqs9Y1qwtXD2E9T+wquc3GPmZm7sSY9RRbVuKxyZ91KKqjTFptibk7b5ZdqimIdj1hQAD0kmftUfifhlMQgUuZBzA+xEEdNd6ZhnI/wA/fnVxg7ncT+tZrJJO7NpQjXRnE8Kta824EksOXfvViigCdCNPf/P3rR/OrA6giP8A8FZviF5baOWmFBA7nUax611dPneVNPs5eowxx8ozvEcUruyqfMN1OjD/AIyINDw2UZWMMqmSBowHQEag/beqq1fl/PLKNFbmOYhxvVhhWCtqCytoevsetdLGlRy83DLC5irl1brqA1wKWey2qX7AHmt5fzAaiNRuK8yxDKXYoCqkkqpMlQToCecda9Eu22suCh865XtkfjXdY7kSCOsiqH+InCFtYhbtkf6OJQXkA0AYgZ1jlqwaOWeudroRVNdMe0EuHEyyvJ1qRh3hqihaVXiuU0dJok41wajhzTc06101KLSCK2Y0htkGmJoRR2fSqaopoI2sCpPxBUC2ZNSEXSqaInRDApwprNTlajLEcVwWlO9KpmoSxCtNJijqtNuJUsqwBNdSkUlWGPUTT3Wa6zXFtapgsQ6CrLw3xBLN8uxj/SvqrROV3tOqNHqQPeqt2ocTIrSHDKceDUYqyfhhWBDIcpB3AIBFVqaGrhuKNiHu3GUDMyyF3VSsKSeYXKo96r7tgqYj/OVMajE36l0wcE+Nr7QrkxpUS+hCs28Cano200T4YIjkaQTobfJncLc80v5q2HBfFr2RAgoNAOmv3FZq/wAHcE5CCvQmCO3epfDOHiVzrlgySTmLdABsBVykmgYp2ehWL63FzHUtrPMnvUkYUcqqcNiEUQIqU3GEQSzQP67UCQcmWC4adhqNedR3WN+WlUOJ8bWk0Ac94qTY4ubnzAawZjTT7ircSky2S5zFWOCv68qztnERzq2wl4GIiT6fWoo2XZejEhVY65VBM/p96868R8WZiFS4DEk6w2/mUqeURzp3irxUCvwbRYBTJYECSNBtyrHm9nbMxkncnr3rq6THtXzZz9Q90uOkXGEYxI1B1j0O9XljCscoGgYMV/3RJgd9D9Kz3D4zQTv+GdPbvV1/NOtkgyfh3Ve2w/Ax0ZW6KwAI/wBynrXVjcUqOTlhulV0SMVccLbYnQBgvUQ3mH/bX3rNcbvP8jOzossgP4Swlo59umlabj7Ei06x8O7ndY5O2QXV9AQpH/Ksbxxj8TU8h+lKaz1Yrrya6NNT+qK2eVCNKTrSCuNR2EKtIKVa5qlBHTSs1JypVNVRBVY0W2TFBoiExVNEGxTSKfNJFEgbEmlRqSKncL4NexDZbNtnI1IUcu9arFJ9IBySVtg0NMNzWivhmUlSpBXQjpGhoT25NSWGUeGgYyT8gmpsUW5aK0zLWbjRruFtNE01mpStJlPShfBFyNNcpp2Q9K7IelRMI2/8PLKsMW7AMLVtXIOohQ7gf9kUVX4MG5b826lVVjzzAkK3/UxUDgXE3sfHVVlcRZey/YN8rjuD+9W3h0J5rV9sis1i9mM6raLMygjmyMwHcCutpfVjlfPQnljtla4bIbJHrTwamYm+2IuXHVIJVrhQAALlHmC/7comPWq8X1OgYT0Oh+nOl9TopJbkjfDqE+JA8RilTcmegBNB/wD6C9T9Kl4lSpyuhU6SGEHXUSDQfL+UVzpRcXTQ0pRkrTG28S7GEViT0BqwteGb9wTduJbHVmLsB2UVFTEMvy+X0p3x3O7Gpz4L9PklXvDeGUQbr3H6wFUeiij4a2EIEyBzqAr5dWIHSTFAxHG0UQgLn6D170axt9gOaXRpFxCqMx0A67VRcW8SyCliRm0Z9tOYUfvVMxu3z52gdNlHtUleAMfkYMem1OYdPLtIXyaiKdN0Vgc86mYGwzsFUSx2G09h3oF/DMjZWUqe9LbUkiN+UbzyjvT+JOL5MpU1wXh4e2RmWZW2boB0bIjZLoI/MrTp+XWpfA+JnMXdc6KoXEJ+eyxClgPzKzKQeoFJgfECuEe8QMRhszI50XE28uV8PejZymivzAg6waz2Ax5tXMyCR5lyt+JGBBVo3lT9at5m7jJAPDxfk9IxCWzbtYRmVmWGtOv40b4uRzH5k+Af/E9KxPiDDR8Nvz2830d0/wDWr3B8PcYe1ixdBKNkS224VSWAB/EAWPpNZ3iuIJYKToi5R6Elj92NBlTjhfPn+ReHOa0UrCkWpN4A0A265B0kJXRShKdlokRg6ci07JTlIFDJF3wORNK5BpRF2pIFAy10CinqmoHWmK1FWtMdblYM+uDfWvDuDwltWxme5ccBvhIYCKdQWbrHKouJ8UrbC28BbaymYM7TNx2nRSQPl20q54RjVxWBufGXM2HQZX/FExBPMUHw/wCGHtr/ADV5cuhNlDvLCA7jlA2FdhRgo8939n7Ujkb3y5eBcdxq+oDBLVlm8zIltWZmOpLswOvasdx3Hi46uLCIwHnyeVXP5imyn0qy4xxJ1J5kzVB/O5tHEH7VlqZRgqj2b6OEpPc+gV7EBgDB9OlCtMSdhVmMGpGnOnYDhrO4RAWJPLpzJpbDFZHyN5pKCshugyzGvShMu0VLxqZHYdDUVBrSuojtm4m2GW6KkERNY5UaxbBJ00FDA5felLToNhSzGESMORqSPSrJsQufDi8oVFOVnB1Np2BhumQsxHYjpVZbOubkOVTrtkXF827QAOn9qf0OZrIoe4vqMacXJ+P6NDhOEvZey4yK1psR8VnMIUVygzEawytp1zCsBxW4q3f9J8yoRDwRJGxAO1W3HuLuYtZywVUUn82RQqz1gAD2rNhZaKc1OdxVXz5+wnpoNtyfXhfINiuIXXdnZ2Z21ZmMk/WiWsY/OD7GlTCczU61hlGtcyWRN2x+MGlSAfzTbwKDcxT/AJo9NKsxaXek/kwwkiq+JH2L+HL3KJzm3Jb11qRZsc6vbPDk/L/Wadf4dA9eVNYJQfLMMsZJcFZbQ78qm4a9lO5pqplPUcxQ8SsCdY+9dOMlGNxOfNbntZp7mFXFWGGmdfMrb7brWMFtkaRoVIM9CNQftWh8PYzK0zqD7H2qX4lwSLZuOgE3nslQOWUXTc05aslE3a3IrFPbLY2Ya7qZ6611pefSPvUjD4bPn1ChEZjPaAFA5sSQAO/am4e2TMbyKxa5sebpF5gEIQMTp5pHQLGvvmqDi8Oz32t21LsWIULqTB09qkY2VVbamWaCY5DkP86Vs/B/D7VpZVg7sPM//qvQVjqc25bTDBjuTmO4F/D+zlnFZ3c7qjFVXtI1Y967jH8LgVL4K4WI/wDpuRm75bg3PYj3rUYniSWkLsdtl5sTsBVlwm6boVo13A2ge1IqLfKG20uGfPl+0yOyOpR1OVkYQykciOVDK17t4q8KYfHEM5Nq+oyi8gBzAbC4v4gOu9eR+JPC2JwRm8ma2TC3k81tp2BO6nsfvVN12SvYpT0pjCK4NTSazbthJEoUFzrRlOlR2qBCCigmmCioBInaftRQVySBl0emfw5v27lpsPGVmKMT+cIwLJ7ia9K4wgKGY9K8f/hsiNjkkGAGKQY8wGk/evUfF98LaLD5uR50/lT+Ml+fnBypxSi/qeXeJcMufQjpEisxiMMJq2xCF2Jbeq+4Cpg6j7isc0t2RtD+CLjjSZZeH8MjMPiN5JAf8yg8x1r1TBYbBYO01y1BLAiSZYyNu1eO4S/lbQ6MINWzcVIUAmY5fpTscUMkU7r3Xuc7NLKptR5Xz8FNx3W6xAgHUVCRTW7+MsolxFcsAxkfKQJj0ihcV4dZfDfFtIEdScwG+UHzDvA1rHVaWUm5oY02rhCKg/pZispFESwYmiOtWLqMgrjtNHXiQAal4HES0dFb2gVGa1qANZ0qT8DJZuPMH5R7bgU1pMLnK145F9TlUI0/PH7mcu6knua6wkOPalAnX7Ua+uVkPUEfvV55WTFEsVUDcCpFmzO1CtW51irLDW4PTXfkJ2pJsZoYmG2nT/OdT8Nw/OZOwaCB0ABn711tCHmO2uxPT20PvUixq5ksFLhXMbFvJHodPpVItjbmFyscusGDpyO1SHsyszGsafvRr2FZHIBlIENpBWNz2kUiPMqfmiTGs9COoNFFtMhneJ2CrSQI+k+kaVVcQgKdZA584rVY2yHSJmAY9u1ZTHAZT6V1sE3LEzm54VkTIuGxGU+/t616FwPEJethXVWnTKeR2Bry+2TV5w7FFYIYg8/2NMYMra2i+oxJ8gOK4BkuvbaA6N7HmCPUQadwZAGzPOURPrOlba7gLOKVb1wsjoPOyKGJA2JWRMRUa/4Sa6pbDX0vjcqvlb3U0TVN2wfjrakYu7cYuXnXNI9J0HpFa7ws6M4ZnZV18o0kz16VU4Pw3de78JiEic7MD5Y5RzNbTB+DHtqPhXVux+B1CEifwMCRPYx60lODT9Q5CcWrj0Xl7w7hsQFZs6ONVdXMj1UyCKuuGYV7CsGggLIYaaDeRy0qBwtz8pBBGhVhDDsRWlsbVU1sVLyLTyqbryVDvOoO/MbVxyXEa1dUNbcFXUiQQf3G4NTcVhUX5QADrAEb71T33IYAdRQzcZRtG+HclTZ4d4h4S2FxV3DsZ+G8Kx/Eh1Rj3KkT3mqxlrQ+NccL+OvuuwYWwevwxkJ+oNUDbUsNBEOlDmnINKZNUQaKKpoVPU1RZa8C4o2HvLeXdTMdRzFevcd4itzCpeBhXhcpEkEiSJrw9WrRcL4uWtNZZpBg5Z/EuzKOsaU5gyq1u8df8EtRp93MfuTWto5ME+xioeM4dGquffWuW+FMzSvipoJTubYxGNQpEO3b0KsNQaNhAM4keVfMekj5R9aiu+s0Sy0Anqf0p740dqE3hnbXuWaYsm4WOsAge9HwXEgqjNqudiwOxXmPpVIjfMaBjXy2z6fc0cdVyBLRpqifx9bdplewQ9i5JQz5kI+a23cT7iKiLxdGAVgVj3qgJ5culJNYzhhnVoehcY1dmy4ZjrS3UcsCoOvadJineNMfbuKDaEIWOXSM2WJYjudaxk0QOcsEmN46VajixRbg3bVcmc4OTTb6dnI8aVa4vD+SRukN3idftNVE6ir5Lvk16frXOzjOIk8Puh1Enly1018o77VZ2nB02nnMKJ3J66VmcFc+G5U9dD2Pyn9qu3eF36GRG/frpJpVjBZJicx1grmYaaCSB+wipWFulUYNJJBceuw+mlUlm5IyEDYk6dBI+8VNRGiAdCpC9gNR6zVEL43wQQ22UAdiATEbSTP0qHcw5jOvmCkwRAjUiD09KgtimgkiVYFT1DQNe3P61OS95YOzj5hEZx1HLYH61CCXCCrGBm7dRuGHWsXxjZo6+9a/GMMpcgoWhWXoy7MD/m9ZLFLmYKNZaD+5rp6R+loS1PaZAvYFkCFtM65h6Utg9N/7/wB6vfFqZUtCN80R00gVnEYqfSmKUJcGCuUbZqeD8Ua0wPTkToadjrWRxfwzQreYoD5rbdP+PSsw+KI2JFXXg6LmKto/ysdaaU4PyLSxOKcvHsei+FHuY2Df0a3zywWB5see1bJOGFTIqVhMNbTRECxpp261M/mANGgE7d/SublzuUvSqXsFghSduufHRFbAhsrH5l59R0NSQIGoA95pweD2jflVbjuIKAROutYpSk68G7UY9dsgca4oq6Zh0rO8a4mLWEu358yqQnd3hUH1afaqPxDcc3Qi/iNVf8RLxSzhcPOjZrrDmcvlWe05jR5HFKkbYotLkw4+vfme5ob0+aGxpc2HqdKHT12pk1ChJpQa6uoQhwalDdK6uqyE6xj+T69xv7ipiXVb5SDXV1WiMayTRCIArq6tNzsE4rpFQeJAsVUbsR+sCfeurqb0cFOfJnk4LXC+B8Qfi/EUrkts6ncMR8sHmDWbxmEa2YIrq6uhjxQyY5NqqoSw55zybX0RhRFrq6kXFDjEarjBrKCZn966upTPFUa4v1DsbZzAMB5l+45j96bg75I+bb9OtdXUn4GCyttMLpMiOsGcw+n61PGJWDAKgkggGTl2g9BGmlJXUJYbE31KKiKw0Y5jAJJJ1A5D+lEw7FkOsEypHflH3+tdXVCDcReOSIaQJIY8hue5qv4TaGZmOpkwPWkrq6ej8iOs6QnjNgFtRuM0dhpWVzzSV1Xlk/iAYv0AjUzhmOazcS4vzKQw9RXV1XB1INpNH0P4R4+mMt51BVwBnXvzIPQ1aYrHKvzEafaurqjxx+K4nPnJxhx+cmL454tyyFJjbKKy6eInuOADpr6ADr2rq6t9QljW2Iekipep9lxhH+NcDfhWBPM8tO9YTxzxQYjFsyGUthbKEbEJOZh6sW+ldXVzZHTM+TTGOldXUBBynSmV1dVkP//Z",
            },
            {
                id: 6,
                title: "The Outfit",
                genre_ids: [18, 53, 80],
                img: "https://i.ytimg.com/vi/KdR3mnvInKA/movieposter_en.jpg",
            },
            {
                id: 7,
                title: "kgf 2",
                genre_ids: [10749, 18],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBcWFRgWFhYZGRgaGiEaGhwcGhwcHBokHBwaHBwcGiEcIS4lHB4rIRocJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QGBISGjQhISE0NDQxNDE0NDQxNDQ0NDQ0NDQ0MTQ0NDQ0MTExNDE0NDQ0NDE0NDQ0MTQ0NDQ+MToxMf/AABEIAL8BCAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAQIHAAj/xABDEAACAQIEAwUFBQYFAwQDAAABAhEAAwQSITEFQVEGImFxkRMygaGxFEJSwdFicoKS4fAHIzND8VOiwhVUk7IWJET/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/8QAHBEBAQEBAQEBAQEAAAAAAAAAAAERAiExEmFB/9oADAMBAAIRAxEAPwCC4+tSIQBNQYnea29ppFYdDRLwyx4UtxGK0y1HnIFDO5JoIi2ulSWHM15U1o3DYWTRG4UxrUaJyimVyxA01oVxFNVBmC715r86ChsQ81Cj6igco8jWpCKFQaaUfhU5GgGt2SWoz7ITRHswPOpsTiksWjcuaAfM9B08+VTRCmDgTsBuToB5mkmO4xhVJHtAx6IC3odvnVR7Rdp3xTESVt/dQTl30J2BPifltSQGd9fnVxNdPwva/D5QmeDsM6so+JiPnUlvHMkjcHUHz6HpXLxbOxBIqw9mcdkbI7xbgnXUKdYjmJMfPSgu+D4+1qdJB5GhOK8SN4lmOuwHIVDcsBgChDKdmEwYid+YkTQd/DOu4NAtvoSYrNuwSKnKRvW1vSgVOkGKjZGijr1slqjI61oBy1YzNRbZaGc0EZZvGse0NSBq9QQlyalWozUiUGRUgatA1b0G4NerQGvURcsXZFL100p3etUuxFkrrWGgF8GtLamdamvrNF4XhFxlzgacp51QLaGbYRrTrDYWBQGGtZW10Ip9h2FSiXD4HONTAoXHYDL5U/4LYLt4c6sR4ZbPvKDVkS3HKn4U7bLQF7AlD3hXVOJYe3bEwFnTzqrY22rsNJHlQJuHYXN5Uw9lAiNaMs2sugUx5GiEQ/hb0NRQWGtnUtoAJJOwA3JPQCuc9seNNeusmoRIAUgiNAe8Dz1BM9QD7tdN43cVLD5xCEf5kg+4oLOAOZZVKDxcVxK5cZ3Lt77sXbxZiWb5k1YVNgcIbjQfd+dW7C8IsrELrSbh7hEBgszbAbmj7fGChHtLTopMTBg/GImpV5w+s4G1tlEeVBdouziNbNy0ACupArOO4syJntpAYnKx+mvP4Ubw3EXWt+0e4jhjlKZcuYEawZrPs9a8vir9neNHDXFLktbZh7RYBaIIzADUssz4wRXT+MG0yKylWDKGBGoII0I8CK5HxvBhL1xIJAMrO+VhmU/OD5Grl2DvrdwxR2l7Tx1lG1T/ALs6/wAI61v+uf8AAOLTWo1WBNWU8HzlygJCDMc0Axz56xQ13ACIporJeTUV0CmVzAEEwKGu2D0oF7VA60a+HIod0IrQGrM15xWpNBitwajBqRDQbitq1BrJegkQV6tFevUHWnwJG4pXxDBnpXQ72DBHjQLcNtjvXT8P+NT8KzhrnVnh7MwVVZj0AJPyq6cP4RdyBWQLG0sPoJpxaxCKItoAPIKP61i7imI3jyq4mkbdjSxLPdAJ5Kk/Mn8qY4TsvaQas7eZA+grW5fY8yfjWqX2pkPTjD2LdsQsD41McQvWkyNNbFoqmGrX16TWBiR0perVIq0MGHE+HzrBxXh86F2qJnjUChij/wCM2KPscOoMZmdjBOoXII08XFcemuxf4vYUvhbN2Pcco37IcAz/ADIq+bCuPoOfSintnDOACg1gD0qQ4W4477E5dB4zGkDSjsG8L8YoDjPEQRkQmeZUx5jSsKty8IS9h7IMgMsZhqFZdNfgRUfC+y+RiPvqxYbgHfTTQzvHXWqZwsXHdFW6qIpzBnZoQSMx7up5d2ZPhvXQezvbSx7RrMtlMBXIHfbYkAHuk8o9TuZlbnUv+FfbjgDFUvopWFKOSRlgAFRmB1MkiAJNNv8ADbCG3cFk2xaf2Tlzq3tIaxldW2X32ldCJEaCjO0vGbc2e93BfRiV1ghXAYqx6GDB5VnsJh3XHY85iUtlbVsSSoJALRPgiD4eFXlnqf6t+J4e2Rgi28xEZh3Z8wBBP9KrWM4PcTdD5jUfKra+LYVoOJHmK1jG1zrGWyNCKANvTUV1K9es3BDqD5j86TYzs7bfWy4X9k7Uw1zu7aoHEWelWjivDXt6OkDqNR61XcQtRSS6kGoWFM8RbkUuuVoQitwa0FbCiNq3WtM1SLRWwr1YmvUHdOOcWxFh4W2row7pkyI3mkf/AKliGbM1uSf79Ke38R7VgSIA2r15AF03Og+NZSAbOPvEf6fzqR8dcj/TNGLwxuTv8q1bh7De6w84opd9suH/AGzWftb/APTNGvgzyvn/ALa0+xP/ANf5LQQJjXA/0zW5xr/gap1wTj/d+QrdMG//AFR/KKCBMa/NG9KITHN+BvSpDhH5OP5a8MLc/Gv8v9aCP7cT9xvSoruNI+43pRJsXB99P5f61q1m5+NP5aATiSpicPcw7AgXEKzHun7r/wALQfhXAcjIbiOMrocpU8ipIceMEfOvo61Zu9U9DXNf8TuyTh/tqLmDf6wUEhSqhQ4HIQNfXTU0FETiZVMvhQ2GdZLPrGw5T40K6kEg1lWoGdriLgjvt5bjpsdK24pdRnDouQ/egmDzBHSgFqRtfXargKOOYlWYkhYO8beVdX/w5xITBl3aXv3XusdZM5VBM7e5XHLiGD4+vjHU13XhWHa3h7KW0tvbW2gRww74yiH23bf40oJxPF0HMUBieMrHdInxra+lw/7Cfzj9KCey/wD7df5lqCY8dTmRWycdtjnNL3w7H/8Amn+Ja1tYEtJOHygc8y/KtB3e4/hyoyvuIKsJHwqrcVsWT37bCDunTy8KcYfhtpyV9mUI3nWekR/e1E4rstbcCBAG8aE+lBQsRYHI0jxqQYq+8Q4H7A5YJXk24Pn41XeL4DKAwrIq4GsVJFS+z11AE1kpWhGiVs/drbLG1B4h53oJWv16hQazRHfcK0GigZdB/F6UuwM70ywet0/sqB661lRnEcWLNtnPIfOqxY4LicUvtLl0oraqusx5Ux7VvItW/wAbifIVY84AAHSBWkUV+yMH/WetR2aM/wCs9Wx7Zk1qLNZUkwvZItqcQ48v+aPXsgg/3738w/SnGFaNKLzirJEtqu//AIqBtfu/Eg/pWR2Zb/3Fz0/rVjBr1XIm1Vr3Zi593EN8Z/Wl2I4NiE/3yfiauz3QOdKMRelqlWWq8mExA/3WPx/Wk/abjt2xbNtmfNcUqAxVQQRBIglm5DQakgTVqxuMSyhuXGCIPvN9BzY+Arnfa/tSXQm3oGlLeYANH37kSSuhgeLBtIFRVHxQBVW5iQ3gQdB6RQixW2FeCyHY6j4f0ovD4DOYU0A6tFSICfdBPWAT9Kb4bs8WIDNHUUVjuCpaNpVYn2jQT5FV/wDI0/UX80puYYqiM6tDK42MggDK3wJHwmrP2R4ziTYNlH/0joDrCsSQJPRg3wik/G+HLYdERmbOMxLESsmB7o86ddjSqXGzvlVwUUtsWGUiTy3j403xPlNRj8cdnHoKDu8YxgnvqCORAk+VWu7aC7fGl2Jw+pfc9I2pKYS8O7V4pGOdQ48o+YroXCsel62GUQfvDmDVJxGBGRX2VuXXw/KmvZG7F1k0AI+lBZriBbit1BFYu3SJANS4hB3WP3WHz0o/2IagQYuXQq2qsIPh4iqVj0ygo2pGldGx9gCSvSqh2gweuY6SPprQUbF29BC6zvS3EoVBYHX9asz2pWlN/CqHKFtDqPCgr4xRnWa9dLHU0xucO3POaHe0F0NaQIK9UlxF5GvUR9AYZABRPCtS7ftR6CK0s1vwRgUPUsT86y0X8TIbG2EOygsaswC7jWqqy58e0nRbcetWmxYgRViVDdSdqiFs0eLdYa3VNCohFblTW7pFeQ0VECa2Vm6mo8biRaRnImNhtJO1I7+Oe4IYxqvdXRSCy69ToefQ0k1m3DjFYpEBZ3AgT12+Vc07U/4mIhKYRVYx3rjd5VPROTeY06E7Vb8NiR7ZLbqGVzGoB5Exr4xS/tLwHD2cRZviympb2gyjvLoGJHOAQfMCtflNcdxXGLuIfO5uXn6mYHgNIUeQrzYbEPDMsj3QI0WOXXnPxmu3YjsthwQ6IAH6bA8o8CPoOtY/9BQe6B+0DPwafD6Hwp+TXCmQo/fEEQfLT6U2w1vvBk51au33ZF0tnEooKpCvl3CkxJHQEzPQmqj2fxWptsYO6Hx5r+fwNY6jfNXXHR9nS6NDGVus/wB/WlHEMUvtMOsibahjM7k5wPOMvrUWPxzC3knds3lt+lV+6ZfO+pA6kSRou3wrPPLXXRxiUe7dViZkgk6AR4TyAEU5wvALl5JQZ8rQVUpOoEQGYfh+dVjheKPtVBMaMdhyRiJ011HPWux9irI+zlySWuOZJ6KSunQbj41rGNVDFccbDZExKOogBXdSJGm5+WYTvqOdPsBjLF5CEdSSNRI9NPPYwfCrpi1zrBUGdNQCNfPpv8KR4rsphveS2tq4ZJdFVSQBGVgQVZTMwQdqYaR4nDALkA2PPzqDh6ezxCeJq28J4aCsP3hECfDmOa+SkL4aUNxHs5Lq9k6owJVuY37p/I+tTKaNxQlG8NfSDR+GYEA+FB3EOQ+KyOc6eG9b8NnIpPQUUTiE0mqr2hssyEiJHXpVveCIqvcYw2dHExp5TpQc24neKplGrTuNo009aW3MHcBDMunU6x4U2wyHPlaAFO/jrApxcwXtF001nWgrQsKeoMb0txWAkjXXarLicIUlYI6mluKRS4Kg6CPPrQV48P8AH5V6mXEnC7GNdq9WkdqcwrHoDUvBkhF8p9aExz/5TkfhP0ozhohE/dH0rKgeBWc2KxDn7pAFWdhVf7LGXxPX2mvoaeXsSq+8wFWfEv1KqxXopXd49ZX70+VRntFa6mmxMpuRWuSlS8eQ8jU44slNXKA7WYjLbRZjO8ecKx/T5UiwOJ7mu6EL/wCY+jeooXtNizcxOWNFELJ0XbYeMkyeo6UtxV8hbgTU6Np94qqmPjEV05+MU2S5/wDsoOjqR/8AU/WrRxvChwtzfJKxyhiJPqAPhVIt4lftFtwe62VgfAwfyq74bGn2OoHuSf5ZNAD2exAYPh2+57p5lZhSPFWBX+EHnRjsSJI1BKsOvI/AjXyNV7E3vs91HJ0Q5XP7DxnPwaG+Bq0Ygd4NybQ+f3T8dv5aoVcWtG5hcVa3LWLij9qUbK3np6qa+dLV/UEd1hBHgeo619L21hgTtqp/dbQn4HXymvm+0CmcbFRlP8LAEeo+VZ6WG5xPtAH67joRWxsQrEiRAga7ytZ4PY9pbBYkAMdYzTAt7a+Iq0YbhqcriERswcdI2Uj51lrVW4Vg4uKxJ+9PxUg13XsZhQuEtk6yCR5F2b11+lc/bgy5c4CZuRVtBPXNFWbh3E2WxbsP7NlzW0LI5BUFgzK6sIIKhgWViNRoJoVcrh18u6PMxJ+nzrS9azDTkYHmP7PwNK/tLhLiWouOqFrWVlM5tAskx3GPX3cu5mpeAteNsC+jI66Ekqc8DRu6d4mfGeUCqhlhLeVdo/szQePvFbdxgYJQqv7xIVPm9ewWIfPctupGVVZCRAaVAYDrDDqferFtc4tKdiS58ckQPUg/w0QQ1iLYH4QB8IAqHhY7gHn9aZOJkeFLuFDufE/Ws1qCXXpQOLTRutNGigmEzNQcsxlvK7jx/v61LhsYUheVO+LYCbhIHOaCfBgmPUf3yor2KuKyyTv61XcQpHeAEA6+VWTE4cZYG8Us+xsCDEjxoK3jrGdZr1M8Zh8pM6Keh2/s16tDpPFT/kuBppHzo3CZlUCOQqDiNwezb4fUUwRxArIUkPYuvcRC6OO+q6MCOa17G4+zcAlbydR7Mn9adowrfSgqRsYc/fvfG236VKlrDfjf/wCNv0q0GKga6OUVcCAvhpIS4ZBysAhOUwDDdDBBg9a8lpCwAckSNMjCfDWhOxeGf7ZxJ3UhXvoUJ2YL7RSR6D5Uf294uMNhwqAl7zZFC+9Ed6PHUD+Kkmpbii8U4pcuXWUFTHvPEKTpIWPug6fAVGt2+jHMiuIzdwkMOWxrNi1iCASLNgbBCudoO8671K+FuF++bTgqdQvQrXSMBrN7u2iJ/wAu4E2jusZTTlA0+Brp1lBkI5HKv8zKv51zHB2wLot69+H3kSjoRE7aM9dGS/CqOpX5MD+VIEvG7efPOoZoPkzZfzpv2XxXtLLWXJLJ3fEr9xp6xpPVaDxNqSPFh8u9+VLmxX2bEWrmys3s7nTK0mT+6QD5TSpFrN0Ipd9kDF4H4RLadIE+Rr534ribT+0e2GUvcZyCZCh3YwO6DpMa19K+zGbUDK4gg7Ewd/NZH8Ir547VcCXC4rE4dJKIyZJ1OVlD69csxP7NStRJ2axiokMCSGaAADoy25O+nu7eNWjBY6yxAbOk6TlkDx0Mn0qrcBwLMAFBOpJhSTskRVgwuC11B06LBn4mstYJxHEbQkB38gv9aEDq72irkrmOeRHO2QIO/PY1NjuGQocOAMxXVTMgKYOVo1zD0pt2ewZyNnRHdSropthlAcCWOZdCcqiPKgsHYzEq1xVFqyGW3q628rwAoktmMkzrtV6bl51WsHxO6TOS30JCmfUGnmFxYbQwG6dfKkqVNiHyqzdFJ9AaitWwuUclUiTp0qXECVYdQfpQDY1QbrRORZ/lzSBz+7RBoxCSe8vIe8PGh8MmUsP2ifgdR9a14bjRftFgsSWUqYOoJHlB38iKwcOFJyggAbch4DoKKJZtahvGKjUtOvwqUONSay0rOPWHJodSGmIBHWiO0F0BgQYB5b1WBiUL6P5gHb9aBvi7WYSInry0oBruRC2YtOmtEtjQBkLTzGvWgMe2cxoPHqaBXfZSQM22uleqTEYFHEkmRroYnzHpWKBpicU5QjOf7NG2eI3I9+kzucpqVbhGk1cDkcTuD71TLxO7+Kk9kk0Qzwp8KgKu8YunQNW+Gxdw6lqCw5G5FFK80DnDcQfr8qW9o8O1x7VxoJVXRBMQzFQWIG+kD1qW21bYtxmAIkKIA5kiZgfvFtf2a1zPU6pXawoDAFgABMBAeg+9Pj86j4phWVS+cFMoA7g3JP6DanXDVZ3JZFVdgZEwANfXN6CiONWQ2GYD8cifCEH/ANa6MObYNwcbZEyVDsY0/wBtz+VdCb/bA5tr8Fc/lVB4XhT9uMj7lyP5Mg+tdBzjuGQAJJPQZTr5RPpUhWXTvKPEt6KR/wCQpRxqwGdVI01J8oy/+daYztbh0lhmcqCI0G5BPWPd6VSz/iE7uGFhRyKyzsZIJykFANORB23psJK6x2VxZeybbnv24WTuR9xvlB8VNc4/xFvFsbfQd3Nbthp2kZWMeYCg/u0+4VxpBibLIpHtE0jUMG1KNIEHQQdRmUdaG7Qql+9fvwWlglrMu4QZHg8lzqTHPN41i1rBvAsf7PBi5bUPfAEhVGZlDZYEDRVEEgb02xNoYiyLtxFRxEkAHutHvjwJ+RqocKDoP8vOTLSNpEKTpsRTxO0mSw6MmViCsnWQwI1G8jpXP2V18sKeI4nKvs5K95mJOqOe5lOn7vPrU2Av37L+0UFkKCWnLlAQE6wR7swDzIrbOuJQoYV2LlTECCmaPLMvox2pXetk3nw4dlghATGXYZQ2ogaD41ph0/AcTsX1SLie0ZZgMucGNQR1GsjwpVxy+1s5e8H3VhpMc1PXw8arXAMTbtYmzlc3Whg0SIhQsgED8Xyq8DjGGugFipCnMMwByldc2m1X6hlfcrbLHUqsnTcgdPE0m4XJeeRkGfHWT12/7qnxfG8M6FBeRsxAIDDNB1mN9h0rGHVV0DeK6EAkaxOxOm1VA/Z3AXrFy+jD/JLA2jI106AzAUIsmNVPWmmJdgAyyQAQ3XTYmikuhlkEHmNfjXrtqQwH3gR6iKZ4b6UDiAPI0ux/GMkjKTQLYkpod51nlSviGJLSY5TE1lpHxPiyvDbaxB/pSBgofN8RHrr1qM4hs+sADl+fnW2dZ1gTtJ/vwoGaYVWObNpH9zW0Zd9uv50kvY5rZKqdP72odOIsd2JHnQWN7DHUARAiDuNINZqDhWPEAMw5AefKfpXqDDtofOjrdrNvpULWe6fOirYHjNAThrUVJdUE1Gb2WoRiCT49KJgpLfpUltBPQUB9oM0RbefCij0uAGSCVGpA1JA3A8TQbcfd3b7PYRpJBdyTOU7LEAgTvsNNDUfEbwW08kiQVLCZUH3mEc8gaPErS7AYglgF7iqAAFgBRAKoOUKIk/eaTtpW+WelywZxAURawo7u2d0IPScjTHiOfxorF4sezZCmV8h9mGYNbZoOUBwYmeTZSY0FKbPEMogjMTtlIk/BiI/vas3uJwrZRrsSIMHoJIzN/StYzqj8CL/b10Z+44YhSYMpvA0M/WrRxrEGzhwzygI9mTvGZSDp5A+ora1i1tzCOXbVj3ZPmc39Krfa/jDG9atFMwVHuMh5lu4m3QBz8al8iz6qPE3SGKOx36DfzpLhLLSSUbfRtYHgYBoniV0R7gTXXfT51DaRVGhmTzHTnWI1XT/8NbFy4PaXMuS0zJbY+8GIBYk7ZQum+7VHxvjyLecaZA7hGWMsFtWEaEGPlVY4JhXJQ5LmUkQVRyrDXnzHKpuMcNTKMkHKB3dDoSJJnnP0qh/Y44iPaYaBjJ6QzZSfSpMc64p7sKwa2pe2AQc0GQpB0JKyduVUrEYdu5rEAjQ676DbSnOA4oUul8neKgmI3AGaOgbf/ipYStFvMzqobQ6QJEBtyTzMabVFfxrF7xmSzNBIk7sP7NDWrwa+pkqvxrazafNIBMd4lRmgbkmNhVDHhWIFp7lzfLbZyCYzGVdhsean4CsnjKMpCIVJaSwGsESVB8zHwqFrgCPmEM6hSNjqrZo8pmlCuyoDkJBmCIJ3O4NBPjsSsd0MD/frUCXXXvh2X90xHoagTG6xmy9MykDTaYEVu1wEESh0jRl9d6INXi14bOsxHeRGPzWmGD7Y4tPdcnyd4+Clig/lquG11kbdfjtNZFrKAQfn4D+vpQW4dsnYguhJOpMLuTJ0CrUeJ7T242YE7SMoEdCub6VW0d11monvMxkgRyoHgxFu57rqD0Yx82isXsEQdO94r3h6ilTYf9nUedDqYOkjxBoG72TG1a+yEdKHw9xzornYmDrOUSdOegNHpJUFlyk8ulFaK5X4bV6g8XeYEAHnXqC+3k7p8xXhcAPWKDe5IIoe45iDv1FDTG7iVNDm9rNLBiT0Na+38DRTdL00xsNpNVy1dPIGjrGLI5H0oNu0t8rbToSfXI2X50kt4wplA5kseY30pvxV/aW2WNu8NOgIPyJqq3HgnXkFHPzqxmrGeMMqF47z6SOQ6Db/AJNTcLxzMxQIStsRII947785Dc9gtV9cRJT8KDN8ZgfOKd8FdEXuqxkySYJJIA5HwFND5GE+68nfQfka592sxpGPuMpIKKicwfcBI1/eroOFvgtLAj+Fv0rmHa11+24grMZxuI+6tSkC4+4XSdTrJrTg2Ba6+VT3NAxOw20H7Ucq1w2HDmWBC9dpOmk/GrfwKyrFVOgC6R4DQVItW+zxFUw+cTKIWj1IHp9aoWGuBgrGcwI05Gd/IVaO0GH9jhngnVVWD+1A+nOuf4fHlHE8jPnpIq0P7CrBBMESB4amg3uBGJME7Ajx3pKnESbjsZUFttwPM/Cjrl9TrPkKA201vOGYgADQaclMfOPWnPDsJce8FR+4UUXJkDI694DTWQGXSP0p9jvkwdgT4abj0q18C4jkuZdhlQc5gTr6v6UDDtFwc2XD2Fi2FAInM2diViDqQQyxE86REBraHTUEn4sTVv4vjZTQzlZW6RlYN/41UryZbaeK/m1ELriD4VBdRG1MVP8AZmeSBtr9f0oTEYZxy1IkRrpr08j6UEDYVNY0PgSJ9KwoaIzv/N+tbC0+XNHdPPTlpXnQgAnmJGo21HLyNBhbZmc7/wAxo3D4cdT8SaXKXOwNTI7jkdDHpvQOMNbQaGJ8hXnwySYUUBhnMzlMb7eE/TWinxZick/TaaBhw61DiABCsf8AtIrfE4tFB5mk9jHMzdIVtp5wPzoVxNFibFYjUHrXqFVRImYr1BerxI2NQ5mA3qW6usczUKFi2WBRQTXDUyXRlNQurFoj51q4OX40QbYvH8NHW3J5UusCjrVygLs3eoiqVxfh7o5KqxQklSASB+yY2jx5VYb/ABm0GKFtRuMrcxPSOdNsDelQw2YAjyNBzz7UQpAgkxPXSdPnTLBYt1j9Yq730tv76I37yK31FRXuHYcI7CxbkIxH+Wm4UkcusUA2E4oUHf3595Y+uv8AUdRVb7Q8Na7fe9B9kwVy8aAgBSAfxSAI8aS3Dc/G3TfkJgelMMN7QqQWJ8zoeeuutBChzEACFUQqjlrqT1JOpP6CnGBcoNOQ+NLsPbYNqBJMCPHamuIwOQQ3v/hHLQnvHb0mppibj3FJsFSsksN9DoDvVF+06iFTYCYbqdtau2C4ct4ZLmzMq6aESwEg9dedUTQnmBuNiddp25UhWGxQBPcEEzoSP1qSzjF2KMekP+RU1nKsQZ84H61GiICDJ0/Z/rVQzwzIPuP3tIkc/hTGzeDB8khsk97SQGEzlOtAYdRmWHA1BkhvPkDRPDyBfygzKEbc8mu/KQaKZ3kvFTnuLsQciEkyCAAS2szG3OokuZsmcnKFggeJ5VYMbwO+MO94oAsSO8snNGSIOhll6RPKKrDpBB5afQUK2uNZEauDlb1kZOXnUHtLQMm443AiQY5A6dT1j1rGLXSlyIxMlZXXSR0PXpv8KmGmSpZAIF1omOcZfLL1Z9PGedDXsmbRyRl0PMaxl8NJP/Na30EEBSDmLctFMZU0bYfHeh4XJEHNO+wjpuZ9B59aMuVmFuETMnXmV8eep/hrKPDAC77xJJ0EeJJbn/c1rd9nOuYDXb93TrBLb771A+XTLO0mfM6bCNIPPfeiGWFcmB7VRoOmmbdfhUqTIAdOZkxoe6IPj3vkelJgDWZNTAwQEMw00U/JhP0r1Q8LtyX/AHfzov2ZqrAzivVK6V6hj//Z",
            },
            {
                id: 8,
                title: "Moonfall",
                genre_ids: [28, 12, 878],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBcVFBgVFBUZGBgaGxwbHBsbHBsdGxwdIhoZGhodGxsdIS0lIR0qIRocJjclKi4xNDQ0GiM6PzozPi0zNDEBCwsLEA8QHxISHzMqIyo0MzMzMzUxMzU1MzMzMzMzMzMzNTM1MzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzM//AABEIAQ4AuwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAIFBgABB//EAEEQAAECBAMFBgQEBAYBBQEAAAECEQADITEEEkEFUWFxgQYTIpGh8DKxwdEUQlLhBxUj8TNicoKSsqI0U1SD0hb/xAAZAQADAQEBAAAAAAAAAAAAAAAAAgMBBAX/xAApEQACAgICAgEEAgIDAAAAAAAAAQIRAyESMQRBExQiMlFhoYGxBUJx/9oADAMBAAIRAxEAPwD5GQ+se5THuUbokpFMxta4+UUJngTBpYvv6fWBp4GGEoJ0MAEVJu5iBQNPODlLRBaGFYAFlpBgYljnE1A2AiILcIAOKYKheh+sDSIKlIpYlq/SAB6RLGUElvdohOWBp10hRazygKlKHKAB4YirDpp0jpkws7seO/WEEpf+0cdwrx/aAKGUTlXJHLX0hmSsqsffSEJk0qsPT7CIyyoWLQBRbFQBD1G+Bqmix9dYRTOL+KwiC11pABZIlgG7boaWFNSu5m6sYqJE1WhfhFvJW9KPDAO4bDZ0vlt8X3vAjhSCaON/2aCy15SWiYJ1H2b6Qo4BCOFd7V9/aCZCeH/GPFsC+Z/p1ju84QAZpJ5xLux1hhOU/lCSLlz6RGcNw3a68DugAgiVUVhtKQm9X5tHsiUSCRp0PQaxLu0OK6PfXWAWhrATEmlAaXFekL7UUkml9/0gS2BJBppAlEEl4DBfK3HhE0y7OGHrBEpAGh83jwr0IpygAivKD8QPG0RCxEJhGgEDQoC8ADaq3MSOVqu7UswMLFY3t6wJSidYAGhNAoUwOZNCrpbl9vrC4g6l0DsYABpiGr3gmbgKxzDdAAO70ERg5WQGFvSBd3AaEkUcs8WGFmku9PUQrh5VnHnTpFvJwqiaFyx+HSNsKJoXV1D0rDKFuLUgSEBAZw5319I6gVlJJPGw1oBGDJUQmpGZnZJZzDX4OXu9f3iGQKpQDXzrEO6SLZepD9YDUhTHbKmSSQsUFAQQoF+VvzDmDSK2tfUxotppARlXOVMUp1BSS4dxlUQSzfEKPFEuTmNbb9X+8SxyclbK58ajKkeIW6T4gNdXUfq16xA4kgAbokvDAWUOTVHp949TIBs9vZihEgua7F3ep0bd6RCSzFx1f6Q3LwBVY0FauzgaMLnSATpJTRusaAFaybRxFiaCCd8MrVzPqzEadftAlqeAWj1nJAGj9N8eBNWp5CPAzeIHofm8eoW3I8IAojNkqAfTfAaxZGf4WYpO88ho0LTpiVGwHFmgADLT4mpDypSDoQbH9tP7QgVAaPE0TVAUp0bzgMCLkEOwLcoLnGVgkc45Ls91U3t6x5NB1DaFoAJSZBVTwjzJhjEYZKBVRP8Apbe1fesKypHiqWG8v6gPDwwyMj5gfFUgbtH1PpCybsrBJpkJC0pOZKDzVceUHRtF3cNwDJ84VmLCBldKiwqlWYAF6E/qtQUgkhSMoZJzOKg1J+gfn9tv9Bx/Y3IluQXPu9Tp9onkKFVrm8mewPPWGcLgVqqsMn3Qu1W3kRZI2XIylcyZMzABkjIEA3sQCp2/LZxE3lSdF4+O2rKdSS+rOzaefWJ/jMtMopxjwScywkeIksAN7sOnXSHv5OgUViEJOooW6tWGcorsRY36KrE40LlpQpAStFErSAHDksoUGtGGnGL3ZmwMOvCnHYyauVLUvIhMhGYuAxeigA4N7kGtYzCsQ35UHmmNlhppOxFnIimLTQpSEtkFWJZ42MaaoVycvyCzeyezk4dOLOLxKsOslKcksFQUCoEEZPDVJuBFdtjs3LlSpWJwq5k/DzCoEqSy0lJYhTAAFxR9xh/Bz1HYqylEt/xQDBKUoAyCpqz8Y78YtOxVHwZvxeXwsxHdg6UeHkpfv2CS/Qj2X2MMQZpWtcuVKQZkxQQSvLoEpDuaE0e3KGThdkkscVjQbOZQYcT/AE7R5/DfFqXMxScqH/CTSGSkEnwUjITdrqBbLLChuSi/+pMZbV0YWXa3s4cHOMv4k0UhZAAWkhwbAE8tQYd2F2Uw6sL+Mxs+ZLlqmGWgSglSioAklRYhIooNwhrt/jlhGAAABOBkKVvBIVTLup6GJYDEqOw5yiQCMYkVBt3EsCiQWqeVYFfFfszVhMF2X2XiViThsXiBOUDkEwIyqUASzhHCMVtDZ0yVMVLKFHKSPhLhizENS0WPZTFLVjsKBV8RJemneoJMG7ZYlRx2IFQBPmgMHBaYtqQJtyr0Y0mrHtidlJSsJ+Lx06dLlmZ3aEy0FSyQLqdJYUIFNOMMo7HYLFS5pwGJxCpspOconIAKk6hLJBJ4B7jfAsIsfySaXJH45Olf/Tp0eCfwtSkbQlspSiUzNKD+ks7zA4unv2aqsxaNnKK8mVdNcpIjd4jsjgcKlCMXicV3qkpUpMmXmQkKDhOYoNevSMkUBbLUcqikFkpSK5dAGj6d2s2pg5apJxeCGIWqRLWVvlNUmjdI2tpP+jNbMVtXBYBEsHCzMXMW/wAMyUyQGNQQgVdtYl2c2DKxKJs7ETFSJMgJUtSUOo51KQgJSQXJKSLG43x5tjb2CmSijC4JOHXmHjK1mlXoOkXv8NJo7jHDETCZQly1HISpScqphBSFC9fThGNKnTNVWJbO7PbJxUwScNjMT3q3yd4hOUkAllEIG7fGcn4RcuYqWJazkURRKlBwSC+UbwY+h9nJuzU4uWZOLxallYypX/hkksARlFKxnu1SFfjZzEACYoMVkgBzZOYV4ONYyt0mbSo8x3ZNP4CXiwJomrWpBlhAYJSqYArKEZ3IQlyT+blFRh8GqWoK7ok5gQChiNwDiNdjVg7Jk5koKRiFoqApkqSqYQOJU2sZqRi5UtTZAondLQctC4pVyNQdYXpb2VjFN30aJeGmLwMybMKkLQtKQijAEPdyYopkkhCXWC4cJzElm1oz0vGm2XOXM2diwUCipakgpFyqpbeBGOnzikB0JCrfCB75QsMaSY88jbaHcNihL+CUkroEkkmtCSza7oIdnTTXwB61YmtamKdc9T2AI3eto7vVmrv1P3jJQt6MjlpU0Ir4tRvlqdIf/m6/wpwgCTKUsTHY5szMKvaCYjDpUHS78WfUmtHr7MLHC5Rd1agP9vveJxyplJYWmcja8wYU4Rkd2ZnefCSrNly/E9qWaIo2rNOG/BpCVIMzvAySZmbLlDNo2jPE1SlqLABR3i++8QkoUJjF0EG5oQXoX9YZTTJSxS/wC2PtKbhZiZshWRaX0cEGhSoag7vrGkP8RsT/APHwr7+51/5RR4yVkzApGjsQ1viYeFrx5gFpC3MrOli4cAGjVLMwfgxaG+RVdGLC7qxbbW1p2KmmbOXmUQAwDAAPlSkCyQSWHEw52b7T4jBZkoUlSVgZkLRnSSCACzghTPV9Gbc/tWShARMkyykfm+FRSHAqHIJoa0NHijUtalOfF8wHoH0NIyORSV1Rs8Dg6u2ayV/EDHKbu5OFQo0CkSxmSbaroecZHFInlZXMC8+Ykq1JNSS1HfzrHvdpSTnCgQWcZCx96vHs2cKPLJJDElQryATTfG270ZwVbGMPtVZw6sICjulTO+zEeLOEZAHNGygUY9Ya2FMnYWacRhzLWqWlZUfiTlKcqjRhZdhUG4iolyAoOxSNXqBuHpE1YevhqxB0V10aH4/oTkq2iSCzWoGrbQb4utpY+ZjCkTAh0y0S0lLgBKXYqqXNYpyFEupD6uzsOSRDuFQVKyoAS9hT/srpc6xuhVFsrcRs0ppfkQfWLTY87ESZWIloSnJPShK3BdkKUoBJcM+Yu4NIl8JYkKqQWAIvcHUN84sEYFZBBWECxTnCVEX8uukLKSrZSGJ3pCuyVS5E1E4KWFoOYeFJSVAuCQVO1N+/dD+NUiZMKyhedaytRKmcklTJAsmu42gknBCWoFCgWuZYKiLu66eKDoBLlKD4gHKlOVMSfYiLau7OmOOVVX9E8J2in4QKQhKO7Uc2Rac4B/UDcGw3UFo7a/aKfPklJlyUpLHMmXkIavxPb94r5kgqUxQSdzH1pDErZql5gAAzO5oAajrwFYZ5IpGLBKUgewttTcMVGWtJSsMpKgFoUBYsd1W6xaY7tZNmS1oVLkBK0lLplsoOGop6K4x2H2XKlpCpinL1SGFK+3vFVi8Kla84TkpRiXb1JHH0iUcybpIu/FUY3LsRRKJUaJ9txiapA3AdBFrhtmrUASMqTvdyN8WcvYYYV9DDvMl7M+llLdEJ+wETPFKXnG5JAUNxym/nrFXP2QsODUF6ulC2biwJpq4pCsmblmZ0qAcMqgckfCX4VpxjQyO0VGmBKk6hQFuccWTxsmP8XaKYs0Zu+mZ6Zg1ozEeJgGUwJSx1Cnbo4hebs9ZdT57F2BJ9HA4Rt5Yw0wjIru1UYV9DBzsMgUyt+oFxfVrViMc7i9rZdqNHzkYVZJICqPUvV3cM3E34wVKZ4QoBa2ytZNU0oCUvoKg0YRtsRIKFFK0ZgwO7W4I0bjFbighnTnzPvBA6/aOheQnpon8C7TMOrDLRoU6sQztu3/tDEgAp8SFbvCoUqC2U1G9xvjWy8+rFIDeICot9bnfCM0BJJCE13gEb7ZWiiy8tf6F+Gtr+zN4vDWYHlo2lyTAkYIs730+2kaSYSpWZhWwASA3v5xOWCUkJQK3JApwBMVWVJEJeO5SM1K2USWrrQCsOnZZQHIvvLfV4uESFWCRd/b/WPV4dYHiU4OjFvQt6CB+QkbHwmynTmSTlJAOj6He7kj1gokhVfE/nU62F6w8ZQSzovUEFI50cn0g6cOGzBzXd1uD7+SvPFjfRyWhXZ2HyrBAciinajvZucPKTlJAltxKga/7ktl4Ut1iYWEv4S/Ekt5wVc5WmmuvOkI8qb2Wh48ktEcPMWlJMyalNXAASa1uAg+RvE5u0UN4gpYf9ZSDX9Iy14UtCipL1cHhoP7esTlYN6m26teFIm5R7Z0RxTSpEcRjnBSmiSbJoCNAbuOcAwuJmP4SAHuw+r6RbYXAkslCSXcVLOf8AY3K8RxyBhgha0KSlS8hUllZTZ1Jd7xsciqkjJ46acnQFElai5v8AqUb9NOkWGDwB+K6v1XHrBRi5af8AORYm3lFRjttLUpiaDQUEbCOSaqKoTJmxwdt2WmJxSJDOc69zlhXU/SF//wChTvbg1ooZqu8VVQGrl4GyB+YHoY7sXiQr7+zys/nTcvsdITWhQ1pAjNeiqh38ouO5QmxccdPKBLwqTenJvWKtp9nOlJdCqZ5JvDez9ozJRUELZLhQA36uOdesLqlJFmMdmRyiU8cZKmjox5ZL2bLZ/aJS3EzKoMKFmurhQ8eMMzlypoaWllfppX/T+q9gdIwEnFpzMhYJpqC9x16cIcl4xWYEmPPn4abtHbj8hV1s3f8AKkqQfGxbUUJ1HvfFJN7MrL5EgngQRzaJ4XbYWnLMJ4LHxbmULLHOvGLiXs2eQJiCFghwpKqeRqI53hlHpl1lT7M8rs5OFMh8g3mW+cFwOwZo/wAQrUeQAA3BtOpi3w+1FhZSpRBBsYtRtwpI0I6xOXydN/0PcltJMy+F2fnUvJ48pyltDuMOq2UpNSnqItMPikIXMWhTd5lKksGCq+Ibn3QReOVlzpKVMzuaNV8tPipEGpN9lPnmvSM1itlKU2VJPFuMC/lqxRKS/AH7tGnV2hckIKWF2I8IZ36kfOKvG7cJ1Y84tDHNpJMaPkSV8kkJSdgzVDMQBwVlD+cEl7FAUylJTzUD6gRUnFHMtapi1FZdiaBqAAWgKtotzYan5R0fBNrsk/JSbtjWIKEqSlRC6F1BJSkpZJUQSVKNSaFrbqlibtSWlu7Q9Q6l1puABA+cZubihVqOa82A8mAiCJpUauIvHxk/yIS8t9I0OJ20QGBytuYfKKsY9cxRAJJPnFrs/Z8uYKqzKA1SCIfwmzWUpkZTbNp0cOIaHCGq2Jk5zp3oyc1aspDkb+EI94oJGZRURqzP0jeY/s6pYJDGmuvlGcxHZ9aQVGXQe7R24ssGefnwTEsBhFz6S6q3KLDzJ4wyrZE9NCZdP8whVE5aHSlDdLcoH3695jp36ZzRjBL7k7JomNvju8UaBNeAhmTtNI3HmBDSNrkVBSGswEcsptejqjCL9lajZ01dRLWehbzh3ZeyjnUJqXCQ7E0Bf83CLGT2hXVJIY3zftAsPtAFS1JGgH6v1Fx5fPWIvLJ6aOhYIJWmYVExQLhlVcWPEcY0EpC1BK1JJK05ywLVJf1eKJKS7Fuojb4BCzh5CkiglgEf/bNT9I3JPirFwQt0V8iTWhbWoPlaNrsPaM1Espdk6Zh7pC2G2UtTPmSLeIZS4D++UMy9gTH8VUvvIP1BvHBOfI9CMMaVMUmlClHvHJe4p5ER6rDIoyjlNWeoPNo9x+zRLYsrMSWBUA4Fz62ignbQXLVQENub7QkYyl0Wc4JWXKMM6jluWCnILsCUu1r+sGxsmblypAJoQxqCCCGH72MZ/D7QWgOyqeIqIcsaO/Jw3SLU7RmFSRldKg+YbmOgtaFnCUWEZRl0I4hK0VU4B0cMLuA1HehF6RTz5j0B4xaTUKmnMzJdRHCpctxNYTOFzOKHTi+7n84timl2SyY30hVGEKrLA4a6wx/KFk0I6mGUYBSWfwuSBmoT51awfjAkTlIcqJYAhtL6PXryi6yN9Mj8SX5IfwXZpRIdSCN76eUaOTsiVLScwQRqaDjGWl7dUA4DA77wOV2lK1BLEu4c2o8JOOSXsaLxx0jSSly2IQWawok3a9q8+kRxO0cigChYPEEGKhOJBoSADwpTiOcXGA2qJZSleVSR+UgW62LQnGux3tfaM4DaiVeBRNbFi/CsO4iWti5dLuGAtq4hDaO3JRU0uWA48Pho43nSK/A7fWrMkhm9Du9DBTu0hY9bLGZKkWmSy51q37QH8JhNZQ/8oSn46rrUW92hZW0Bo56R0KTrsR41ZkZmFChmSFDeGPmKWiKcKsdLglj/AMSxh2VISmYQJhUAxzJF3f8AU/kbvD/8rSfGEkpeqE+EpN3BIYp+VtxI/IS0SXi3tor8MkEHMsJ4VJ42p5mLHALSETmBYS/ian5moLQU4L+mQUFKLkgKJZwarDZRTTSDLW2HmkSwlKpZGbKoKJZfxE1bdpXjE1l5Ms8PGJk8PLzMDpR/vH0PstMShUgLmAJCFAhRASGmLUCcwuXSQb8Yw2GXva4rvHHhxvFtLmOElJZKXDE/DqA9iK0J5HfGZ5O0ZhxJxez69hMVKeYohLpLku4KQHSoDkTbjDUidLmVSSHUGFUkkCvMVD6R802dj3ZKlF2y1ao0BfcQ3QCNRgtqVSoiod60FqAdPSIx8lLTSEyeE+4tjHa7AFWUpLEJU3E0LGmrRhZGz0lX9RZSFAsou4U1KB6aMOO+Nxj9tpmMlhSl6mrRjdtpzTEOAhw1WB+JQcuaNxaFlkjyfEvgxyUFGXYtjJCAVpQsrBl+NT+HO9hQMW524Rptg4JCZCFkOop5mi1cKJ4xUJwiTJWtCgoJOUnRmADC+azk0AfnGn2NhgZEpk+JSVIKhoHL9dzxrlyRmX7FafsBO2aAhkeImrkAu+4Ware61uIwiUSwZaPEpiCzrd+po7Us7RrcPstSqqLBqJuAaMU7rQ1iNkIUPhcgML03wvwyatE15ii6bswK9mzmAVcguS4YO4dVieG6FMXhEk93RS1VKRdyxA3Dq2nOPoOIwJcFQLB6Cr8S3upikxmFSo50AmoKgCyiWZN7WalTvpCVKDLQ8lT7MiNjFQdSWcO27nS8V34MJWUpDkEEtq4q46xpdoSpsuakykFSVOVF1FJCiKlqgtrp1MZzHT0zJih3au8KmKipgBmYEoyg/CzudItDJL2NKEZbR3hKSpy6XFiQXILOzPrewMPSMD4UZaoJZlg5hd2NbVoeWkeo2SubMyv/AE0MJeTKtJYgF2oCQ5JMPzsMn450tKAnMEJewLVZNAun5dDxgll/TNUF0V0uYkd6oghEo5XsC4FACKl38xBO9cFpeWvxFnPFn3b6x0/Hy3AJKhrXyuYKjaMhKwyS5FSC7HcAfdYVzk90MoRiLfgSs+LhQmvD+3GO/lw0HpDs7aKAVKC0qIAS76v8LAU39Buiq/mCjoo/7j941TkDimX2DwclTFaghRdARlSAFuQoqUkF0kJBBccakNHZGFmKSszpviOXKhBZIoWJJ8QBq4Un1dqybj1MlQWDldYyiWkUf4zkeoOnpFgZiroyhSgCXQoPShJSTCU0uhe/+w5iMMkOpKAo1KQsnIkiibClTe5c7oq+0m0ErlLSkp8LJUxs9GJGt/M8IY2RiFqKs6EgpJdOYqzJJNSP0kpU3LhFd2wloloXkypUtQUpIJJAcEFVNa3rFMUKkrFyyVGSzEUFbGhpw93rDCFkBKgsORUPXlVqt/cwnh5lQ5fWrG1WINGi2nSHloYJJZRpRQGYmhFxzjpyxrs58Ur6DSJhTlzKYKSC/wCm5Aah0rpFzhNopZTkuwq+o+8ZFHEEjjuhqXMZmo5pWjPbpHDkxfo64ZTW7JxqBMBmfCWcs7MdH5aQzt2WmbMSqUk5VKGZwqrGqjRg4pfdaIbLEoYcEZTMJAOarJNinj8nMW8/FmXMCFd3k7ugS6W8QDkE3JLPWJwiE5fdaTvoqsYUgZEkJTlBNXJYmg0AcANrvvGj2LPCZUsPoTfXMr6U8ootpSwpKpgzDwOkEBm8BrRwasxO/dRvAECUhTl2sQwufhVqeEUlLjsnKKnGn+zd4CeFpeg4CGSYw+E2opI1EezNsE6mOmHlritHHL/j58nXRrsYpkEpZ9PlFdiEhKcyiNHNuFesY7GYtShc+sN7K2f3ic6lrJJIABNAzHzDxCefm+h/o3jVtll+HXMWtKE+FNlEUJ/MK6JLWuQRo0RV2c8SZk5apqkkkAAJSXAAdIuzalrx5tbay5amSrLy/eKfH9oFy5a5i1KUwbK7AvUdXpyhFON1uyscWaUeSaS/su1z5ctDJCUFqpDUPFqb+MYDbm1DMPiYNarc/fGFD2zBlZJksqVVykpSHJoegbyMZraG1xMAGUhiTcahP/59YtDBJvaGU4wi2nbLJeJKjlH0iJU9dR6xX4SciyAtvDmUWISW8Vvyu7atDqJ6FNlUkk9SbNQ8j5xeUOOjIZFJWy1CxMQElqJuwzDcOIvxhPulfqbzEXfZ1aSWSNDmNt168B6whtuckT11TpoP0iJwTbZRuh3YeLmLw6RNKShsoZnyBk3zAg0MUeExM6XPTKUolSTlUMxIICSWINDDmxZjyUACgKqa/GoirW1puEITpgGLKv8AMC+tUD7tFK20QukqNlhcYjvAQohQbOlJy2GYXIBSQTQ8dQYp+2O0UTZSFIBqsglSQDRIYEuSpq1tpcGEV4113sx3VYDTlFZteY7czC4oPkh80lwbESSLNxhvB4pSFJNLhL1+F62hEqv70EcFfDzEdso2jzo5GmOSJnv9odlSiW11iskCvvjGh2Uvw+ccuZUrO7x/uey62NhpypbIUECwChmBUaJDafvBxiiSnvRRIQLKJDKIUCagBOZtATmOlFJm3BKCUJykqDLSUhdQoNQ2BD+QO90MXtLNLAbKomoFQ3XdfiRzjljFrZ0zlcv4NNiVp/DrKQWCMoJOjgVG+gvBNnzCZKRpk30fMqrRnUbSBkKRZgzuzlnIG+rbzeLbZGNAkpe2VQ9TX1iOTRuJW6F8Tiy3LeB9YQVji9/QQvtHFjMcoZzFYucrdSHxwtG5MtMuJmOLX9OcbTsli/6FaVLc+UfLRiTSkarYe0SmUkWcmm6sbki4qxU1kXFjXbPFBU+RwLnzQ/y9Ynt9aRhJ3wk5Czh60AZ7Gt4oO0OLzTEKeqXP/kPtHm0seDInoKiSQAKUGZSWHkk+zCxg5OLNdRg42Y6Yrlrpf0pAiXRXI7clCvAMXfU6QREnMVBThkkhg7nQdYWKOfl86x60UeVNljhZ5QlYZJSoEumm5NAw1O6AYabkKVs5FWfn9/SDKkDI7oICU6+Jzo3B/SFQjgYEk7Nk2qNv2MxpWtSAhKQEleZ3JU6U2NqfKKDtJiz+Km+IUU3kAIv/AOG0kiZNUaDuxVxTx7umsZXbs4qxM5SSSDMWxYVGYtrHMlU2XeT7VZZ7LxBEsClyQ/M6iB4pf9bO7uUNbRKQa6GkVWGnNBVznUjh9xHQ8f3WQWW4pFh+K8eVhoAfvQvCW0plEvfc1rQKeoFRLxCaMxPiBADm9mD6Q0YU7Mnlck0QWuI956NA5nyiOavURQ50PSV198YusBPZPFyYoJZhvv8AKltffv8AtEckeWjsxT47HMfiSVMXYMQNBv628oXn4hwK61hKZOcdR9Y8Wug5n374wnBKh3lbstZa/BoRztaLzBYtSZIocpfkanhwjLS5nhi1w2J/pMXIBLVs7MGP5XDsI5suO1X8nRinT/wRxUx1E8T84SmTIOtYrzPzMKqIMPCBHJIgFxd4PEBMpCiCRnY1Ao6nqeUUK0tFtLxMsSJYUlS1OslLlFCpQSrMHB1DMG43h54+SSDHk43/AOC2MxZWpyzANyq/1ie1yplkkVWkaaIBb10hVU0H8oB0PDduPNnpBtrEhB1BmbtcgbV7RsYpNJA5XFspl+7RAiJkn28RZ9PnHScO2XONcS6vZLX4WcH0VFUYudryglJa7pB8qO2U2/UjkYpTCQeiuZNOh/ZW0VyUzclO8llBNXAL/CxFebxWZobmoyS21LP1qfSEY2CTbYk24pJk0LFnqecXU3ZKkSUTe8TnU7yx8aQCUhTksXINNzFy8UUiSSRuj6BhdivIRMnTQZakgMkFS/jygOzgjQ7hC5snChvHxc7sx0rBrUHCVk3B0ux/tBMLhSC60qCQQ9CHBNbD20XMvZDTClExYQD4bpcFYTY0d36wziJJRh5hdyEKuSp3Qk0e190K83pFl4tK36MntFXiHFKdG0+cDLMDq4ieJlgtl0DnXXU6/vCym4g8fdKxddHLJNSYyiYXLR7MmOHJa8DQgMSVAW/KTv18oFMUl/CT8q8Iz2NtILLVmo7U4camPVzTQNaAylXMFz1ubD/qPlCvson9pY4aWgo/xDnYnKU0pX482o4QyJn9E8x8/flFMFFnq2/SHJK3A1F25GIygXhP0NYmWfqDoxAIrv6b4WaJTZt/doGpKgPEGo/QlhDxiSyNXonlffEV0GtG8rlong3KgHAB1MNbW2Z3UwpUsAFIUlWigeAdv2jXJJ0wUG1yR2MxSMvhl92sE5sjmWoCgYLUSlT6cNIFtSZmSW/9w/8AQRE4aWwBmurK5ys1nZyb8IkuQhSAe9SfESU1Cmt9IVJJjttpplYBX3wg0iU6kjeQPURKXLRnyqJCf1E24mkOysMEqCgpwFChBSb0NdGrpDzlSoTFFNjm3v8ADTWmem5mNrgDkR/pEUZlqSoBSSDRgddzbxxi42pMzt/qJqWsk3P1L82hLaa3IoQWDig33am6tHiWK0qLeQouTkjzbOJTMUlWXKcozBqZnNQdSdYrHEGmGiW0d/8Ako/UQCOiCUUceVuTtlkhKQ44UPFotE4vwBIYBiH1qoHf7EKzdnrQoBQICgFAsahvuCOkeZGO8Dj+0RbhPZ1QUoWqos9lTgFK0+H/ALJP0hnGhSpKk6qSwO8lAFSTwEI4AZ6gJQBwAdQfKCTbrvrBVSyPEtJYcNLOK+6RCVc9HXC+G0UY2ZMyGgdiCc1C5Dc4rZeHWosEkkU5Hc+kbWXjqMCCNzM3lCkyZLKj4b9BvP8AaKfLJXaIfTxlVMzs7AKCc2+4YhqPexhJUlQekavEy0H4XqwNXNNdwikxWFGZkg+cUx5ORPPg49CcvELQFJScrjxR4Fe/KC4rDEVyny4QMJDHT62iySORtrQZEw/7fq1frHiFlPy9YkJZyPoSCPIwJdPOMcUapsdkjMBvMWmG2ZJmJSr8TLlKZlpmEPmGoBIpFNgl5SKObh7GPMfic6yQAA9hpwidNyou2uN+zXo7mXL7rvcEsAnxlBM27/GFjla2+K3EqlHxGclXhIyDMSN2Uk0YxmDMjwzI34t3YizNKqCZ4Kmc2tITKo4rivE53J2X0gSwsKExFvhWgrTUPZxHYlTrC0zEKL5ciEqTlAYulJNAWsCIou8iSVksPIQrgU+X+C9UuqVA0BU7aOL0qK3I6jepNmgk5k0L2ofQCvBm4R7hphqk3+Kt3830NRXo8LrU/v35eUIo7KSnaCBJanjFeY5i26o4wLvf8o8v3gayw9IBnh1Ei5mwlbZ/oZF5VqSnKh6JHi1LguNGeKQlVCpQA1Lk7hQi5+sU8tZcEJFK1DjqDDi9qzVS0ys7oTZLBhV91a74isCj17Ol+Xz/AC9Gy2HgZc7LLlqGYJKiqjlXiYcmbl5QXtBi1y5aJak5sqRUirWZXEU3xhEYtafzkci3yaCTsWVBlHNz+8R+lfLk3aOj61caSosUYgAPYm4d4hMW7lJFYqZMwBJe/wDaJS8RQR08DlWbQ9+KUHfS1Y5GKJqGBPCFlTARSBAmzRqghZZmy275/BRzcm1YBOkJzsfQ06QCXWCqXl8JD/TrDJUTcr7LDBoSmWUzGckgG7HRoqsXhWNCNdevtolMmJysH3xCWk1U9NSTvO4xiTRrmmqoYwODWvKkVJqGPi+VIWxSGUQQQRd7vq8GwmIyzUEqNCKg1GgPIQPGTlKWtSy5JLl3q++FSlyKSlFwVdihAgaomqYIgKxYg2Rj0GCChH0vFgiUhSQVYgpVUV8SX0ok5sps4BjG6MSsrTBsNMCVpUpIUAahQoecOSZ0jMkrC2ZlhJLvvSrPbmIFPXKOZiv/ACk3HBXjIbiILvVB+O00N7QMrIFS5iVKf4AF01cFSRTRjXnCGfyhdtQQ8GRNChVn1c0IjFCkEp8nfRGeqnX6Hz53hfNBMRSxfkX82p1gDw6JSeyWZo9lvf52ggS8GSABBZqQFYeBlcMLO7yjwSxcxhuwaEUpA8phx07jEWDfOMs2gAcVgiFEx4D1jiit40wlUGlolMWTe44xFagBA84MaDZ4ZjcYlnIvrAVipjwqjaFsMF9YgqbASYi8FByYZS45JgMdGGcibxILgLxzwBYd44qgMdG2ZYV48KoFHPBYBCaR48QeOeCwJhZj0LO+IR0AB0TGrEjOhaOgCxpM2Pe+hSOjKN5MOZkeZ6vAY6Ayw+d7xyiNIBHRoWTzR5EY6Aw9MRj2OgA8jo6OjAOjo6OgA6Ojo6ADo6OjoAOjo6OgNP/Z",
            },
            {
                id: 9,
                title: "야차",
                genre_ids: [28],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGBxQUExYUFBQXFhYYGRwcGBkZGBocGRkcGBgZHBgZGB0ZHyoiGSEnIRgYIzQjJysuMTExGSE2OzYwOiowMS4BCwsLDw4PHRERHTgnIicuMDAxMjIwMDAwMDIyMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMP/AABEIAREAuAMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAAIDBQYBB//EAEIQAAIBAgQDBgMGAwcDBAMAAAECEQADBBIhMQVBUQYTImFxgTKRoUJSscHR8Acj4RQzQ2JygvE0c7IVFlOikrPC/8QAGQEAAwEBAQAAAAAAAAAAAAAAAgMEAQAF/8QALREAAgICAgECBQQCAwEAAAAAAAECEQMhEjFBBFETImFxkTKBofCxwTTR4RT/2gAMAwEAAhEDEQA/APH5roan3MOeWvpUZQijsDiSCnBgKZMCkQJMHTzET7cqKwasKsXBMVYWrqjQ0BhFgFvlUtsc6dCTRNkimywTHL5/Kp7GLUkATJ8qrrGEdtlPry+Zqw4VgQGJe4ogbDxHX00p+PLJySJ8mGKi2FXL4Ua0+3i1OwJ9qHx2MtBoClsuksefPQUxcYzEKsKD00qlepalSELCkk2WjWYGZiFHnv8AKh7uJtDmT6DT60Bi8TmMToNv1plq1m0pkvUzcuMQowilssRjViQIHU/1oe5xIHmTQuNP2RsI+u1DRQZPUyUuK8BqCa2GtjV86j74NMTpQjVO65bfm37/AH60r4053fg34cURtiQDpM/Kh2cGaY1OcQnqfpUspN9lEYpAr3BXbNrMQBT8Jgbl1sqKST0H41pMHg8PhU7y4RduD7I+EEjmRv7fOppSLI47V9IrcBwC5eafgtjd20EVbpjsLgxFpe9u83OwP7/Yqj4px+7e0nKvJRoB8qqmakuEp/q69h6yQx/pVv3L7G9ort0yze3IVyqS3So44o10BL1M77ICx5aVIuIbnr60QuFQfG49F8R+ewrhe0vwoWPVz+S/1rmYteaG5wxjISf8v6UZZ4MTEsLc/fMfTf6UG3EbmwOUdFAUfSm2m3Y+1ak2zJSil1ZeHAWlgZmuR9yAPnqfpT7WNC6LbVYGhPiPpr51R27xGxNFpjXAEwZ6iabF7J5q1S0dv4h2+JifejuGELbZjuTIM9Ov1oI4lD8SR5qfyNHYtEFtUV4J1IYR+9fwpsJVbEZIOVR92A96TrzmacjHlUv9j1mJEbgz+FMRQAev9aXHJb6ZRP0rSttefPsPYlj1J/YqxtplTX1JofBKA4I5UTiVzKRV2KXFcqd1rRHLE5PjaVNdsqXeSTXbbx5+R2rlyyw3BArVdiux9vH2LhFw27qXIzfEpUqCsrvuG2IqeU+O5DYY+bpGfs3VYwUAND495aOlaLi3YfF4TM72+8tqD/MteJf9w+JfORGu9U2B4U90FyQlsbu+g9vvH0o5ZlKC2DHFLnSRXqJOgmeVW68LVFV8SwQAaWx8Tc/F0rlzilmxK4dcz7G6w1/2DlVHi8SzksxJJ5mpZNv6FMVGP1f8B+N42zfy7Ki1b6Luf9R50BxC5svPc+pruCTdjsPyoO88kk86HiorQxycnsU00muGlWGUSWzXa4m1drgRGo3FTmmd2axsYkRhKfc6dKkVIrhtHyrV0C+xtlZIA50TiSM0dBAp+CsRqTr0rpwjEzI1PU8/ajUXQqU1yIrIlgOpp+Mv5mPloPapsPgiNQZbUADzAA9TJOkdOunp3ZT+F9mwovYqL93Qi0R/KQkTDDe4RHPw+R3otpVR0VGUrsxPZDshisWRctoUsg63mlUMbhObn006kVtcV/DiF/l4rM/S7bGU6ciplR561P2s/iK9m4cPhkt5bfhdmBIzDdEUEQF2+fTW9s4p7iq7AKYBZZmGyAlQR7j2oHDJplGBYptxZ5jwLAG7jBhXtd3dLZDB0G0tB3GXxabitbxj+F5to9047KiKWI7nkok/4lWnAuHpc4rexPJLVu0D1uFZcz1Vci+9bLG4lEtuzGAoJIMagCSOp9BTJZJ0op0LXp8duTVnhfAOzN3FZ893u1WNYzyTJjRhtH1Fb/sN2UuYPvWTEo4uBQVayVgoWynS5/mbfy6VUdmWxas5u9zbW7ca6y5SbxL7AmYUQABImBWsOPtLbzs0KFzEz0zTOnrRSqSpjcGCPHktBXEMNdvWXtNcQZpBOViI2IIz6g6c6887RdhLz38PZOMDteZgFFkqtu3bQs7wLhkA5VjSSw1qS723xhZ2s4dRZElSUckIo3cyBOknWrv+H127iLr4y+VY5RZtZVKhVBzXDBY6klRP+Ss+GvYGTjVRZluP/wANP7PYuXWxQK2lZj/KjMRso/maSYHvXns17J/GFLj4YLbAyZwbknWBGVQOfiIP+2vJbGCbMAYrJRdrRJjnp2/J3EmLYEbxMDp19TVfFH4rDsWOogaVHbwxB1oHFsdzivILdHLpUZFT3bJ30pq29aFoNNUcpU8ilWGWSEUhTrhHT0np6xrTCaFDGdan26jqS0tHEVMKtLRCJ1/fvTLYAFPtnWqYqiKezQ/w24WL+PtBhK2gbrDr3cZf/uVr2fiuKFvD3roUkrbdsoG+RSY+leM9guNphMWtx/gZWtuRrlDEHN5wVX2mvacJjUuKHtuHUgkMpBHzBpc7TK8HFw+p4n2S4K2LxKz4lnvLzcoksQ3mx09zXoHEWFlLlxjopzHqSANPM8hV9xfiFuykKviaYt2wsnqSBoBt4jpXn3EeLWrt8LibqkZp7tW/kWyo0Nx9DdbSI0Gu1a5uXSOjH4er2zUdgsMyIGfRmJdvJn1Py0HtUf8AEbEra7t7ahsTcbu7Z1JVR8WVToGzMonz8qr07V2rSO4uIzKpKqHBzNHhEA9arOAcXGIuHE4zEWw6ApZWUWCdWfLp1gH16CtjFuV0Mm40sae359g7DYNrdsKWJuv4rhOsnpryGn486iTiAYlVI8CKHJmMxzeECeW5OvKo+PcesC2zI6u+yiVJmdCY5Deq7s1esrYZrl23nd2LBnXN0Eg9Tr701ent7eyh+oxYuML0u/79TvabjLd06qZFwZdupXSfMBorSdjLRtW0tzoB5byS3zJNZTGLae7bTvrYQTcLZ1gZQAi7xMtt5GrfG8cs2cPcNu4jXSuVArBiC2kwDykn2pzWPGmrt9Hm+p9byk/hrtUvsV/8RO0iX2S3ZcsqMS5AZQWHhETE89RptWXw+JIBZgGjQSOZ89/rQ6rRF9ICr7n1P9KU1ZPF8SDwE/CV+v4j86iewD8LL6HQ/XT61KUqC4lA0HGWwbEWGWSymOsafPahpovvGQyjMp6gkfON6mxXFXupluC2zD4WFpFeOcvbCluWjZtztU8rsqhTRXOtKnFKVYFTOMPLbf32rgNFYjClSQRFROkE7e21IjKymUWiKpl36U026egp8CeaJg/78gIqe08dD+/p7ULmM0Vh8CxGZiET7zaDzjmT5AH23prlQh42+h2adqtLHDFtjPiHKA65B/et7fYHm2vlQx4qlrw2FIP/AMjavPVRsm589d6r3vk6kknrMzXKbYDio/UucTxsle6tKLNrmq7t5u27HSqxyNInz9fL2qJXqbDAM6g6AmCZAjzk6D3o1roCTfbOB6cr1Y3eFWcrMt0sAJB8IkZSRIMGdvrTjwq0GCm5G25TmYOx15fMcqNWK5x/qKtmrvKjMPw9Gtq5uDMWgrKjTNG5261Dj7C23KqcwgayDuNdRvBrjrTdIGIrirFSVNlmiSOcqO4RJPkNT6CuXDmJPWiEUBD1Yx7D+tRkUdAORC4O/wC/f50OyHly/wCPzFE3B0pjUuSDgwG6n9aHmNOVG4hqFdfL35D1pE0VY5M5aPWlXbDajfff57edKkSTssi9F4FF63P21Akcz5jrVRdQTseQ660XhMWFYGY6xBnfz2mpOI2Vde8TY7+R6VLj06K8nzRvyVjHr+9NKk4dgLl5sttCSBLbBVA+07NCoPMkV3DsuYF1ZlG4BClo+zmIOUHrBMVPxPizXfAqrasgytm3IQf5mnW43+ZpPSKrjZG6JwbNnmL1wc/8IekwX9dB60LiMQ1wyxn8h0A5ChKQamoTNt6HzBnfb96+VcBpjOf3tTkas8gNaJVNSoKgU1YcN4mbLEhZmJGYjQGfnpz8+tHETK60CXK4u8fv3q1Xj58MoNABoY2Ujp5/SoMTxgupXIBJJ3ndw/Tyj5Vrr3BXLzH+QHNT1erMdoiGDC0mwBg8gdB5emvI8qFx/FBcRF7sKViTIJMKF6A8uZNda9zlyb2v5I1M+dSWiSQB1/GhEejMKYBc8tvU0xMFxCbzeLTZRA9qY5qG20865mpli3EeXphYf8b8v371x2oe5e10/AUEpBwgJl0Pp8tRrtHl7ihHEUVbnTTfadPeT70jhmb7P0/fpU85Irxxd0BWIzDNJHkdv30pVb4PgF1iISZkczrGmx9KVRyzwTqy+OCddFdcYnaY8xE+ZEmN6J4fichg6qdG6RpB/fSg1PvXGf2rYo1yadh3FMMFMiIO0dKAuXP2KO4diM6905j7p6eVV+LslGKnlTovwKnFfqXRzNvSAmmL1p00aEtCLVIjVYcO4C90Z/Dbt/fckA8vCACzfKmcd4U2HcKzo5InwyCPVWAIo2mlbFc4uXFPYKpo3A4JrpIWNBPvyHuflzqtDVItwjYx6GuTMlF+C7Ts67BTnAzAHUERIn6c+m9Sr2VcgHvBq+WMp+8Vn6VnWucuVSHFMRBZiOmYxW2vYW4ZPEv4LxOzTG69s3VXKFMlTHjMDoR6x+Uw8R4EbVlLveBgxAAykbqW32O0VU277DUMwO2hI0HLQ7U/viQAzMQNhJIHWAaxNHcZ2t6+x1TU10kBV9z6nb6VHh1Bby5nyHp+9akVWcyAZJ5belGFR2ypOkxManQe5qW0dImfL5/rRFjhh3aF9T+VGL/Z0EEgmZ039PT9a55EjVib70VRtzsCf35bUVhuCXniLcDqR+5os8fRP7u2Aep1NA4vtBefdyB5VPOc5dKimGPHHt2XGG7PqhXvryrGyrq286ATrVjh8ThRqiG82ol2gEnXrPvWIbEGZLGdwfP56U/DYt2OS0CSeUjyJ8htUs8U32ymGWEekek2eNEAMxS2NoXfoANJ8udKvNMXj8mjXFY8wpJjprEfU0qll6N32WR9ZGugAtPlz/X8BSst19o/f0pMhJGnyqMsZq6JFJDjPWrFAL6R/iKPmPL9/lVZNOsXyjBhuKZ2LTp76OMCPWn4NlzrnErIzDqBuPfarDHWM6C8oOo1Ee0jykH3FVYWdImeVapATjWjW8Z7UrCmzbIM+BnHgt6ZYUAROkSdRPlWTAu37hJJZ99ZJMCYEA/pW47G4XC3VtF7mcqGN3DsMqkq0W/E28yPCpk+etU3afFE4l2thUeGWEUeERELA0JBIka1k5yl2DhwQxLS/wCygBpTXVtEnKFMjlBmekUUuCYDx5U00zGCPOBqdqPkcoNgs0/MABGp1mRoOQjqefyqSLK7lnPl4R8zrXf7dHwIq+cSfma6zuKXbO2sI7fZPry+e1SrhlHxuPRdT+lCPimb4mJrttgYEGZ1O+mkADr8XPWRRJgtLwiyXEWkXwrmJ5t0Hl+9qY3FH5eH00oC6+unLSm56OwXYY2JJmWqNrhqNQYLR4RueWu1Nz11oymSE1wLoTI0jSRJnoNz+VRlqjZq5s5Idcetr/D7s3avYbE4i/de2i+FSjAEFVknUHfMAB5VhXuaR9efpW17A3sM2H7m+DBxB8XihO9sG3b2GWSwbePhHMCkTeh8I29mIx9pQ5yFivIsNffqaVFY1Lec93mNsHw54zEDm0ADXePOlSQuY2881Pw7A9+8ZktKB4rjmEUTv5k8lGpPzAd4MInntQ91zty39+tahsrNjg+EcMg95jnYjWUXIpGmyurE784PlvQXFeDYUoXwmIa5kWXS4qq0SASpB8UTMQNKz39keQCCJMT+/wAK9CwnFjc4ZfwjJ4LaFkuLIg24um0fDEMEM+KdjBgwakvYS8cvcxvCcVkaCfC241IPy5/v0MucGus47u2zBttKrUxpX4FVPMCT8zWt7IYlgly/fYlSAlrMfidzEekrr5A+VFCLlL/J2WcYQ934+/sd4X2ZxVh7TBgLt1hbFtIZgpjO7EjKMok6T6ihbXA7lq4xvKyuC0LILED4ySJjca+Zjy0eS3fuO10Mypb8AkrMsJnTNLHYb+Gh0As23uEAhIRVkZWfxTl8lJKnqQTV8fTxT5M8qXq8jTh5/ukc4twWxdtqbVx8O8KsEfy2ZvvxBTrInfavPsRbZWKt8Skg+RBg67H1rQtxS5eutmaYJ8I0USYgD0A+dVHHB/NJHMCfUCD+FIywhXKPuUemlkT4Td6IsJgWuEAZVkEjMYmNNPeo8TZKMUaJHQyPYitjh+FHur1zEWLttu5C2HtiUAtLLsfFEbA/kaxVy1cnxAyeu/P9DU3NXRWoy7fRyamsGAW6aD1P9JPtQ9FY62beW2dCAGYdC4BA9ly/Wis2vJDNE8MtZ7qLlLSwGUbtqIUf6jA96htYZ21VDGomNJAkgE6SBrFWPZlu7xVhiQAzjxfd18LTyIYA+1F5Fz0n9i4s8ExWPvPb7xFFpigUCEUruq5ekRPOKzePsNauPbeMyMVaOqmDXov8NMPbcXrly4UbvZJmJCBzcJPPNMmOg5ViO1vEBexNy6ls21JOWRBYSZZupMkegApcW+TY3hFQSQLw/CNedbdsDMZJJMKABJJ08IAmTr5a72t3hWHs2s91mc9A2Uls0QijXQSSW6DQTpVcEvEXQgcJ338sudlDsBmM8hoa1P8AEa2bwt3RhzYsoO6tsx8dwpMk6SSIMnqdzWynSEuEnJK6X8mUxePw5gJhyOpNxydtY1ga9QaseznDTdtXTbuLBa2O7ZmBDZx3bNGh1LCYO52NUqWQEMgTB33nlFE9lCTibaTo7AMORAOYT7gUtTuyiONRrevq7I8X4LjoxBZWIJUypIOsGlV/224aiBYVc0hVCaADmDAg6kelKh2ZOML+WRTnBtDG2khYJJMnXoNOnTpVe9l3PwkmNgNgOcAbV6Uez9t5OHxVl+gIQN7SJ+tUV7gl/D3kulCch5DcGZ5QdCd96kh6tN0z0Zem9ivvWYhmOuhI8wI/CjcNxO4EW2HhEc3Y3jIjzI5giZHPaDsSOJ8FYuGTRWOx0yn9DVX2lsYjBXWtMqqHRgtxc3jRwUfWQJgkEEafImjHbVic1J6RQFpJMATrA2HkPKrGzxJz3aH4bYJQRzLE5j1OpE+QqqU1YWHB7sDcI0+7EgH2NVQdPTIsiTW0bfs1xjMrs394gVuUwQwBE84H1PWqbEcVN640KFtWwkDkSrgSepOv1qv4R3j3WRXyBsstMSqkAjz0J09auOO2LXcThwcudFfmcwDPl084286sWSTjfjf7kDxQU9duv2XuUGDvnv3gAksYkab9OnPWuY8E3CBJ005k+I7RQuAYq+Yr1MzlmY+0dANR86JxV4K2ZT4o1ysCNwZDKoBM8x0NTcuUd+5Vxqdr2N1g+0Df+kXsLfuW1uKgFsNmDGy6jKpCwSQQw2OwnrXnuPxXetO4CgD2p+LxzXAC0FlEBtpEdB6UELhCwIAJ16mNppMkrtDouTjT7EanwtprtwKD4nOpJ66sxJ9zTntqbYYaEbjrrHtH50ZwO2ypevAGUUKsfec6wd5ChtuvsSXYLfytr+sPN8tdS2qlls3UAg/YkLAA85mN9OlUNy6HIBYKACJ11gkg6ddqOUtZzG5Ks6K1poEMQwcMDBG4HrVdfuEovQbgAROpmfehk7OhGjT8C4vcayMOGy2s1xr7krLkoQqqB4iBv5npGo2Aw1u4+W4xMljrqIzZQB7giQenIVWY24rLbVVUOigFlO8gcuoMnNO7VNZxAttbKnnG2gCToRvJJJ+VHBpaMyJv8f4B+J4XuL5RhmCsDBPxLMgSPLSfWth2o7S3MXYtm7DatcDJ8IVzASCSylWDjXQmY0FVn8QcJrbvLBBUKWA3OUEE9PT9dAeyTPddMMIKFixnWJUAwOZ00PKSdprMsN0jozagpPx2M4dwy5iGIXKqCAzuYUZiAB1ZiSAFWSafdtYfC3Va3eZ7iGT4REjyEgfMxR+NS673DaH8ixKWydLa5TDXD94ksdgWOcA1k8RaKmNfWCNee9ZSjHrfuam5vvXsv9l7xzjHfd2xM7n3lYn60qocMdY5f0rtLsasSrofbxFxDILL56jofwI+dWOH7T4hPhuMB0JkH50MnDQ48DqTyViFJ8hJ1PypnEuD4ix/f2LtrpnRlB9CRB9qyWFPbQcc0vDPVOyvaC3ds2zesi7cYgACZMDxMQugUaST1qw7TYfB4zDG3dHd3rchCfitXBOddPiUlWBHMrO4rHdhcZ3N7Dm4TCI2UeVzMCD0EOfkKr8VxVmzXiRIxDuRIkyWugETtmZxr1NPw44RTi/YVmzSdNe5UXOBE/3Tpc9Dr8jB+lPHC3t3HXKx0Eab9TG//NSY3DKuJzWWDW2Oe2QZjNrlMbFWkQdYXzEpeJ3E+0YnQGGJgyIBGw6mgUZQV9mznjnpWrX3HcPtFXXMpAIY6yJhSdD8tuoqwusttcwuG5oHumY8bqAqzMysyecig7PGbUgXbStA0YEgBioWMq+QA9qFxVy1dYZWe3JEAjMNoEtpOnlTfiJRpoQsDcuSf+iXhvDw91f/AIgJzHNEHrl1H/FDYy6Ll12aSiyPiJ3kLqden086tcHhGW2bVu6DM/A0QTuI0JHr+WtTxHDNaUIUZT8VyRz+zBiIjb1NLWSLjX5/0MeOSly8PS+nuRthVCqS+rA6EaxsDHny/EVFewoAWGBPw+89Zg/1FRG+DHh11kknWdpHl5V1CGnOTptEbdAP3tXWn4OprtlrjLaomUEHwmN42G0aTzrvDAWs27IkZ7jMxAJJVVC6agECGMVWNe8O+sR8x6Vf9mL6d5hxcPhFm7Gw8Re6ftCNo9/Ojck2KUGo19Sm45i+9fT4U8KD/KIA9NuVN4ViQjA5MyBlLLE/DqTI21HyNR3AmZ5mJaI5a6eR3+lE9nSwuKwcIAy6lcymDPiH3euopV/MN1GNewTxjhd21cZ7tk2Q7EqrAKI025c/r51VY3E52B5KANOfU68/0rccWw2Ixd1bPdgrrkKkkQIzMhZyFUBQNRA+VVfFOEYHDXmW7cdoI/lWobLoDrcYgHedvejpioZV52/psL743+HhXDKwhFJUAMQ38tVyjM2gGwkmfIErDYJcJ/LWO8S2bt5joQf8G033SXKMw5Qo1iTS2e01i1cW4mHa6bZ/lm9dkLp9m2ihR7z865/7t1vXFtZbt34rhcsRruAVjntpsN6NSV22DOMpaS1+wPxjirC1bsIpRLY1JBDO7GWeDtqTHMDpJFVOBSS09Pzpty+TMACd8uin/bsD6RU/CgJb/SPxqbJJtWVRiloenDyW8Inb5Tr6UqPbwq7A8o9ywH512kqTHwSrZXcCvIj523Gx+7yzfWt7wHjeGvd5h8dDYW4AEuS02GWCCCp0BMaxyEyJrzXFLDsBtJj0nSiOG3IbcgmR5HQx6R71RdaFx7NXxjgiYTMcPfTEWA0C4pGZcwzKrr6H4llT5HSsvYfMt4RJMOP9pg//AFdj7VoMJi5tXbbWxNwRyEEm48wfhjNbI/7aDaqXDWBZKvcMMdkGrZSCCX+6IJEb+mlGnYuUVF37lv2XxPeW+5uITaSSDbQ94rNoXzgHWORB22FFHsfh7jlbeJvodu7uYdmuHqVW2czLsZC86zzY8MQDK21MhBETyEbHz6ya1/A+119LeayAt63JXMuZSgOZrYnXUDWOggg606MVKNd0SylKEk6pN760ZXifCzYdrYvBog+EEfEPtA6ow0kHXUVDh7mWJOgMzBFehdou1Xf2RjDYwvfoqeIor50ZVzrD6qyMzgGfskayKxVztbiDmKsFHPKiroTpyNK5RQ6UZPXZTKXLaBj5AHrWksYrEahEdyPhBRnVlAGh8xHX8qrr/aDFg63SfCG0yNowBEwNN9jtXLfaXEz/AH7jzAXTz0FLvXQ6Lkn7Bl9XcfzMA3qlu6h9hBXr+9Kgu8FQk5UxFs9HtMw+aj8qIxPHMU0Ml95JAKqdmO0eRoAdpMWdr9z/APKgW/oFKUl0k/uOv9mMQACq5x5Ag/JgDUvBrd63es50ZdHVJVh8QcHYTux9N6Zb7UYtT/f3B8vzFG2u33EFAjEsR0ZLbD6pW210Ct9qv3sztiCyhz4Z1IiRO51I+tWl7AIbi27RkAS76RGpMEMQdjzGulWX/ve6/wDf2rNzzCKjfQR9Kc3FbN3QC1an7L2vBruZRo+YrFL3Rkk/Bd8bv2U4clq1eV775BdZTDxlLZCNyNpOxPsKwF8s8eGY58zsNTvEAacq0H9iZ8wVrZEbocwXYCVALRr0NG9nOGrhcR3l5wXVEe0UBXM9y4qqo7xBplDz4YgnXnRRbk9sCowWkZJMC/QD1PWpRgY3dR6Sa2Xb3GFrGYgl7lxGcMCMoVX3HOWLH3rApq2on3iiyQcXVnYp848qCf7MAD4x8v60Rw+1lcgMGkaxHy35UBbtSNidY20k7CZ38q2fYfs4rE3bzZLds/zGiQJnwL99zEADQROtT5Hxjtj4xvom4bwIPaa7dOSwsG5cMcjOVZ3c6COUydopVF247QC9kw9pe7sWx4bYJjXmx+0YOp6k0qHHCTVs3nGOjH8SH8zaJCxpHICfpvSwWFDHxGFAkt5DpPyqbijao2hlQdt/XqNtKgu4uVygAayYAE6k7CBGv0HSq1SexW2tGgtjDsc/9qe2RMZbYnxeebppVPxXDWlINu93szMrBB5bEz/Sq+lRSlFqkqAjCSlbk3+AjBXgp1AI+o9K0XBsUq3FcDSRmkkyOY1rLqRrvPL8510o7AYsj4joPz/rR4J8XTF+oxcosJ7S2+6vXLSghAQU10ytDL6iCB7VThKuuPEuiXBqVGRj5DVD8iV/2iqkDTz5/OlZI8ZNB4pNwXv0RzHkaltXBzNRu+8SAeU/j111pswf11oBlWWmDvhdW1T4T0IOpX15jz9TUeNtIh8PiU6qRzH6jYiq9fOYo7BXA47tzAPwk/Zbr6HY/PkaxoJRTVNnMHh++uKi6ZjBZtlAEsT5AAn2q0u8SwtkhEwYuRu913zP0IVYVB5RNBcPm210ONURlg7BnIQk+zNr6VXXbhYksSSdSSZJPmTvRJ0gGrbT6NCnaHCkGeH2Z9X1+ulNPHcId8Ag/wBNy4Pwas5SrbYLxRfl/lmnXi2EMC3YNppENmdwT0ZS3iXqJ9jV6e1GfGPdueJUVAveEIfCSCUSecmANANzzPn9pyNp9RM6T09akvkkKSSSwJM7/ERvz2Nap09oz4Pi3+T0njfc4uzmtgEgaKhAI1mTEg7/APFYPEYBFfLnyE/ZYdTEAienQUDbRhqNPPn/AEq5wPDC6hnc5/tTJyW40JY82zaAch50GXInt6GYsfH5UGcA7KXbiXLhZVsqQWYEMdDsqjxFvlTuI8f8SW7Xhw6BgqDTUsczt95jGvloNBQ3EryOuVDdhYyjMiAkaTlAPIQOmlDvxq6EtqwF0a+G8qXNyftMuZeexFJjDntjpTSXGINi7wZiQZn9TSqFbyFtVAXmqEx7ZmJpU5LQiS2TYmyWtWiB5akDbTUnbahTgTkLl7eh+HOCx9AKu7PFLJUobZVTzBzld/EufXmfDzHOq/F4TLzBB+F/hHOQQQdffTXeidVZvTaKsqa4TRjWFie8WegBPprpQ5tydx19qGzbREKNsWSWAUSYk+Q5k9BQrpBIOkUZw6xcckLMNAI+8AQY9NqJOjJJvSC8Y1xEK5VylZLc99NzvIGw5VWhSBoWg79D09a0/Z/G93cy37S3FIMKVzakHKApO8begpcUweER85N0pJBU3EDTvlhEJMAj4stMlUvmv/wSm4fK1v8AyZbPBGk+us+tRVa8Uv4d57q01oidSxYN/qVpKn0Yjy51WOxOpMzvSn2PT0MmnKabXa4402FAv4W6+X+ciqmn+IiHMxA+8oyz5VmyasWxT2WtBTla2A0x9pgCZHPw5VPWD1ori3DQ9lcZaH8t3yXEH+FdImP9LakHyIoW6dGrabKU29BXLYkxMedSOwAgD1M/gP1qBa4wJt3cjHWRzohbU+LKYJ5AmNAdY9aHv+IzGnLX8NKsOGYF3cQcqKJc5iFVVjMXI2H1OwoZV2FFWWvAuDqVZrhAAXMSwIFtJIzMCJdjBCoNyN4BofjHF0YZbSFbYEqzGS56vGgPlsKi4/x43jkQnuVJInTOxAXORy0AAH2RA9QO7lSw0PPoaVx3chjaSpB+L4gMoS0IA3cgZ3PXT4R0A2qrxDRE8h+elMwzRHPy6+Q6GldcHlGkevmfnVCJ62MBykHTUHod5Bnoek67EcjSqJqVaGS2Y1kxAnbUkbAH7PrRHEnkAknUAxOkkSxjlqa7aWyD4y4GpByAk6CNM+moYc+XtziDqQApY7RIHwxoTB0PUVhrQHT7TaMNNj+/rSCSBEk6kiDoBzn5+lNt8/Q1wLFd1JPUn8aOfFQgtrlA5kasx8ydh/lEDrNCXtges/iajU1xtk4vtrDHxaEzqRzBNRwK5cXUxqJpuQ1tA6HO0+fnUVPpoE1xooonh1oNcVW+EsM3oNW+k1B3dSYVJI3AmCRuJn9DXJHN2tCxVws7MTJJJ+ZmjOH8Qe0HUZWR1K3FIOVwwBEz9pSAVYbESJ51009WrOzukSMxAB01BHKYiDpy33qCR0p9wa6kH0/pT8PZzEdOfSOcnlXUaiXC2ixAHqSdgBuT0FT4riAydzbkJILtsbrDYt/lHJfMneoMTeGXKmi9ebeZ6DXQULFZxvbN5VpE1q2SNP36/Sp0vQIINOsYIFQTOuv6U44Eedc4Ni/iRQKiKJnN8h+tccHlqBrtqB5x7fOinwgWRpsNoPQ6HkdtvMdaju4cAxoa1RZ3NMDNKiri6RrI+EzoBqSI8yZpVtG8kWljCCfsjTmRz9afw+xbJuZ2VQGgSR05VSMY+315mm5utHzS8AfDvyapBhl3vINOWbnuNqE41icMbTLbcMxiIUjmJ1IrPg+VPBHMVzytqqMWBJ3YVxzEo5Q29AEAPqN+VVoNEm6Igrp1AE/1pt1fhM78tNIMbDbbnQNtuxqSiqQg2XTQ86731Frbw5RZuOjic0JmB6Qcwjly/SoXS1rla4TyLIFA13MOeU/Oi2gNMEUV23pTitPwtnMwXMBJ3OgHUmhsOhjvpRGGs5VzmNtBOvr+VEO1tTpaBjmWJ99Gg/L5VHisUbmhXXlAgD0HKi17gXekgK5qa6kwI5aidv3tXWtGSIM/hG9GcI4Vcv3BaQakEk8lAElmPIDTWlt0Gge3ZZ2315k7ADmegAp2JcAZUPhG55sep6Dy/YLx9iJtWlJQbtzuEbtrss7D3PkF/wCm3PuGtps1yitWRONv3v8AsUw0U2DYmMpkaQYH4701sC43A+dbTBtDxxFgANPkP0p68QY/8f0qAYcjkPLXnTTI5j611sHhF+Ag4snpXGv+lClj5U3vDXWzvhoJLilQ2c0q6zuAacN0B5fhr9aQwh6fjWm7O4EYm73YYKYkShIMb89KtuO8HfCIrm7mDGABbPSeZNVxhBx5eCGfrOORYr2/GzCrhyOvsKk/scnnPnNaGxxlwYKT/sjWrvhmPtuVVkALf5dAfOaKMMUtcv4GOfqF1G/3MZY4TmiXUDzn9KsMPwSwCCXD+XjCny8MH61vON9nLdmzbvXAAtwgaACJEiacnZNGHhUkGCCQI8Wo+hFbL4GN7khV+qn1FoxlrgOH+8vpmb9aucB2CtXEW54FRnCrmzktIbxAzESpHLWrLE9i1AhV8XtExPTWKhtcHxFgALiGRTDKCSV0DAeEggRmPzpUvU+n6i1f2Dh6b1N3K/yQWewiNdNrJZBChgxDGQz5F010O89DsaGxPZBERXNtIfIAYiC8nc6GI8quGwuKFzOMSxlQMwCjQGV0yxvqGGvpTcZw/EhEnEF1Url0AIK6L4hqSJoFmxN9r8DfhZV2n+SnPYJA4QsAxBbxFxoCo+y8AS4AJ5giqnG8Jw9u41soWyEqTnfUqYJ186vsauLEGRE7KVUbg6hVGug+Q6VU3lvksWWSzSYgkkmSRz60SljfTQyKmn8ydFd/6XZOwI9/61wYAKjW1dlVoLAEDNl1UMYkgHWNp13AqxxGFvR/dxpyHIDU/wDFBtac6wfOR9KW4Nyu1ResuCONLi+Vb9ga5w9gPDecerVDdwTAGLr6GNT++VEsSJnc7imG/wAtNdY+tdwlrYLzenadR20610/AD/ZGP22P78zTThyIkyBsDtvMR0mfrRLtPOlbtKdS1H8NMgc2lYC+FpDCr5/SrFcOPy/5ppw/SiWIXLP9QNcGn+b9Knt8OtvMA/p9f1p72TvNWHB3tqGLMJmYOxApkMcW6aFTyzUbiysbhA6GlV02Msx8X40qf8DET/8A0ZfZlv8Awa/6xv8Ast/5W61/8bf+jtf9w/8AiaVKoF+hD3/yJfsePWqvuC/Fb9R+VKlWYv1I9SB6n28/6DDf6rf/AOt6fhPgT0X/AMFpUqi9d4HYPIzG8v3yFVPEPsen5ClSrz4fqKJdBNn4F/7Y/E0In/8AS12lVWMRMFOz/wCoVEnxr7/+ZpUqJdo7wNu7/wC0/gKrMZ8R9D/5LSpVbHwTyKS79v8A1D8Gqru8qVKqPBO+xjbmmpsf3zpUq1ASCk2P+r8jUZ3pUqeuiSXZJa+NfWgRvSpVj7Dj+k6N6VKlWnH/2Q==",
            },
            {
                id: 10,
                title: "Encanto",
                genre_ids: [16, 35, 10751, 14],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGCBUVExcVFRUYGBcZGyMbGhkaGyEaIxwcGRoaHRsdHBwaHysjGh8oHxoZJDUkKCwuMjIyHyE3PDcxOysxMi4BCwsLDw4PHRERHTooIygxMTExOTExMTMxMTMxMTEzMTExMzExMTExMTExMTMxMTExMTExMTExMTExMTExMTExMf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAECBwj/xABFEAACAQIEAwYEAwUGBAUFAAABAhEAAwQSITEFQVEGEyJhcYEykaGxQsHwFCNSYtEHM3KC4fFDksLSFSRjc7IWNIOio//EABoBAAMBAQEBAAAAAAAAAAAAAAIDBAEABQb/xAAvEQACAgEDAgUBCAMBAAAAAAABAgARAxIhMQRBEyIyUWGBBRRxkaGx8PFCwdEz/9oADAMBAAIRAxEAPwAXD4dy0bEiZGwHMzQ2AC57wuFpUA+EwSdgfIaUe+MDr/CVOx0kE8upnl6VNiOMW/3a90Aof4mgtH8Xl/pSDkdoA2kRNtbc21BuE85Y5TrOuk760Be4wPHoBAygeekyfWmlziloOQokzuZGY+InQdc1Lcbh0ezKHxknNPIciAN4g/SsU7+abYnPDsSXv4V9P77ZREaD50sxuKVcRdLTqx+5orgVsi/aEkxcn5W2n7UoxDg3HPU7VSoFfSGfTGdh5hoB3KgnpRVjEW2zC5cdSvw5V0M9ZpCuMZRlK6ee/wBdhXQdSYzEEa9ZodO8XUsWGQmSfECNPOsGDU6kQR1/30qDhryvgMxzor9lLuJgZue29ERMqBPYBOkidYG1FcPuXFYFW23Bo7H4ZFKhXDQYyg1LcwltNCRmPIH6TRKwq5lSLH8YuMPD4esVxh+L3wCG9AxrEjMQN+U61neZv3bAGDMjQVusXNhXCMU2SLlwEkyPSoOOX8sFW13EVq5h1I00oQ4Ygjcjz+9F25nSW1xkxDDXlQ+O4n3mirr5/WoMYbaTnYL8vbekS8ZC3BmtiAec/UHehLC6m6Wq42wmNuWmlHZCdyDH+9OsL2txFtVAKFV5ZYnXcxzpJ31u78IE76ev2rVvDATrPlWgGCbEu1ztfZuW1S4ry3xhToPfmKdW+MWFhO9WdgC0/U15gj5dCB+ulc3Inc+9FO1GeuYHHrcUMpkH8qLTEVQOw/EWBNpnXLHhB0M+XWrdexIVSxBMcgJPsK2rnK0l4nhVfUaedV7H8J7xGUmP10p81yRIpecQxcgrCgaNO/URXb8XCNGU04QoAvID50K7nQ6+hO1PuJWMyKR0386SXcA4XMdZ+tEqwGmrl6OYPlXNu6N2HOoTh3iculRA6b0WmoFxiMeRsdPPWprXEhSZzy/X0rU8jTFYgVcyWdcWG1n9DSt0v4c37tdBz5+ZrdLLiOAMC4jjAYy+QWDqQBHLrSPG4ozozVNYWQLjkAyRAMMYH0oXEYfMC8aTy5TtXnouk1O0zX/iMBZgx0+tTLxhhMSA2mh5dPKlbWoOnKoyTOlO0gzqlt4XjQXnKABmIOo/4ZGpmkQvhHzlQYJNGcBuHJc/W4NQYeyHJzba6/b51o2EYOBB72KzkltyZBGw8jUdt2DcjRRtIs+elEPw12AAXKInXT31rQDMmWmcHkuoOhgT505w2Na7vHSkVvBFRmM778jU+HeIykb7CsZZhMcYkgEBTr5VMmJYaPLHr0igb+Hcn4gIOuvKojcUSs7bE8opN2JkaLig3wkE9enrQlxSNVM9QOfp5UvW4IADep29qiv3WUeHaQJHnPpIEfWsF3OAuM2x+VQzGBOxPIb1Xzfu4q6RaVt+bQBPU7VzxYBs5+KfxAgBdBoBzPh19RT/AAnCsPZw6d+5JbXu82WOubKJ9tI8+XM9G+5lWPHe05fsfiHthhiLTMN8rlyPLMAYO9VnimDNtyhSCPw5sxjrP516VwHDWls3GsqFBEnKSQQOck8qqPaC1bDlrgGc66biRpr1jly9ZAVjyMWNyjLhQICOZWsPirlphuD19dN9qsPCuKu6gKoYr/MFJ8oPxGlXFMIO6zo2ZZBHlrHTUUHavFSsrDTPSq1e9xImWtjPQcJh0e0t0BmVhOgjegsTiNChUZeR8+pqbsZjXuI9s6IiggkQASVUDzMuKg4jhIJgyJo/VvEMtGRW8rCS0Ecxy6Uws9oL6Zl7zMCIGYfY8jQCpbYFV8B/mM7enU1y2RQVb4h8q0GDGqdqr6jKSreo1+c1zhOOYp2hQGnfw8vtSe88mYGmmlHWcVcAEeE/DpppPOt3rabvN3eJu3hcnKp0UaQRTDC8Wt5CrrkjbnVdcNElee/WtQx5aUyDZlsbE2yshhGwqvX7YBmZFCWyduVSpcnfqPrNFxMJudM1aBj/AFra3ACNZrvEXJJPM0UGM8HdhF9OtZUQTRdPwr/8R51lSHmVgQXiKSyliFB10WJHz096XXUhSuWczaxr8Mx9zRjKbjKsgDbXcAz89qnCIqwhZso0Y7A9IFSeK2wMyVvEbkeZ1oZ2p/fe2BtrENptqdqWY1F5Aa6iP9acj3BMO7LwVuncgCPfMKFsWGuuLYMa7nYDmTFH9ldBeggAIJnrJj86Dw2KK5gIg76U0d4RNARjNq0QqKWeIn33BI51vvbgDZ7ebNtLa++vKh1xYZGDBJnRiDO20jaoDiFQEFZk5SZOkjl0/Ot1UIPMJxV1iUMwIGgA25TWhdjURMyTty0Fc4Z1a2WaB4coHntPsIrrBcPNx7VvNlFzxEkfCFmT6wKQ+S9jC03Oy5KGXGZjr7bUsvliY89YrrKWvsiudCQD1yzG221Y9pvEzK4AMFspidJlttiD7itGNlXXW0H4kIdswHKdaLuO9xltoCM/gRFOmu8nmdJrfA3tF2e5BVFJXnLHwgnyBM+1JcSzI7OrlWVjlGoiQZj+EwaE7mhHIKW4b2cw7vjbVuASbhUg6jw7n2ALecVeu0fAO8zshCXJRQCAQFCsHXUiGLNmBEyI20NVXsO8Yq1eJXSQdYyyuU788rE1cuPYe+z5gGdBuqRmjnE7nyqXM7K4r2l+DEGQkwzhfBms4e7lcAFQGnXXKAdARlLGD5Aba1ReK8Ne65IOVp8Q3jXkSZ661aMXjLvdIqLcFuJC5ARzIMqSZPMMJmaS3nk+L4o2gqfWDrXI5FkjeG2NWXTcHxOEAF2FC5h8Jg6gakjUa6aVVOE2Ll24lu2rO7MFRRqZOwE7DqdhEmrfiLgVGnQQat39nPYs4e1+1XvDddTkUzNtD11HibQkchp1qnG/eS5sQBAgnEuEpgrdmyXBud4ty6QYBcEaAbwNhtzPM0mu3wxIIkk7DkZ11ojtHZTvie8mDvIFLbgAvXV3AclekMZH3FVuKQb/AKVEPiZ2CIN/mcY5Y/4bLHOPzBrtbVsoIY5+cnmd9OlbW2DJaTOwBkaemvOhmugEZd52jT2NYh1DaSurIxVxREmeEIjUTJBNdi+GuAAQJ+lcWwWPigkwY/rXXclWLAQIPpsaMAXMuzOLCLlzPz+GOUdait2yYBBAnej/ANkdbeh1MypPIjUDoaVBmJWW0iIJgnl7Sa4cztMLu2LYZcjEzyETtUMkErE/fSpe7ZDPPy/Ku71strz9NfnTAIMELzp0rA0UWluNAoJP4juK2cM2XxKYnQjcH8xWlqmhbkl3H5YHRV/+IrdIuKT3r+scuWlZUukSjeHpeyFi6iUIBB855VxbxfhLuRBOqA5dPKKizpcv3TcOXNqIHMcoG1C3bYg6zGnXSptHvNZaO0y/fB15HWOnlUD6jfauLp6c/wAqhzGnKtQCI67PZgl4j+FR9TQCsJM7zRPDHPcXYnVlE+gY/wBKXltaZXlnHtDcK4RlZgGAOqnY+R8q44ndzEsAAC2w2HQD20ri2uxovH93CZGJI3BED586BgbG01RsYNgrxGnSY9TH9KYNauQjmVUDSBJg84kffWlyrqWGXeYPn7QaKvY283wupkdBvHPSmYceLUTlv6TjdbQ23hFUrcW5mHIZMszpqS5g6044RxxsJesq2tu6SlwKNZJUIw5sVJOnMM2hMVzx3A27d62iEAXLaXIJJjOkk8zEzVp4Xwr9lyt3Wa9sLjeIoWEEWxEKeU6tvttVf2jk6fB0ejs24HJm4kZmsdpnbjhKshe1bTvVUloWM488upYQSJnp0jznhfZO9iDOYLaJk3WkjnmCroXOnp5167w4eObpyggnxcyBJjeTt9aRdrOIqlprdlWdrsohkDKCCC0AawJgDT7V8p02fKKxgWfeWlFM8kuYwLaeyqyGcsH2LLoFzeYAnfmfe3dje3EFLV8Etoqtvm5DN/N586reO4NcEzqV9vodaD4bgnN23lGveL880/kflXq5ayKA/biLQvjbyz0zjuLW7GRzB5f0+tJoRJjc86c9peEqniXTqBVbupHrUWMkigdp6bE81LJ2B4Acaf2hhFhH8Ej+8dTMxyRT829DNu7T4Twxn2Hr7kk6VU/7ObISzcRHLOzl8pckJyAFvz3LCCdByqLjjvqLlu4P5kQsvvMEfX1r0sK/ND5nnnY2xN/H9xPjMGuYy3PyFS8SfDKoIzG7k8RB0PJSfYbAUGbCH8R91K/cVvF4W1AJmY+OdgNYjY86ozMGSlNw+k0+MC34iz3mYXEAyMwUdW/01k/0rrAYQ3CcoJC6sYmAdpqfs/g7ly0wCL3c+J3Gi9DLQFMEHei8PeS02W28rmh2BmY0mfr/AL1nR4MmQELsB+vxGfaJ6csWslz+QgptqvIiTEn6VtrBjfSDPkYOlMMdhmYkLrpzahMPZuLKuBGnimQQSBpWkONyNp5QAqBvhS7AFoWdxqY9a1hcAjElixVWjWNh1MVYrWGSeVD4ngJIYq2QbyWGXXefShORVG81MbMaEmwdy26xbAmeY+01DiLttCVK+LmAJ9Z6aUBwm1b75jbuXLoticwWFcjkCOhIreIa4zsWCiTpmE6RA1rFyKTsYZwEG4zt8LW6pdGGnIyPaK3w/DDvVtlgzTJXYAAH8R0J1GlQYO4y27iOfjjK1sxlPmDypRetnPlDsdd4jaNo35Vj562Mzwwu5kPE8IDduHIRLt9zWVNjsaouOAE0Y7trvzrKT4je07aVdjrTKwVZDpqoJPmI0+tLkGsCsGIgnXcR7GjIs1CUgbmYw0FbbBNE6ctJ69elF4a2QEZnjooGYwZMxMAVq9mVp1E69dTttzrg0x1PMktDJh8pAkuTr6ACo7dpAJgkkTPQny8q4vP+7HqfvXDXhAEdKYfSIAajOyJOhMe/6k1trDc+RiPM8q5/ahrA0+f+1MOFuSmsAvKrJ2WJuPr5CKwuRDQBjUX935/7Dc01w/CO8tK9u5DD4kbk0aCRsIIOx33odLbXH8C76hB/CNEUEncmnWFwxw4h7ga48ZraeLKepcGCRtCyPOlZslLYO8v6HpRkyaStg/p8wLBv+8D3DnKsuaTGYWcojyWFC7Uy4nxu9eZbjuZVsy20kBSxPdADmTvOp09qX4vBlm0OUN4STyWTMDfXb2rq9dWyyqHJJEs53kkC3l8lK5v8oosudM+n3Aqa/RZMGokUt8/8lxbiRxWQXPC6obbAeHNcH94yRvIy7bRHKp5ZVhmOVRAhZMaaSQY2HKqfw9X7xUW5muZltW9Y1Y5r1yeQGviqz4JLl7R7dxmPxA3BcVWEgujlV8TDXLJIJOoOtT4en0sSODBTP4fAlc48bNzDh7avm72GdwdR4h8ROkEZYjlOszSvhRCEMBoly3cgfysQf/1dv68j6JxzC2zZNoiCSXyaqqu5Y5txJ30JMTHSq3Z4YlttC/xDUqEkbnws8zIEa044wwIXiJOW21d7jnthj+7tZhbRvFEsOXsdeXzqn3OJsVznDJl/i7sxqdNdqt/bPiSYdVNu4hdtQjqGaCYzaDKo0brVLxvG7t1XW65IKnTlPLTaoseMrsRLPGVhay09kL+EuWm7x7dpp8aMCizLZDmY5SYmNZBnQVLxfhDgE2sS2U7Ce9X2LM0D0NI+xna23g7LW3sh3Z805svhy65yQdoAAA5maP7RcQwhtW7xsqrXVLqiaMQCQxYhAogxzkz608atXAr6f8k16ibMT3MO/Nwf8v8ArUyYRbgFtjvMsNIAG/zihuH2DeE27agTHiYT6xRuCwJJ/eqFCMQAhHiGms7RoCNOZ2qp3TGup+P57CJKm/JzCOHWUNk2nIuKh0IkaHUeh32PSuMAlix3lu4puNlzosEfHAEsNiok6Ry2imlm3bVYt28oBk6ak/zE779aixmDW46u6sIGWQfiB1AJAkc/nU3TfaQx5WAJ0EbfjCfGXpjze8r74khXyLDH8Rb56dfOuLXELhhIJ1B+X+1MeJJnuixaVQFGoESznlrvA5nqabYbAWsKqvcym65MWwQcxj4ROgjmaoy9c2UAtue0oXp8ekV9Yst4yELvFtRzYanyUUn4njnvtllktj8JOpAiTHLTlTTiFoXXFy42aDItjYAKtwAT1XMPUVEcBbDhk/DOn8QQ5tes22n2qcZByef2mHERsvH7zjBXBaUKDCg6+3gYx5qVb2piL4K5X1EDMPQw+nrlb0JpVfbLOWCoY7c8g8+tth8qjs4oKdeXI84EH52yD7UJS94YfTtHPdoIOUKQf4em/wAppU58ZB0YsBrzluXtUNnEBAVgsRJHikEgazPIoR8q6weLkaiLggzIMsuoM8hB+YrSD3k+UKwsbQLi2DY3rkMoGYx86yiGvMd3U1lFrMjqCYC2EgqF7xhkBYyVzDxMF20B35UF+wpnygGBInNMgc4FR4bEMCVBEsIJ8vyHnXdjiJtjIIKgnWN5ogWE1GHeG4qwlsrkBylRznU8p/KuOK2gHyBoyQN51jl96Xpc8UDUbxUjXTnJOsaa124mM+riHYjDW1sqSSTJjz6k++lKrdrNpMHl0qe7dzsADCrprtXWJtgCFBneT+VNS9O8WTBcPaLEyYgHzkgbepqb9nuqpLZlEQBO/UeQFQ2sRDA9N/XrR63M8Z5P8sx8ya6zc0E1tC+z1+1bW5cvtnJhEt7kgasY2H4QCY2NM+EYjD3LNy9la21pwO7zZpDfAQCNyQw8oNVzH4VreUtEOCVgzsYIPQ+VRYYOrSPhgFpMCAdPeSYpeTErWw5npdH9oPiZUbYDn5uWPjfHsyqq21zIo35TudNWE8tKrWLW7dz3mVmUZQzhfCubRBoIExAFXbhXArF79nu3LoyvmBQaHSQqswmPENdNj5zVi7W4hsjJly2nVWAEEQQFA30WIEVOM2PHQUWe8f1PidQ5tvJyPaIOw9lEw7XSyi7ADMAJFpWy5czqVcjIoKrOyyZq+O6m0rG4VhspUtlJSZnw65sp22NIBiLV63Zs27aqFKhbe2TLDb7gQsk+R5iorxUsrhhlSHUg+EsDGgceJixSW5f8tK6nqNhyD+km+7kHnaMsDgHuK5yMokTl0IIMwRlYjloIPnSXjGHAjNbfMNJfWY6SuhPOsscYuW7PfBbYghTccvqSNsocKxEmSQftVf4vxW7cdmZpLHNJWN51UGdNCPajxWxDHiRtkokChLKuKt3E/fC2VVSAoy2tgSq5wJ3Gw11PU1QMY6tdeAFUsQAswBsInU6ddTUyWro1ljbYwSJid9eUjQnoKL4dhz+0Jcc+G0Jg6kldbYM9Jn2FG7qu4h4m33MO4J2QKKLuK+IglbOYCSATF1j8M9BETqeQmvWFt5BctIzIitDKQArHNlykyFkwRO4O1b4Zxtb+IAxFwpa18Y11GqzI+EmBttHrVy4hxK1iV/dqc8APbIIkDfKQdIP+2tMxKzDU39RzFf8AGV9sVYL3HUuSwXKhGVA8gvy9QANBprQz3XOYd7aUgFoZgCRudGObNoxECOWprlsGtxx3Zb/KFedZ1IImBzjkPWpuJYm0HAZAzA7mCVBC6DpOUEwdfQ0xyo5FwUQsaBkvD8TmtHLGUmE1khf5uhMGjMZcRLWZzOYEBAYYkamNZ2FLMVgGw+bEW0nwnNaBE6/iKjWOcRvr6KsTiLjm3cJUIUYK+jMCwKkNECJBgxz51E2DU+ocSpQEG47fwzluGqZZmyAE5VUyVylWMnl4TIrn/wABuXHZlLPlJAdm3UGCwJ5aj51Hg79wLyaDqMv8hTQ+lPbnHVOHASbdwAr/AAqZZSYjRhpt6Ub+Itad5iviqjKnxDB3LbtbfMrKdRJ00ifkY9KXPeuAGHeJjfqMv20p9icW91u8uMMwAWWO4GmvXlqaFNkAN0Ygkb1TjPl8w3kZfewYCwuwSrseuvUR9tK5tYW5+IkA+e/KPlRv7XGiCOX1kxQlzFGTqP6dfWts9oByGYMLqZZsv6n3qVLgEOAZmJ20qFL+pk6H9aVFZOYkZjCqT8q7c8wLJjL9rH8vyNZSPvQOtZWaJk64a2pb9aeulGYuCCCwbTTKIgzzjcxS0XCo2MculSXUfKGB09a0izOqcWng+YojDuxYQJoBSSfpRdnQ5SSNK4zNMNw+G71oLKoB1y6k+Sgc/Wphw9dCtwIJAIckmNZzQsbCg3dVKkgnzHPkfTSurF8aamJkc/WgOr3jVCgbiMb2BtPnuKAokhIkroNJ0k8+lT2eGoUVyczkEsBELBAGhOk670tu3jbYqhLRIDEGCDzUEaVL+1ZQsqdR4hOXY6QaGnHBh2hO4huO4U+QA3DqfChg6DeIOmpNccN4VcOJs2nK+K4hKM0ZlUhjI6ZQ31oj9rtgJoH0/DCsDOuZiNZFG9jscLmLZ3IBykoGIJViAmh/wkisLMFJMJcas4A71Lj2lu+HLbUojEnw5QC0knQEbkmfOkNi5nm1cMlvhYnM0jceE8t6acB4OLgvfvSbmc/uyRBWFh15kzmG8bDTQ1rh3AzcvojSqqcz7A5UjQQNJ0XfY+VeeV0meqrKFPxCuynCjZs3MVdEPlKpPJPxNrsWO3l/iqqYXFAIy5AxbSdSdYAj+tWT+0Pjeb9xbMKNGjyiB6eVUjCYg5/CAQN52/351Tjx+Ipvvx9JEXo2Y8wZt95ZfFtlw9ssBaIJAuDYuADKkhtPIA6GgO0vFBfxTvhLZ7pgqSq5czIUcmAJUEhTy2BNTjBLcRlzsgYRoJHL4tRIkT6weVc43gNxMCO7CtkuE3SmpdSfAwEToCPCYjXSm4sR12537e0QMWrYDb3iW1cvp4JBSTlUukAn+EZtNfKo+K3cQCVFt4gZiq5wNCPiWRt50GLZqbDZ1PhZh/hJH2p7Y1N7fhGJ0ag2D+MccJOHXDrdttcLnw3GYqEE6i2qAZn+ETrrrtOlh7N8BvX7dy8kotyVti4SmdIEXCVUlgSToFEwDPUfgVm5cVWvWrdwRAeArwNpIHjHuDqauXGu1uGwiA3iwYjwW0QnNA2UwFUcvERFJ5Y6TfH9QnwMikEVfcTzvGpetYhsPiAGuyHXL4s+dfjzQJEoszB8Pka5uXnVmCI5d18MatuCTI2H2EU54ThLuNv3OI4gm2jDJbRdSLY0gEjXcyeZYxypfxvjKpNjCqozaM27HoCx3PqdKPxmZtPNTlFLZMM7LXhlYXsz3V8RE/Cmnidh+ImQBqdPWoOMYZD+8tghZEqYhYzGY8yaS8Me5Yuk3FMNIPMMYMeRiSRTixiFbMusEbemv5V1EkmNB8lRG53kEDxbaa76VHbxZyBAG0JyzrAIBJ6TpRPELQkQWgtt5Ef1oa5aMyJ03oxvICpmWbhZWYgR/SOu3+9A4nFaHrv9edNEtAAyDt6R86X4hEuu0EgiBsPy3FNGMmc2Mxa1+Y+3T+tSuk5SNTHy8vOpbHDjng7bhvIUbgsKI8RAHX3IBodhACGJbhP5VPwtTLnllIPvFNBw9VYyekGPeiLXD8xOU6kEbxppQnIBN0HmJV4cTrLa/wDpmsp9/wDTtzr/AP1atUHjLAqIrdonK0eDYSCZY9ANzV64L/ZzmAfEuUzQRbtgZhz1YzHoAfWknZvBXUxFu/eC93aOZUbSSFOUxyhsrSelMuOdt7txjbtczE6gf9zDzJ9qXkyG6SVY8Qq2j9uzWCs6LZtTvNxs5k8xnLR6COflSTjHCbdw/DbU9VAWPcCf0KTmzdua3LrnyU5B8lifehsVwq0NWME7GTvQDIw7/wC5ScQriG2+zQgRejqMubT5jXSpU4CyCbdxC3VlIid41bXzpNgi1q4FV5UzsdDpppyMxVisYk6UDZHHf9IIw4zyP1iXF2b1tv3iyDzDZgfp9CKDvYgKSSgYERlOwPI+tWu6Q6MrbfrX7GqqdRqJPMcv61RifWN5LmxjGwo8xdZxRmurWMcOGTwkc+nX21o97akA5ANfhj67Vwyg/AgU8yRpFUlBUUBQsGGYPil9rltUEXGnI6GGEDVugAAJJIiAa9O/aXxFhBh7ttWuhS98qVz21Lh2FvNOrg6SN9zE154XFqxNu2DduggHmLXiR5Eb3DoAfwhuon1DCYBbaLhHC3Llu1I8IgLCLGiEgkidOvOouoRVW1lSMxNE3KxxfsbecxaxFpzGzEoekjQjepOEdkSgAu75ioC6yRvrG24mNdI3En9on/Z7BW13iB33zP0/9S3oND4QRzjnSzii4myltEuNcuNF24GGbKTBRRHSDJ1kx0FLRyVobRhTuY0xeDFtfBaM8oUmfSPUUPwBw1q5k0YP4gTBIZRkInQahgPQ+lEDHLYwtnMoe7cQEzdIy6IsZDBgd2kjqp3qtJ2rviFYlgDEkgyAbMb/APtH/nNElVvvDDspBE540bLXMty1lfdmTwOZO5Vhlb1gUDhbeGBJd3EHRcgJ9ZDR9Ka4/tGzC3mtq02xIZEYFgYBIIMSVzHycigeKYqw+QtYtjMnJSpAV7qLqh5BE9depp65DsG32hHKNyBW8c2O02FtLlXOY0Ay7+5NVHtbxwYy4oKAImqgaydR4jz8x5CpbGDstcHdoZLABSzEH4ZDBtCPi3/IVDZwGHImCBoD44gmSBp5Dy2NMxrjUWOfeKzZnfY8Q7inay5dtrbACQIJXQQBHhH4dKV8LuJqx1bkIJ05n9fnRS4GzAhAwJKjxFtQF36/EN/Oi8PgVRNAdddthWKiqfLEMzHmRFC8eJQBrBBknlsCOvOuMA7C40kErGo8+XrpWXkJ0BFbtkjwqFH66Vjlr4hI6gbmbvYrKW8M68z9q7s44nTKsedD91O5/OtNajUH5UYG0mLte0ja4zB5krMD32Ebn2oK0ggWwfhaWIMAA7akTPl5VNibWVSAJkc+R5GhcFhDclS2REjM3Ni3IRqx30otRG5hKWYw7MiQS2aBpqNfYUK/FRPiTT60ZdwFoKCFMcs2YH3Da0rfDoxhSVPIGR9963ykcQmQiN+FX7TN8ZBP4co1+uvtVgsYpQcpVQOkak+ZivOnZkaDII/QNWjDcRV0UlZYgTA5jSdNtaRkS4o2JYW4mB+Ba3SHvJ/Cw/yk1lI8OdRkvaPEHuyAdyAfc/7Ut7O4YszMBqIAnYTqZ9oo/jNslCIJPLzrOz9s9zcXVWJI8xKiD9aBfTU9EbtZnVi5Y70Aubjg7nYH+UDwim+MARC3Ia0Hh+E2rdxrig6qUCEyqhpmNAeZiTpNF3rTFIcAqRBB5jzFaUHvKELUbEQ3MR3yK+SIbwPoZK/EpjY5ZMeXlR2HQ+/25fnU1y2Fti2qBVEkKo5kETO5MHrQt240ZRp1PvXFbNCJyNoGpp3i78LlHP7frSgAi1L+zE6zWxhT509FCChPMyZDkazIgqjWisBhVcliD3SeJyOYB+FTtnbUAep2Bq4/2d8OwwV7l9FLCMjuAVtgyAYbRSWBhiOXzt3DcJdtrDIuJEki4GGYgmYKv4RG3haPKmAWOYa49rJnlXCP/MYy0Hyw1xAwGgCJHgAH8i5R7V6FwsG5iMVePwg92CYjw6nUgjkvz50wxNtc6ucMbZQFgzFGiB4oVC2Xwz4hB2HOkHZjiltf3Jebl3NcEcmKkskgE5goB5b1L1APEoxLSk+8i7bXQtruxEMzNpHTT4dOnnQeOuKcS2cqIsoBJUalFP4z9gTRPbhcwtAmCWI105LzePPnr1JoXEuVxdxQWnIvwNcBOVFERaDNEzuh9RzmS9JlBPlEGZpw+UmHV2jKYGUrtCALuJ251XXsQqnqSJ1+5AB+Zp5dfwO0yRvLSfECRobVth8J3XnvSPBCbltZ3dZ9yB1p2PvMeqEN7VYhXueFAmRAgVdICryEHmaL7ZZItW7YAS3aVVj+YBmOg3JMnzpf2ncftN6NAHIiY2MdRQ+LclU56eu0Dzp4uwYs1vM4fbEuxYjLbciNdWXIOWnx7/WobSSGWdxMf4QT58p+dT4dyFeCRKhYjcZ1aNtPgFDd5B/X9aYBxFEwnApsQBKsNeeo0An/AAz/AEqLiTubhysIUAFRuvhUmR08W9G4C3BYdGiZHKRtznTkfrQbOrPnJjKzbdPw8ttW0oiSsHTrFQJrbEzNYAw6UcWUiQPUbx/oaz2rfEMmIINQEZtd66hv0KLLeR+Vclz0NZ4hmWYHdmDpryojBYS73DPbXYPcYzyUhYUD4iYGg6H36LdRW72Ja2i25lRr11JOvrQl75lODe4EHdrK3GBAkjXy/KhhZuZypQlQMxMED2Y6H9R0rvHY1i2rXAOQIJ06ABYA8pqJLpG1bt3jWkHGk+BvUH9fOieCXAFMSNeW0VzigXA5kGfy/Op+HoAu25+1dqiHFbw1cYR+NvlWVxm8qyuuB4r+8c5D0Pv/AFojBWYuEnnA8jG3uNfnU1ywx0gwNfWfvVa41we5MG4VQ6qGZjPlExp19KiAB2uWYuqvYjeXf9jlgEgT1obiGCdGjMpG/wAA+4NVLsz2hvC53btngeFz/LEifxb+tWe9j3YSaWwdDRl6ZFcWIHxa+ttZOpJCgbST09BJ9qEyzt9Naq/aK9da9mfMFDHu9CBCmJX6SavXZmy1zD23JnMsa+RIn6Cn7Y01GQdQ5yGuwgCAgQJg12LGm1WEcO0gge+tZ/4eo1AFL+9KZCwCwQ4W/ZsJibZdQ2aXWRlyuyw38pCjfTlSjB8SvPeS2uQNcYLmUd3JYxJ7ooPOrXge0jYMtbZM9vQ5ZgrKgypOhBmYO8zI5rrXHsA2JW41sKJ1JthSDB1JWY151TjYcz1wWGMBl7Cj8S0do07uzFsOBlys2Yvm6S0kzpvIrzLjCMmVgSGDz6Eg7dNuvWrV2hxmDukG1duIefxR7aR9KB4fgO/uhLj5rXxBsmb4QwIzLqu8zB2qjI2Ips2/yKigAVqt5dOyd8XsMl82kLmZnwwR4SUhOcAzrvEmJqtcee3cut4QDzllMkdc1tSaLtYu1hbJs5y/iJEFmgEDTVVjboaR4HCi5dCW3YFj1Og/5I9p1rzVYqxH+tvzhDEwFkfvN4Ym5hsQZnLkEFjAktGUPdYifFyA6E7CfsV2ZvXsmIhO6V9mklsh3QDTRhG42NKDiclq5bDgZoJS5ZIaRtqNtzrFehcExQt8PseAE90pIgamJPxb79KZZW9uT32i2BNATz7tJw24uJuZoGpczNvTUn4xHtJ96VX3zEActtQZ/XpTji+MLC7KMuaYAUrPyIB9IpJimhTlBB/wn+sCrU0kQCDCraO9nwJccFwPChYSFMCQvxS23rpWNwPGxIwd+P8A2m+2h+lWfs1xCMOgu4Lve6EW7gzLlmfhZQQpIAJKxvB2oi/23RfCMER/+Z/+2T86cqCtpMz71FXDeG3AFLAtOjRoQ4IlcrkA6AgzqDyoq32Zsosm3dBj4jdVfmSSPkOtD47tDdvWXtJh7diy0l8tqDGhLszypPnvIoKzhrMCcR8io+womdF/xv6xuMFh7TfFeH2rRQ2r3e5jDq0Erm2OdQFYSCNgdh6bTAkwYP8AWlfaLE27dsdy7li4zOSdVyPpr69KuXB7YaxbV/iCCSOoABqDPkK7gbTXW+YnXhXM8+Vdjg5EaE1Z8Lh1ygkn3/1ohXWAPyrzW6lgdt4rTXaU4cKk6iOun5Us43wu4FBRM0E5lGhIPNfMdOcmvS0wonbSK6Xhis5DNlWM2g1IkjSdh51uPqXdgoE1bvyjeeH3LcGSCPJhlPuDUWKvhBO/ICvRO3nArTXFZCyzoY1mBvrzpFb4BbNtlYlswAJ2iDOkbcuu1eghsgGUMjASocOsPfvBQTruRyHp0q5WeF5FCgaARTDsjwu3ZZrSSzHxFyBMcgYqznCCk9RmbG1VtJG5oykfsB6VlXb9jHQfKspH3swaEOt8OEQCKU9reF2+4a465xaGbSRoSAQY2H9KZpebkPnTtWK4VwIzm2xJO0lTE+W1TdOrF+YONWZwR2nhVpD35/dm0CxKKeQAEaHWYP2qzsAyyJHUT9qrltnXElXbvWAglZOh1jrufrVhskESDpXp5UJoiejjariftVbLWAsCEYsDzUN8YB5g6GOoBpn/AGS4mTdtlxACuizrOocgf8k+1d4lAVM7RrSPsUy2uIWlZSNSoHncU5PuPnQsurEy/WKybGxPX+5kVw9idQBXC3wJBBrtn6Ax6/r0ryBYkhFznjGCwt+2BdBR0XKHQwYG3Igj1GnKvO8Z2eTMct0kTzUfka9DSzIPIefnW2wamJC6ctNelW4+rKCiLlCZmVdJ7TzS1wIAwpdm6LpPy1+tWoG5g7dphAy+EiTuwJIkA+fI1aMPh0UaKOXwxr9NPrSPtiVW0oaIZ48WsQrGdPYTymtGUZcgUjbvO8UswqV/G8YFxpcAnzcf9o+1Lk4pF9LmQFEIOXcETqJgRpSjiHEbauVCMdtQ0TIn+GuMPxDwglNwYhuk6a84gzI3qxulQegH6mO+89if4Jbsabc6XXCnVQzMIB1iGHLyoXH8YdLQtpcbKNAIABk82YCd/OkNrHoYAdl8iD/0k10XthoNwZonmNJ3n5UJ6agNTE12qb96VtgR+cKbFErED6fkf61FeZmAEADfb33n8q1nWV8a67eP7c67lTJBB66g/Pn9awDTxO1X3lo7H3kUZbeLuWSQMyBhAYbnI/5UVxzC388nHFxGh7tB9jVctcRsZQL1u20CAwIBIG3McvOhMTxHhwOlpyf5ZP1zx9asx5B/BEMAu5r84fjrdoA95fa6Y+HNpPLwrUFlcGAJJ9PF/SgrXaTD22/d4dgOpyhvz+9NuDcesX79uzkNovMO4TKIVm1gzrlj3rMhJ3raHidBtfPsZJgMBbxLKlu3CW2F1iwMNlkBdDmbVpieXnVluJbQeMQeZAcAnyBn70XZ4eluS7gyNPFGntrRH7VhycpkafiBA/3qPI+o7cSlVqBdyy7KOoOaNOVTHHsNGUR/pWnw6DxW1Zo2CmYPvoK6sI7Am4pE7LMkDzIG9TOinkX+8xsYY1UlTFs5yAa6A68ztWuMcVtpeWdRkyjyGbRj5aTXLLGomdh6tIHrAk+1V9LqnE3rr/3VoFFH8TgZY9Aok/4lpnT4tN1Ox4hjazNcYxAYkTmMz7Hb5waVrCnNMjYAcyenWh2LbrEHkwmJ6eXlReBtANmY5miB0HoOVXIhB/lCc5Bk3BXKuWI1Y7dByHyq0I4O0DnVTsvlvMs6QD7kt/Sn2FDFYHL7E0nrMerFfsf3knULq8wh2U9fpWVD3NysryK+ZLpjNXQmARGaAOfhPiM850M+lR9o8WFw90ExnHdiNNxBA9poexisyhAIgiBEbjmB/LUPHyGW2rbFixn5CqsJ0hm9ql/SoHauJ5n2aQd+wXOQokseb5lBB/hEBvPQdTVxxXD1fxKcjncjY/4hz9d6XYe4G5ZD3jqQNPhcqkgfiKhZPPSnlkGKtTqdVqwqVHAFAo3cVW+FOxi6VyDks+L1nYeVJ+PYdrONs4m2sgmSI2KBR7Sp9iKuLA8qrnaQhzbtqwkMC0HYbEfLN9KNsyBdK94Hg7by2cO4ily0twgrO4mYIkETAnbpRIa2SMrR5bnWk/ZW037OFfWHIUbeEHqNzOY604FhZJAivIYKDUgyAKxAnYZhIFwafepUYnQssHy/Oo7FvQkLpz9v0K60OkfofegJEC5MMPpEx5DSqP8A2gcRy4gW5gKkHzZtYHoJn2q74e1mIE+Q6iZEfSvL+3mIBxFwzmCMRp7rqPRI/QqroVvIT8RiqOZVcZiczbnc+flp9fmakYsFyyQJggHTlvH50JbuAjUbaecevvU15CIYEkEc/wBajavcEnILWZ0G8Vd4d8zMT5L+Z/KhVeNa1Z2Hnr8664grDuIJmIA5CgWAqbDuSzekfPSorogkVxnJttOI1rsVCFg12vM1wjG5klT2cSLd21cIDBGVypEhgragjmCNPehGPhrMTqB7j9fKt7TBzc+i8ttraEAFGUFVygQpAK6EeHTlULXraDRY8wo099qSdg8Wz8Pw924Q6KmQqELOO6JtiMupPhG9WW3h7V22G7sMpiFuWyD/AMlwafKvJbykieyrjSDAcPxW09zug695E5QRJHWB611a7wMzOVyHYTMfTSdPrUt6zZtyy27YboiKGPlOn3pXhMfiLjQcOlpOty6CT6KgP3oSL3EMfMI4vihasPdMAqDl5yx0Hy1ryzC8eCd7bZSVLBs28GIbTz8OvlV17d3W7nu2iVGc5dAcxhYk+teVXX1VerEn5x+VXdMgZYnO5WqlgscWQ/8AEX3MfemVnidrc3E/5h/WqEzamulNU+GT3k/jH2lyxPGbZuqFbMTIkDTTUa89jVy7M4jNlnnKn5Sv1FeScNb99b9f+k16TwW9lj2I/wAuv9aTlxjSwvkVCDF1Mu37L51lSZW/RrK+asySJ8Htc/W71Hxn/h/5f/kK1WV6OH0NL+l5lXP/AN3c9UPvlOv0HypziXIXQke9ZWUJ9X89pf8A4iIsVdYkyxPqZoN/jH661lZTlkx5lr4R/dj1/Om6fCK3WVPm9Ugzeswrh23v/Sttuf8AAfsKysqQ8mKE3w/++X0H3FePdqNXedfF+QrKyr/s71t9I8cH8JXeHDR/Q/cVobH2/OsrK9s8SM8mcXfhNSLWVlZMPE6wG/v/AFrWJ3rVZXQR6pCtdjY1lZXCGeZjbVKnw/P7GtVlbOE9V/seP/kD/wC6/wBkq0YW4f2krJjJtOnxryrdZXl5fW09nF/5CTNtSbH7isrKWkplc7Z/3Tf5Ptdrzm5/ej0P3at1lX9JwZD1fqED51Iu1ZWVaJFC+Ef36ev/AEtV94d8K/4qysqbNKMXpM9FatVlZXzZk8//2Q==",
            },
            {
                id: 11,
                title: "All the Old Knives",
                genre_ids: [53, 28],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgSFRUYGRgaGB0YGRgZGBgZGBocGBgcGRgZGBgcIS4mHB4rHxkYJjgmLC8xNTU1GiQ7QDs0Py41NTEBDAwMEA8QGhISGjEkJCE0NDQ0MTQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDE0NDQxNP/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQIDBgcEBQj/xABIEAACAQMCAwUDBwcKBgMBAAABAgADBBESIQUGMQcTIkFRYXGBFDI1kaGxskJSYnOSs8EVM3J0dYKitOHwIzRjhcLRJYOUJP/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/8QAHREBAQEBAAMBAQEAAAAAAAAAAAERAgMSITFBE//aAAwDAQACEQMRAD8AxqEIToghCEAhCEAhCa/xflHRwpqHcKKlChTujW8GtnLO1xTYjxaVpsuMjB0+zMluDIIS49l9NDfLrRairSqtocBlOmmzDIII8pbaHBLKjRvXp6KpubSvc2+QrGhQSmpUEEZRy9XT7qXrJaMhhPa5Q4R8qvKFt+S7gv8A0F8T/wCFWls7VOEYFC9WgtAOalF6aaNKlHY0mOjbU1Mgn+jLv0ZzCXvs+uCiVatVKIs6J7ys70KdSo7EALQpM4PibA26DJO2ZVOM3/f16lfQlMO2QiABEHQAADyAG+N9zGjz4TZKlRU4qnBVtKBsyqppNJS7hqIc1+9xqLA58QP5PrM44VbIvEKVIEOgu0QE4IdRWCjI6EEffJKPChNm4rwS3duI3tCmgprbXVvUp6VxSuKFRVVkGMLqRdQI6eL1mNYll0JCWns64bSr8Qo0qyhk8TaD0cojOqn2EgbeeMT3qF4b+zvzc0KKNbIj0np0UpNSYsV7nIGSpxjScnb1xhaM4hLt2Y0VNe5LCn4bKs6tVQMiMpQq7Aq2w67AnGYdo9GmrWyhKXfNbLUq1aCCnQq62JpvTAAB2yC2Bn4YDfuCkwly4lbqODWlQKodrmqGcKNZABwC3Uj2Ts5TppR4fVvglJq3yqnQ7yrTFVbemVBNXRg9ScZwT6SaKDCWXnm0dLhWdqL97RSsrUKfdIyODpbRgYYgZO3nO3nCgi2XDGVFUtbuWKqAWIcAFiPnH3y6KbCajwXhNC54TQtiiLc1nrm3q6VDGpRIZaTP10spcbnGQPPErPaXbqnEayKqooWl4VUKATQQnwjYb5klFUhNg4Zylq4WLf5OpqVbZ7sVvBrFQMjUaK58QDU1bPlv7ZRezqir8StkdVZS5BVgGU+BuoOxjRWYTs4sAK9UAAAVHAA2AGo4AE45oEIQgEIQgEIQgEIQgEIQgEIQgSUXKsGHUEEbA7g5Gx2M9VeY7oXD3YrHvnUq76VOpWAUqVK6cYAHTynkCPAjDXVwziFW3fvaLFW0suQAfCwww3BG4JjbG+qUdfduU7ym1J8AHUj41KcjzwOm8fRtM/ObHsA1H+A+2d3yWkgGpC+dtQYqc+mPI+/Hvk+Jrg4bxOrbszUXKMyNTYgKTpf5wGQcZx1G8F4lVFA2of8A4LOKpTCkawukMCRkHG2xnVWsKZBam5B/NYenUZ8jOCvaunzl/jC69Pg/Nd5aoaVvXKIWLldCMCxAUt4lJ6KB8J53Eb6pXqNWqtqdzlmwoyQAOigAbAeU5YRhqw0udL9aIt1uXCBdA2TWF/NFTTrA9gaeJa1mR0qIcOjBlbbZlIKnf0IEjWPEsiWvSp8fuV+UBaxAuc9+MLioWLFiRjY+JumOs8vTHlYYlw0tvWem61EZlZSGV1JDKR0II6Gerxfm69uU7qvXLJnUVCogY+RfQo1H+lmeOwkbCSwldfD+JVaBc0nKmpTak+ADqR8al3B64Hti3PE6tSnTo1HLJSDCmCFyoc5YBsZIz5E7eU4TCRXdU4nVaitszk0kYuiYGFZvnHOM7++T8E4/cWhZreqyFtnAAZWA6akYFWxk4yNsn1nlQjB6HF+LVrmp3teoXfAXJCjCr0UBQAAMnYCNu+KVaqUqVRyyUVK01wo0qTkgEDJ39czhhGD0F4xXCUqYqELRc1KQGBockEsCBnOQD18ozinEqtxVavXcvUbGpiACdKhRsAB0AE4oRg9g8y3Xyhbzvj36AKr6U8IClAAuNONJI6ec5LHiNSjVW4pPpqKSysAuxOckAjHmdsTihGD2eN8zXV2FW4rGoFJZQVRcEjBPhUZnjQhAIQhKCEIQCEIQCEIQCEIQCKIkUQHCT06bEZA+MhAnXbjpviGSULd32UE+4Tu/k65PWk56fkk+WM/ZLrylagIulQxJycdSc+yXSkWA8SY9PX45G049eXK9PPh9pusjo8s3bglaDgad87D/AH/pOG7qYGlxpcHDKQw6dBsw8vZibNcXdXoEwNtz7/Z5Sic8W9NmLjSHwAc4yceyOe/a4nfi9ed1n9VR5fV6SMDJwJNVXA69NpJYL4gfbOmuLrs+BVXGRt6RLzhFaiuXXw9SR6+Wdtpq/A+HeBWI8p7d/wAJR6eCo6ek4/7WV6b4Zn6wKng5Jz6Aewe3z6Yx7YwGWPmjgQonVTB053UHYHrkStM2d/X3fcJ6Oep1Njzdc3m5StI2kkY0tSGGJAxJlSzosbfvKlOn+c6r+0wX+M557vJNDXf2qf8AXRv2WDf+MX8F95k7L7e3tq1wlasz00LhW0aTpxnOBnpmeZybyFQu7Jrt6tRWDOuldOnwAEdVJ85rfMNIVLa6peZouv7VM4lR7Kfop/1lb8CzOqzLkLl5L65NvUZkUU2fKYzlWUAeIHbxGQc7cESzu3tkZmVVUgtjV41DHOAB5ywdi3/Pt/V3/Gk4+1v6Tq/0Kf7tZd+ilwhCaQQhCAQhCAQhCAQhCAQhCAQhCARwiCOUQHgSTBwCPXHxjFE9Lh1PIZtOQjoW9ilvEfdt9sVJ9q0W3H6lsBToIjFFy7MGYnSMvgLuFXO5ln5e50uLgOe5RtCF/ASwJBAAwdwev1SDhvD6NZmNNBrOzNgH4b++WbgttaWi1QatNGcaW8Qz57keW+fqnl6svzHs5nU+6odftFun8QWkiaiNbK7g+eG0ggHGNp4XNHEPlCJcBQrK2ioAcoSRkFc/kkevrNGs+D0HQ1KVQFPygjDS3xHx+oypc4vRWj3FFVGWXoPMHPQe4iXnqe0kjPXNnN2s+cHG/vndbqWKBdRdhpVVUMSwOnGMTluk0tgjB8x6HzE7OEP4k8RXD/OUkMM4III3HQz0PN/V85D5jqVqyWVRgdSko4UAjw5AYDby+2TXbXVK4q01Ks9Mal79i5qg9BSp5CjKn2b5HXpy8D4lT/lSjkqqohQMfN3y258ycneafWvaTsMaW8RXXjOlx+Sc/NOJ5urOetz9ermXqZv4zi94fcG3L11VGYZ0qSQPgenu8pm9xalFDEfOJwcbEA4wPj/CbjzrVUUyo3OJjPFq66BSGdSuS3oAdxj6/sm/F1brPm5kkeUpg0aIpnd5zTEjsRcSBuJcOyq31cTon80O/wBVNgPtIlPJmiditDN7UfyW3b62dAPszF/BrdhcB7i6pZzoNNSPTXSBlX7MaZThlRD1WpXU/BQJarDjFCpcV7ennvKJXvfDjr83xfldJ5PJ1sRQu6Y2Pyy6Uem74Hw6TCsz7Fv+fb+rv+NJx9rf0nV/oU/3ay2cg8pV7C/UV2pt3ltV092zN816Wc6lH5wnN2o8nXD1q/EVan3SohILNr8CKhwunHX2zW/RlEIQmkEIQgEIQgEIQgEIQgEIQxAIRYQASRRGgR6iWJTwJNQqlTt0OxHkR7ZEBH0k1MF9T9nn9krK7cs8T+Ts7lvDp3IPQEj7esn4w1O6Iq07e4305elbu+VUHwk5AOc9fv8AKt8LqIXKv80Hp8RjPs6S7V+C06oV6ly4OAcIQoHXBz08ugnn65zrXp473nDOH8yrbqtsKLoDqwXpGmQWJJDeRz/vEp/GrgFXfG+oBc4xnIzt64xPdv6aUUYGvrQk4BOTnqMgbjy38t5SLiuW8Oc+ZPu9T8I55+6nfXzHG7E7nzktq2Gx67fHykI6QnVyWHhl7TSujPR7whhlSRgkdPnbD4zW+HcwVKyBO5QjHV6yZGOmVQMZh9C4GtXZQ2CCQejAdZolDnq2Sloo27B8YwqKo+ucvJzv5Hfw9SS7Xt8ccYLueg332mPcSqaqrt6naXildVLkl6oAXqEHT2Z9ZUOLUcVGOOsnimXDzdbJXmqsXEfiIZ3efRiRkx7RoEC4p2bXppLXApaHCMvjOcVCoTIx+kJ7HL3LfFLJ3+TtQVncUWLMH8SqagxldhjznVw2q38l8L3O/E0B3O4FSpgH2bD6ppFxS0uhyDqu9W3l/wDzOuD7fDn4iZtaZPd/yrYXerNNri9PRArhyGAAAIAXdh8JoHD+A8RRHJv6a1Hc1HVbZGQOwAYaiQSPCN8D3SnWNmE5hQd+tYM9ep4TkU2daxNM7nDKRv0900m6vXW+oUA3gehWdlwN2R6QU5xkYDN9clFB4S3FK9/UpVbinSrW1JgG7lXRkqshJXpkHShBPu23nj9oHMF/Qd+H1rhKiPTUsVoqmQ2+B1I6dZpNMf8Ayz+3h6Z//TUH8JlPbF9In9TT+4xB38J7KHr0KVcXSqKtNagXu2ONahsZ1b4zPB5v5Ir2Gl3KvSY6RUXIw2M6XU/NJwcdRt18pr9pdvS4MlZDh0sFdDgHDLRBBwdjuJF2jeLhNZmAyUpP7j3iHb6zLtHzzCEJpBCEIBCEIBCEIDsQxH4hiUMxFAjsRQIxNAEeojQJKiwlBj7clWDeQMUU5MUwJrGddF3aH+cTceYjEvXxjW23lqO3wklpXYLt643+zMur0qQtwijLFQ+4wGUgnVgqMjbr5Tn1ZP43xzbv1Qaiu53JP+/OMuKQRdI3Y9T/AAna7MNgMAjO2NwehzOV0m5IxbdecqR2idLUoLRjF9nOlInoCcbnAJwPU46Cejw18EDHWezylW7q4R9BcnKqng3bGernC7Bhv6x3OdOjTvandJoUBMoMYRygLgY2xnfbzJnPduOn5JXfTukpprY4Eqd/fGozEKACcj1kT1Wc+IkgeXlIm9BLOJPqdeS9fEZEbidJAIMh042m8Y0zREYSWMYSLq+WHGrdbDh1Fqqh6XEFq1F3yiB3Jc7dMMPrl4bnGw1g/KUx8r158fzfkxTV83pq2mFYiGZ9V1qXC6FqON0K1rc993z3NR8DAps9N2CjbceI/VL7e/SVr/Vrn8dCY12XfSlv/wDZ+5ebLe/SVt/Vrn8dCZsxoxPpZ/7PT/M1JlHbF9In9TT+4zV0+ln/ALPT/M1JlHbF9In9TT+4xP0aS30D/wBuH+Xjuf8A6IrfqqX46ca30D/24f5eLz/9EVf1VL8dOB89QhCbQQhCAQhCAQhCBPiGIsUTTOmkQAjyIQaVEzJQ2Dt9sTptAiVk7v8AfoI41CeuPdIwskAhDqDkHA3B3xLoeOO9stHUKjuqppTBbwZ8BUdNsEnb29MylIdxgZOcY9cz3OG8Wa3pOV0d5V6OF8SINsknrnB0j4nOwmeuZW+erzrz6ylHNNiC67HB2H6PwiaB5n7MziKb5/1PxPrOihVI2+3zmo51LoX9LHuH/uc9a4CnCjV7TsJ1tXOnqc+uTPPCQR6XL10yVO8IDMmXAY4BAUlgceWPLrIaua2qpkli7E5HUEll8zg4zsfZvGUjgtp/KGk+4gg/YY+g2kEev+xJOfutXrZjhZPLpEVZ01F85GBtKiMD1iOI7Ea0ERxrR5mr8j8i2dzY0risjl3L6iKjqPDVZF2Gw2UTNuNyayOIZrvLHINpWa7NRHK07p6NPDuMIgU7kfO+d19kh4TybY1eIXdrobu6CU9I7xs62GXJbOTucY9kz7LihclcUS2vqFw/zFYhj6K6shb4as/CfRK29J2S7BDFUZUdWymmppZiMHBB0LvMs4vyPbU+KWlsqN8nro5ZdbatSK5OG6j8iejzNyZbW5s6VLvVSvdpSqJ3rlWRgdQxnAOw3kt1Xs8E4zTueLXLUmDJTtVpawQVYrVLsVPmAXIz56Z1c38rWddK11Vpaqq0H0trcY0IxTwhgNj7JWucuRLC1tXuEpuCj085qMRpaqquMH9EmSc29nljRs7ivRRw6IXUmozDYjOx67ZmVW3ly1Srw23pVBqR7WmjrkjKtSUMMggjb0la7WOYKNO0ayVlarU0roUgmmqMrktj5udIUA7nJPlGcK7PLBrOlXqU3Lm3So57xgMmmHY4B2HWRcp9n1jXs6Feojl3QMxFRwCckbAdOkoxaE36t2ZcOCsRTfIUkf8AFbyHvlI7NeREu1N3c6u6DFERSV1kDxFmG4QZxtgk53GN9ewziE+guLdmlhVQolPuXx4XRmOD5akYkMPXofaJhXFuHvb1qlvUGHpsVOOhx0IPoRgj2GJdRxQhCUEIQgTxREiiaYLFUbxI9BvAfACGI5RDJcR6CLoirKgQ4DHzxpX2as5P7IP1xydP9+6MCzoorBahIklPAIM62tvDqx5/+5C9FtRGP9MQmmOw8ukTAMR0MRFYb+kKF6yRhHXNLS7qB0Yj6jImaAjdDID0nSR4Cf8AfWcbGEhpjXEfGNI1DTN+7Lvoy399X9/UmAzfuy/6Mt/fV/f1Jjp05exy/a6EfPV7i4c/3q76f8IWUHssvO+vuIVs5DnWD+i1Ryv2Yl/5gue5tLioo3SjUdf6WhiPt3mZdh/87dfq0/G0yrQOP2Wq6sK+N0r1EJ9FqW9Q7+zNNfrnDzz/ADnDv7Qp/c0tdSmGxnyYMPeP9CR8ZVOef5zh39oU/uaRTe1b6Lr++n++SdvHqvecKrVPz7Jn+ujrnF2rfRdf30/3ySTl/wD43BkXrqs2p/VTan/CB18bbueF1cbaLMqPf3WgfaRDkD6Otf1Q/EZxdp9XRwyuB56EHuNRQf8ACDO3kD6Otf1Q/EYGP8c54v0uK9Nblwi1aiBdKbKHZQPm+k1PsrI/ku3x/wBTPv79/wDSZ9z/AMhtbLVvjcBw9YnRoKkd4zN87Uc4909vsV44ClSxY+JSatP2q2A6j3HB/vGW/guvLF3VY3aV31GneVETOBpplKboo9gD/bMY7UsfynXI8xT6fqklq7aOAbpfouxxSq49R/NsfhlSfYvrMml5gIQhNIIQhAngIQlZKBJEEjEeJUSCOUxgMcvWGU6vF1SIHaIWlR129PUCZLQE9LlugjI5YdDt9Q/1nEiYAMsjNr3re11IBjfUPuaetT5eLu23zmx09TmP4Xp1D08Pt3CYP8ZotilMhvLI2Ppt1nLrrG+OdY9xS3pJcrRV0KacM+lhiplvDnJGB4Rnpud9o/i3C9PlghR9gxOnm7iNqzslFFGklcqcqcbZU+YPrLBfmnVtkqoc6qanJGCT+VkeRzmXnpOuVD4ima1Q+rt+Izy66YYj2yxcXQfKHxsDWbp6Fz0+E4ea1VbusEAChxgDpjQvSbRClrm2Ln24+Bb/ANTxDLIK4+SafPS32u+P4StMZaQMZGxjiYxploTfuy/6Mt/fV/f1JgM37su+jLf31f39SY6dOVjv7Za1GpSO4qI6H++pQ/fMo7EARVugdiEQEH11tNP4Hc60c+a166fsV3A+zEpHZ9Z91xPidPyDAj+i9RmX7GEy0v1K6BrPSzuiI+PY5dR9tMyt88/znDv7Qpfc0k+V6OM915VLAH3tTrOV/wALPI+ef5zh39oU/uaQJ2q/Rdf30/3ySLsmrauGU166HqIfi5fB/bkvar9F1/fT/fJPG7Ea2bStT/Nr6v26aj/wMv8ABP203BWxRB+XcKD7lR2+8LLByB9HWv6ofiMpPbncHTa0/ItUY/3Qir+JpduQPo61/VD8Rj+DK+fOeqlytWxakiolYgOpbUe7ZlGQTjeVDgPFGtbincp85HDY/OHRlPsZSR8Z6vH+X7s3Nw4tbgqa1Rgwo1CpBdiCDpwRjfM1bs34Rb1OG29Spb0XYh8s1NGY4rON2Iydhj4S/kFlvLelfWjJnNKvTyrY3AcakYD85Tg+8T5nvrRqVR6LjDI7Iw/SVipx8RPorkwOqXFNqZRUvLhKQKlQaRfWpQYHg8ZAxttMW7TKYXidyB01Ifi1JGb7SYgqsIQmkEIQgTCOAiRQZWCgRwjMxRKJRFAkYMUGGcSGAjQYu8o9XhV0UVh6yOnW8pw0quNo5Hl1PVbeH3+nG8sD8SNZDRBcaxjKZLe3bzHsmd07ievwsq7AM4T9JteB+xvM9TSXHmcQ4W6XAou2CcHJUg4OrJx/dP1y01eKAIEQAKoCqPQAYAnicwArW1GqtQqiqCgc9S40jUoI2JO/r5+XlvcH2xzDr69a5u8kt55z8Z5t/X1uWJ3J/gBOZqxkRea0kd/ff8LT7/vJ/jPPYxTV2xIzJaSDIiNEMaTI0WbJyBzbZULGjRrXKI6mpqQq5I1VnYdFI6EH4zGsxpks1qXG1cq86WaG6Wrcqoa8q1KZKv4kcKQRhemoMd/WM4fzRYJxK6uPlKCnVo0sPpfBZMqy/NznCqfjMXMaZn1XWp8c5rtjxm0u6dZWpJT0O4D4XWaitkEZOA4PSerzbzdZVXsWp3CMKV4lSoQr+FVByxyvT3TFY0yeq62rtD5tsriwrUaNyruxTSoVwTpqKx6qB0BMrnZJzDb2puVuaopq4plchjkprBxpB8mEziEeovvaxx6jdV6Jt6gqIlIgkBgAzOSR4gPILL1ybzhY0rG3pVLlEdKYVlIfIOTscLMIhL6j6NuOeuHFGAu0yVIG1TzB/RlG7L+eKVCn8iuW0KGLUqh+YNZyyPj5viJIbp4jnGBMrhHqr6Q4tzzYUEL/ACinUOPClJ1d2PkPCSF95wJ8+8Y4i1xXqXD/ADqjlyB0GTso9gGB8JwwiTEEIQlBCEIEwiwhKzRFzCEqFzFDQhCFDRdUIQEzDXCEBwqzsseKtTbUoUn2jMSEGQy/4i9VtTEewBQAJymofWEIBriZhCAuYhMIQEzEJhCFJmIYsIU0xphCShsSEJGhCEIBCEIBCEIBCEIBCEIBCEIH/9k=",
            },
            {
                id: 12,
                title: "Blacklight",
                genre_ids: [28, 53],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhUZGBgaHBwYGRkYGhgYGhoYHBgaGhgYGBkcIS4lHCErIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHzQrJCs0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAQsAvQMBIgACEQEDEQH/xAAbAAAABwEAAAAAAAAAAAAAAAAAAQIDBAUGB//EAEQQAAIBAgQDBgQCBgcHBQAAAAECEQADBBIhMQVBUQYTImFxkTKBocGx0RQjQlJy8AdikpPC4fEWM1OCorPSFRckJbL/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAAkEQACAgMBAAICAgMAAAAAAAAAAQIRAyExEkFRImEToSNSkf/aAAwDAQACEQMRAD8A5RQoUKYAoxRUYoAFChQoAFChRigCThE1osakNU/htiSKPj1lVKxvWfr8qNfH42U1TuFYQXGIPITULLWnw2DTDBbjNLlSCm8EwdacpUiIxcmVPB0m9k9R7UvBWYxJSObCrZ+JskZEQAnSFTY7meZ2586mYbFI4717alkJh8qiRO5YbxNQ5PtF/wAa5Zm8LcAvNJ0JInbnyHOnOK3ADlBHqNRPM+YA0HXXpS8Tw7OWe00kknJs088vlVTecsZO+0bRGkAcq0i0zOUWuiCaKhQqyQUKFCgAqFChQAKFChQAcUVChSGCjFCKkphZHnSboaTZGoUcUAKYgRSlFFFa3gXBbb2wzCSRM9PT0rLJlUFbNsWJzdIhcHtyyg6Dr5VE7QIBdIBnSrNLqKCAZyzr9BWfvtmYk86zg7dm+WKjGibgLKqhuPE/sgkTHNgOvITTZv530gyTp59PmfxpnG3GJgmBA0BMbdKYW2eR+3+dbKN7ZzylWkSb+KzgnLGgnzIMTrtvUzCYoxmduoRQBoOev88utRcNw265MIx+VbHsn2Ge4wa6Cq9FIn8DRJpEpMor+LzgMqIsc5IfTeY0qr4rYgq42uSfRgfEPqD867JxbsVbCeBiCImVDEjy2NYDjXBgthwjhwn6wMCsSoOfnIMcjrIFQmkxvZiaFChW6MgUDQoGgAqFHQoAKjoUKACo6KjFIYBT632AifLzimBShSasabQBSgKNVq2w3BndM425VEpJdLjGypAqbhr7hSiuwU7gEgGmWtkEg7jQ0/YSok1WzaEWnoN2EaCNBp5xqaatWSzAASSdqlPZir7slhENxnf9kaes1k5+Ytmrj6dMzz4YvfK7QY8hHIVO4FbUXijgGCRr6/lVzx3hq28Tavpql1tRyDfkQfoapca+S+5JykHSADtsTrVwn60voynBRXr9nQbGFKEALoYgjpy2/nStP2fLDXkZj3rFcK7Qi7ayCDc0MD+NPhJ6jNUq92ua0zWrdh2dZE6BYzfFlOp386lKV0JteTecTuHI/wDDy+1crxtw5cTdIDoisM2SJLaKHnRtSOVbvgWLxNxj36ZeYIIYHzUisn2zw7JgsSdgbiJA0GUXM2Y9ZZAB6mhO5eSapWcqoqVFFFdZg0JoUqKkpg4XM5ygg5RzY5UdRHIMriG2pkt0Rktk7D+fPpRqvvVwcIwQs36lIcIG+K4UYOqP1aHWCRGlV96wTLqpCZsoZoESJAblsKViUkyK1Gqk0RFGAOZplCKOhQFIYYpaik0tallIcspJrqXZCwGwqafvD2Y1zzguCN1wkxzJ8q6ZwRBh7OQEmCT761yZ5rh144PzZzvjVjLiLg/rn660WGSrHjSB7j3ACJOx02gVHsJS9XE08+WElrMa3vZ7g6G0ARqRrWc4TgC7iB610bDYYokDpWGS3ofqjM9oeHAWUCiRbdD8g2secTWAxmBfvriv8QZgZ3iZHrpBrpeLvG3bdLwnMZB61nON2rdxP0hDDoFVxOsaAA+cMtXgk4vZOReo0VHYK6qY1GManKJ6n/QiuqY/hNh7kgqt3fK0aidwD9q43wfFLbuhyhZswIjbnp5b7jpXTuLYu3irKXCxtsPEjg/Ax0JLRrtqDpXVO7OaOkX63GtqFIPrpXMv6SePvn/RYXuyVut+8x1AWeQET6xW5wGJdsPmuEZllWjYkaSPI1z3+kfCQMPdI8Thw39qU+hNTjX5bHN/joxpt66ajl6Udu3OkSam8ENtnCXSQh1BXef3ZgmD/O9aE8MVrge21orOUWrcqwWNGYvBdtgY9edbttHPdkzst2KS5aS+7uGJzIEywuVtCcwMmV9Kq+J4IYW81pB3t0ZfG8ZFVu8tqpB0gh7RBMQR0q8t8euYVu4Rc4Pw2wpLh2aCA06akHUNPzrL8exN5znvOqs+vdrqQHS26sQP2SQuhOhU6VljU3JuT0GTy1S6Jwl1XdSytibzlQEOiQyFMjcy6nJBGmlK4rhXCZ791c5RClteeVjbyuBorAA70nhjOA4W4thCA7GYchStxch+InVSIIqY9q1JTD2nxLubiZ3BysG1R0B2cAMa3+TmbqRmInbwrMT0nkSNToOlNVJe3vmJLQI94IbpoKk4UkZgtnMJnXUgHYVRp6pFZQFCgKRqKFOKKQtXr9mcSlrvmtwgGY6jMF6ldxWcpKPWawi3wX2XtM14AGNNfTpXXMBhVyQRP+lcW4ZiWtuGQ611HslxN3Di4RplKjbSDNcOeL9enw7YP/HSKjtRglFx408Ct7T+VUGGTWtB2wuZroyt+xqB6mKreF4bO6r1IFZxdI0ltI1HZfD6Mef2rZYcDLJ5VW2uCrbQ5GOYDWYgxvpyqrx/GTZQhiBPM/anF2zBq+EHtpxVCDHwoCT5nkK5vw7iOV3DnwXQVfyJ+F/kfoakdoOL954F+GcxPU8vvVEzV248a80/k55TqWvguEwzhwFmQwAgkazpBG3rXRuA8PYIe8tLBn47nfeshvh+Vcrw+MYACdog8xGw8wK0OA4hiXhGusobUGN/nTlFjTXwbnBlB+otnw5iSAPCNScoP2rM/wBKlzSynMFj9B+dazheITuFuvlXu1Kv002b5/jXLu1/EziLxc/CNFHRfPzO/tSxxblZM5UqKGeY5VoOHYsXCixDDMHHIzGUjy/Cs7SkkEEGDyIMEHyNdJztWbnD4h1lCTHw6EgwCCMrDVdQDpzFRsRwdGQmzlDyCS5JYx3mbKdtQ6/3YO9VnDuIswDOZKuAW6gwNfer9ElGeYUZm06DUfalRnJNPRnMDYVbgV7L3CD4k1BJ8SiI5S1vr9a0rpiWteJreFt/qnOWFYgHuu8SNZ0JImqt77ZEcs2cBXVx8Vs6NIPqB7U8/wCi5Je5cuvluKF1AR58B15HxEjrUuzKb+SoW0A5S3+skugeIDA7MJ20E/OnsV365X0QOoiBEhdBp8/rSxiD+kq9lO4kpkXoGGQkMw2Op2jWpt3hmbw3cSFZGZYLEwJ20YfyadkvpjaMVKdZEDencFw1nbLIAAknek5JLZ3KLZGsXMrK3Qg+xmuoYntphu4bKWZ2UqEKkQSpHiO0a9a51xPhrWGAJkMJUjSeojrUdBWU4RyUzfG3HRIw3xCuidk8IXJJkFVERpuTNc/wmjqT1rrnZh1gQI8Nc+fqR1RdRbM52n4cLbqRMuDPyj86Z4VuPLnzrQdr1ByHzb8BVPw5Irma1RrB3Gy6452u/R7XjILsDlQbt69B51y3iXF7l9y9xp6AaAf1VHIVG4tj2vXXdjuSFHRQfCPaoRau/DgUVb6cGTLbajwWzzrSSaTQrpOcWsir/DceiwLLIpZCcr65gDyjnVOiSAaeKCk4p9GpNcJp4ncYEMxI6HYHqFGk1Bx5EDqTS22qHiXk1XES9jdtZIHUinrtgLEkgHnEgj00+9L4baLPppAJ+cQPqfpVxicJNlZgicqkToZ8qAICKFw7gHxaNI5hoKkfIVb4a7DYmyWgG2oHyAQ/aqTidk2yF5Migj5bGnsfci7cPUKP7QU/egTRMsXiENsiSynU7gHRAPkJ+Yp/CcRuW3C21QksGQsqkyVNsgseRD8+gNQeFEu7OfM69FiPrkH/ACmpGOsroOWUD+f+mnVoylHRCvO7kZyWhSgnWAmuVTtoOnI+dW638GrNmzvOUhtv2RIjSINQsBcs5pdHvPmaQTowKwp65s1P3cc4ClcOFGULOX4ipIJ286hmUu8M3ZuQasMDxPI85ZXbz9aq4pzDqCyg7EgH3qZRT6d0W7LbH4t8S6gLlCghZ6cyT7VKsdm7pUNIg7GCZjeelaXDYNGtsIiFMHoQJBHtRHiYsIisuZPFlYmDmmSCPQ8prjlklVQR2Q8N1LpkFtMjEMIKmD6g103gGKRLaknWKidncHbxLXHKrJaToDAOoifn7VeHsykmHIBGwAisZ5HJ84atRjpso+JY8XiAqwoO53J2ppLZCOwB8KO2nkpP2qwfhKo5Umen+dTreGUYXFEasLd2P7skUo/k0P1FR0cPvjWeoDD0IB+9IIpy5ERM5dFPVDqPxn/mpD7n1r1UebLrEzRiioxTJJlilk03bpRPOmIWag3DrU0pAn+TUBt6AND2ZsSGMeY+oA+pqZw9GDPaIOUsDyO/xDKdxGunSonZxyGZR/MCPt9aue+BdTEMxCnXmJMx6A0AU/a214laNP8ASqrihgr/AFkRj8kC/wCGtN2hwxdRAmIms5xtIZPJAPb/AFoRJZ8OCJaBJAJAn8Yj1NPY0gpOUgzEnnI3HTYVRWb4XX4m5dBUpL7kNmMgjY/T0oRMkTeG4i+oItBYBRySBKkHKDJ5SdamXcNiWJVrqgqzSPNoY8vOqaxaDGHfIMrGepGoU+pp24lnN/viQVUzzzGcwPppUtbM6SZUlRFNTrUtKj4g60HUuFrhePOoCkyuxGxI9ak47iffBZAVVmBMkkxJJ+VZyaeRtJke9ZvHFcNISt21s0HA+PvhnJXVToVkj2rV2e3rwf1a+Wp09etc1FwTuKscPdEVjkwxezphL1pmxscauXHLsRJ0iNAPKrnC4loZc2jgq3mCIP0rEYDEAHer7DYvUa1h58vRpSo5uRy/DY+dKfc+p/GhiHEkSNP5P1mnsWBKuIhwD84Ej3r0E+HBKPf0RjRig1EtUQWOGO+k6etEx0Io8K2lHaMh6oQpz4FM8uXWq0b/ADqwLHINOVVwpMC04VdZBnAmGg/Pb61cYe8XvpyyqzxJOpIUb68j71R4AgqVBiSJBiG1GmvnVtw5Id2G2iD0XSgTLZ3kt00+lZTjFzM0+Zq7uXyEbXX+dqzmLad6EL5CtXVA+HXzM06uIMzyOnpUNGilB6AaLfDEbsA6ghipjUTr96ZxF1SFAtERIPnrScC2kRvpTve3ZOo3n31oZnWypz0RNEKOkbmh7L462tvE2rtu8630Rc1hVdkyuWk5iAJ2961XCu1FiwbZGDxTNasph1LW0HgF1nctMgllyLt+9BG9Vv8ARb/vL/8ADb/G5W4wN9v0oo2Nw5XOw7gKoubGEzZ5kaTpyNJlIz3C+2uHthLVvB3m7k/qwUQuiNdcuCAxJJtOqAnmOU1R8A46mGbFC5h2cYgqMjgDKmd2dWnVSUeARzArpAw08VEW8oOFYB9PGRdSdv3cwGuuvSKxPbfABcZfJOxT/tJWcnSs1gk3X6stMT25w7pdRbV1O8LEEC3oGRVAMOP3TyO9WeM7XKG744fEqqBpDWxABUCRLwCCOWT4jrWK7E8NGIxqAiUt/rH6EKfCvzaPkDXUOO8XtXhiMHBMBEfoyurFgvpAB/iFJJy3YSajpIwX/uDhe8Zks4i3muW7hdBaZ7wVMrWbgZjlRugZjvSn7Wo1l0/9OvKO5vIjLa0R7zvIB5pla30IKaCoHYfhAR75dQblt+6BI2AEl16ZpHyptO2V4Ym4hTMisyZEUlzlcCVM6tpMedasxRhlQk5QCTtABJkbiBryo2tMpAZWBOwIIJkwIB31rdfpaXcfhri4e7ZaXDG5byB/1bxHUjX3Fad+GW2xCX31cJkQGIEFmLKObeL5AUxHLLVi4qklHUAblGA9yKfweGdULMjqCYllYfjVv23x2I/SRbc5bQKlFWcriR426tMiOXzk63t80YSzpM3P8D00xHNUQlSoBJk6AEn5AVBe2yzmUqd4YFTHXXl+VaXsdc/+ZbE83/7T1rWwaPxAu6hsmHUqDBGZrlwZvUAaetDAwXCuGXmIPc3MpBIbu3jbSCBrrFSsBbZVAghpHhgyTppG81q8T2kxIxgw1ru1VXRYeQHhBcYswEgbAR5Vd8St3GOFuvbtKy3kTOjszEFvhMoJGk76fOlYHPcbbZF8aMskxmBHPXeqPEWHjNkfL+9lbLHWYiuzdu+E2sQLXe4lLGXPGfL45yzGZhtA96qeOWFt8MZEcOqWYV1iGAO4gkfWiya2crGEuf8ADf8Au3/KifDuBLI4HMlGA9yK6F2O7QXcS9xboSFVWGQFdSxBmSelUfavtDeZ72GITuw2X4TmgQw1mN/KmUUOFuAU3jmhtDvrRWQRrFFjIJB8tfc0GdbGKBoUAKk1NX2I4hdwxuXEwt2+rhVzIr5VK5iZYIw/a+VarCdpbfeFxwo96CCXygOGf4ST3WYFp061heEcbezYxFhc0X1RQwdl7sq2YsqjctsdvnWrTt85d3NlIZrDhQVUqbEGGcIGfNH7U5eVRJnRjhfx/dF6vau+uIXEPgriqttrSJ4wc1y5bOYsU1JNtQBA+dSsT21zk/8A1T3HO/hLNocsn9UToQR8oqksdq7ru2It2lUMptMhuArmzhrdwKtsDMrEnYkzvUPhXGMTh1cEpdzqiIXZiFAdn+HL4sxYySRqedQm/s1eNVtL/o7w/tC9m5iLycOveN8zFQyrbVEAyEi3AjxMdviNMW+22MvkE4YXUSSws27pYAjSWBcLqBuNpqfxDtS963ctth0i4bhkXtVLAIQC1onSP2SvTlVP2e4rdwtoWntJcCXmxCEXXt+NbYRhcARg6xBA0M860WzCVL4If+0d4XGxlrCuLTKFukh2tsVJCv3ipCsAcvParfC8fUXHf/0y732WCe7hpaMgLZM3iggaSY0peJ7R3xaecOit3V6wpF5+7W3cYsc1jJDuoMZpExqKl3e22IzS2GtMe8tMsXCGCW1zC2SUEic7SdRnIg1TMl0ydzjeJfFWbz4e4QjOtu0qvLMFZXUHLLMD8UDTLECmuKcZu4jFW7lm06XLQhUAa4wZWYvKhQdjDCNhrWns9s8QzIz4W33ttLqhzdZJa7kz3IRNHypEgj4yarLPEbqY5+IJaRDcVjkFxoW5cTIXDZNy0vEczrzpiG+LcXfGIq/oF4sMtxHQO8An4tE8SNBE+XUVpv8Aa12QZ+GXWUGPGrFQ05d2twDMj10pq32sxAYs2FteO2lpstzKuZHe4XCtaZVDG4fCQY601c7Q3Rbt2v0dYtsLinv9TlvG6Ax7jNupBggHpyoAquK9pMly05wL2Cju8MMmdWtskAlBoM086iYnjeKOJXE28LdSLQVkZHYPaDli5IUQuo8Wwj5VI7T8QuYq2LPdpbVrzYgl7z3mzsjAhSygIkTCDnFXKdqsSUW0LFvVRaB7x5KHD90EnJoueLnqI86AIGJ48ji1du8MuMzAd23d51ZiZUI7IM0wCAAamjtJiLnd23wF5GS4t5Vy3JZEIkQUE6sPENBI0oX+1t0MWXDoWdrNxyb7lGGFdCBbtFIsliBJ1361Kwfa7EF1Z8PaOVb6QtxlUi66OZU2yMyhImDmk7UCM7214xcxt23bXDXEe2GlAGdzmymcoQMIAHLnSDxe82DXCLgrxzWyiuquwcA+JlUJqBImDpIqVYxV+3jbuLt20DOjoFLnwMyAZwwQAxAOUKBy0q2Ha6+10OMNbi2LlsILrZQt5LWi5rRGndzqDJc6dQSMh2bxF7CO5bCXnL5bYXK6HOJfKJQyxUzl3jWqbiuKN289zKVzsTlOpHKCYHSt/gu22ItkFMIrI1w3SrXVIZmt2wmQqihYKBgQNmIjnXO3vMHc7EsxI3gliSKaGxzCsykmDljXTajxS5gpGm8/Sn7BS4AruwI5E+H1Gm/rT9vh+/dh2HMjafahulZn882U1GKTR1JqS8Li8mhRWEyZAJjTQE7bVZDiyQB3IBG58Ov08z9KogaUDSaLjOjXYW+twgoqAQZWYg+E6wu9LdC2uVAJHPkV0A0jSaz+F4er/DeX5gjXTTUjrU/B4QIIzI+YmSdIiQOfP70kipTJqgEzkWJOkmNNDGnlM0mzblVlUOYyNdYYlobT5fIU3eQEQMhylVMRJBKgn6n5Cn7rr/U216aQ3vpVIzbEtagKSiEQQddTJ00C8oprEYYMQ5VQNgucjXMV0gcyd6IW18TeGSRvqR4QPtQBGUkhPFGmmkwPsfpTEOmyFUDIhzSJBJOpgcp0oyghmyJroBO0Epp4fmKShETCfEOnULv016cqGUajwDd5kCPEdB9KAFJbGWci7RM6zmQTt5fWpLuuUeBTlWdDoRvqculMYe+rpMJDEDbUSAJM7fEP7NOPcVsygIBsCCNzv7U0AzlDKHCoV8Tb/EAOXh/maesJDg5EMtmWDGUBAYMj+qfem8QRI+D9raOv5E6+VKwFxO9CHJIG52IIygztzPtSEyXibGUR3aTLTJGx13jrPyqFw0hngKu7TJ6lgBty/KpnFiDMBDOWAWAOhXnr1/GolpxIc92DouUEGDmgkGPI8qAXBdwqrhcqMwExOpHwyfD1E0w9lQQwUE+Fmhmg+ALERHQ0/wB2AXuHIdJCiDIBJkDlvQgOofwIATA2mZ3U686dBY1aywp7tMoAaJGxH8O8Ee1ZgrLNCT4joD51p0trI+DWW3Gk7p51lhGcyQNTqZga+VCBk/D22cZSjp5oqkfMkzT+FZ0LC1dJmM3hOh1j70Gsu6ZnxC5N/CJ+g+9DBsuoViwEatlHXYdKUuGbbu0UNGKKhQaiqFChQAKKKOKUBQAS6UmKcdDAPLb59KSBSQ3aEEVKGIGQIUBiSG2OY85j008qjmlEaUxC0dAACgJ65mE+xpVnElVZABD/ABSFM/u6kSIOuhFMUajWgBYIn4B/1fnUhsSMioUWFM5hAc6nQsBJGp+nSorbn1oyKaESMTiwzh0QIQoWNG20H7IG0DblTmCxTzEj+yvOZ5dTUA1IwQlo6j8CD9qmk3tFemlpss8fiHDDUbD9lY1010qt/SWzQxB15qn5VZumYnwySPYjXr5VU4hIOnPWn5S2kL22qbZYC+RoGVNAQQqjnEHT0pC3GYgeEyYByodhMjSkWWDBJJAJKNzMN/mBUjHsltgE1ZZk7a5YBgaTtNN80SqtWVzYgk7LE7ZE/wDGnsPbaZykj+rAI+ZFQ0X2mKnJdVZCz70IGSbgQfCHnnNwH/DUnC2gwLadI1kR1PPeoFtHbRVOvMiB8uvypeJuNZhUYliJfpPKPrUyTfCaVlTQoUKZoGKEUKFACmoweVJFLTmaQ10LOYjlMx59aDCKCLrTmI3/AAppCsZUSacfahbFHd2Hr9qTKS0M0q3uPX/Ok0pBv6H8IpkiVNKzGkUYNMAGnsI+V1PKYPodD9DTdJoEa/B3CoOZeokiPp7+9U+Ow3g0mVOvodRTzYhyq5diAT68/rNIto75jE9T5eQ96ZKRWWBKuJ5T7UeLMkN+8AfprSshR/ofQ0yx09NPlQUJQmZHLUVecPxAcgMkn94kj6VUYUkGRy5eVXFq+FUNlGu0SD7UCY/xXEBBlQwx0OUax0Lb1ScSYZkH7qKv1Y6+9PXXLMCDEHT1qJjXl29vbT7VL6JDFChNCgsFHQoCgBSrNTUQKFAGZ2aACARp5NpzHvUfC/GD019tftUliQ075Fk/xMC0/Vfape3RS1GzR9lrC4l2R7SQo1IUTM9eWx2qp7VYK1avZLcgRJEzBnlOtTexnGRh2cFM2eNQdtDVDj7ha67NJJZifLUwPSIqUmpP6G9pDaLRYiNhyH3pQbkP59aT3JJmdDz8qdjq9IYoDn7fX/KhQqzMFKtET4hpSaKhgOXkAMAyORpuio6SBlpgLx7vLPwn6Nr6bg+dXHDXgE9azeDfxR+8I+e4/nzq0s3YXnVrhAni2FIOcfMfeqhjr61aYniB20jzqrfU6UmNEnCIc2mvI/OrSSqxl5cjE/I0vA8FuhlHgTOJAYmY9Iq9xnZTEi2WXI4Ajwtr7MB+NL3H7KcZfRk7bKXErA6DSq24ZJJ5kn3M1P7tkch1KsAxgiDoKraPkVUg6FCjigYIoGiBoUgHbMlgOsD66fWKmXmARuZdyZ1HgUkRG2v+Go2HGjNzACr/ABMf/EOflUniGVSEURlUA/xES3/6j5U0OwYDFtbB8QAPkC2ojQmody5JJ/ypsCgaVBYsNS3JjffSmhSxsD5ihjTGqUaNd56a/lTuMQB2C/DMj0IkfjRe6FWrGKKhRmmITQoUKADBirS28jeJE9PUaec1VVJw16PCduXkfypoljl20dwJHWj4Thy9+2g5uPpr9qTcJ1Ex5VZdl7ZFzvc6oLe5LKp5TodxFEnSKiraLztahTFWkRspC78tToPxra3uNC1ZRG1Ygajl1msFaxX6Vji8+Fduh1E/6Vb9oWDNzhVPONf9PxrmkuJnR22Re1HEbL4Z1DDvQ6ZNNYkhwDy0J9qwE1N4mQHyDZd/NjqfbaoVbY40jCbth0RYDnRg1seynHsPYsFLjFXzsx8BeVIWNQPI1GWcox9JX+kVjipOm6MbnHUe4oA10v8A2uwv/EP9y35Viu0uNS9iHuW/gIQA5cskIATHqKzw5pzdSi1+2aZMUYq4yTIuEXYctXPykDaf63KmsTcLMWJ1JJPqTJpaXIUzB0yiemnL396jE10mAKOioUAHSl86FpgGBIkAgkdROoqwXGWZP6r/AKVH72kTA3Go10qJSa4rLjFS66K9iIgev5UKsRjLMAdzrpJ8OsCPx1o/0yzv3Mb8lP7sHKdOR95qVkl9Mv8Ajj/sirNFU+xiLSs5a3mVj4BCkqNdJO249qWMXZ0/Vct4UxoBsfi1BMnrTc5J8YlCLXUVopSip17E2mRgtrK2uVtNJedf+WB71B5VUZOXVREoqL07EmiozRVZArOdpNEOlFRgUAW3eKiZU0Mak9edE3FLhWM2aOZkmByJO4/KqvepFtREExNLyvktyfwRnckkncmaKn7uGhcysGXaRoQejA7VHoTT4S010VQoChQAKFChQAVHRCjoAFFQoUACjWgaIUAKoUKFAAojS6QaAFoYNJJpX5UigGChFGKDUxCaOhQFAC0WpBWDB8qd4MgLiROq/jTN5ySxJkydaSe6Ka1ZEbc0Io7nxH1P40mmSf/Z",
            },
            {
                id: 13,
                title: "War of the Worlds: Annihilation",
                genre_ids: [878, 28],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhYZGBgaGhkaGhocGhYYHBocGhgZGhwaGBocIS4lHB4rHxgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHjEhISExNDQ0NDE0NDE0NDQxMTQ0NDE0NDQ0NDQxMTQ0NDQ0NDE0NDQ0NDQ0NDQ0MTQxNDRANP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAQIDBAUGBwj/xABHEAACAQIEAwQFCQQIBQUAAAABAgADEQQSITEFQVEGYXGBEyKRofAHFDJCUlSxwdEVU5LhFiM0YnOT0vEXcoKi4iQlM7LC/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAIREBAQACAgIDAQEBAAAAAAAAAAECESExAxITQVFhIhT/2gAMAwEAAhEDEQA/AOOQRVoLRkTBF2hEQAoAIIY0gBiAww3KCMAIDAVhqeusABENFubXA7zoB4mBVJ0120+DyhAQAK1uX4RIEVaBTaAGkMw1EIyaqC5QrRUMrECGEEXaJUQB3NYQXsLDcxGUyTh116/pA4L0IAHXpFU21J5AHzP6R2pT3hMmlh0Ht+LQGjTbgdBfzMDHSOLSJY98WlHe/KA0SovqNxT18VPLyt7JO7O4T0lQFyQg1NtSedgOp27ozRpkAm3cfA6fjJ2Aq+jQsv0icia/WP0iOthb2wORofnS/uE9ggmd+YP+8X+P+UEFMvaKKWFyfLnBpEmUxHyvEmHlgtAChiFaGIAIZ5QWimtpbwI698YFf+cIw335Du5QL7e6AGh11vbn4c7QXA2v3bddIV9dNIAIALQWg5w0Gvx7rwBdPbvgIhUvpR1k1k04QFkyjhCReFh6cs6ZsLSbWmOO1ZVwhEbOFI5TS4SmGOol1T4QjgESLm2nh3zGGTDE6WgVCDbnOhp2fTcCNjs2ubUW/WL3P4WTwnDme2l7+Mltwd76LtvOhcL4OqKNJa08EnT+cXtVzx4ztzjDdnjuV0I08Y43Z5tDz2/3nRqlMdLCRKlhe/vk3KqmOP45nxDhD0/pCynTzkT0ZuOVhYdF+03jvOmYykjobgTFYjCktlVDc/R008SZWOW+Gfk8ck3Ff6RPsj2CHJX7Pb7Y9ogmm4wYVCt/WvbXbryhBecSYYM0YhFW3B3iYdhGWwAgB1+BDPOG513vtytAxEwjDtArfBgAtBb47oM3InQecANrQA1Gn4awWsYL+W+usA6XgBX6QRba3O3xyiTaAGh1EnAa7RnA4VnJsLhdT3SVUpkNJqsZxs/TTTQSSixNJbDeOokzrbFO4cNZrcALCZnh9I3HOazAgW1vMsnXj0m0V12vJyKPAximijUaR9GI53HgICpCkDpFkxkd1h4Wjgpn4vGgh38ZEri5k100uZFrUr2MnKVeNiJUGb1R+Ep+K4Nhco+nNLgeYv8ApNAlLYkTPcexYN0va17ab+3b2wxLyXcUXoP7h/zP/CCN+n7zBNeHNpgcp+LQxDZfZCm7mHy84LQXh5eW55W1hADNfc66CFcmHz8D8AwnPl3D8oAN/ZCZdbQ9ItabN9FSbA7XO2pPvgCB3wEdfCER5RScwRy+DACy6XgBgvDUD4EANiRpeEB8axxmXkN7dN7626eGsRf/AGvGld9mzlZnAuDZSO46/lHuI4cB8w2OsLs22jDQkENbytrJWLqq7hVWxA16TG9uuYz44TQp+qDAz2jzLZRK/FVSNBfxiHS34XiwzW2mtw1ZlsdxbcTmFF3DXB8Jd4XjlRLXNxIyxv01w8s6rpmHxYYD85LDoOQB6jSc/wANx+++ngZaJjXZb7zO2xrJMuq2aVlG5/KJOKudJnE4koHrGM1+06INAT8co5dlZJ21NWoFGZ2AtK6jxlKjEJc2O/KYTinHKta4W+UyLwurXR7rex36StcImU3+upLrMj2hw/8AWEBdfqnkbjY980HCsVnQE7jQyJxajaoHYEpYE+IB2ilFn0yX7If7J+POCan9s0vsP/CIIbP43FFXyhjwgpjXU2HXeAjcHfS353nW88RHs84aked+sSCYvTTU/HSALdDf328RfnGc0M+EMHcfHjAEmGjkbEjw6HeACJywBRNz4xVVCCL2uRfS3vtsdNohhDy6X5fHtgBQK1jcbw3I0tAq32+NYAH30jiZbEkd1r289tYhha9/x74RPjBKx4LiMtZb7NdT57e8CXmHwJFUlvo2J30Npk0cg3G4N/MbTdJlKBr3Di6jpcXmeU5dPiv+bDNcX0kKrgiTJgbaTKSgiZW6bY4zLtUUOAs3O0N+zbjn4azZ4SqoUAxGJrqLxe9i/hxrC/MKiEkjRed950XgeCz0we78pnsU+fS1hNj2WYGkB0hf9CT03pmu1NNqagJ9Im3gJk6OEqOxBBHiZ0/i2FDvbptKOphcj6i46yZfVVw9uVDguBVeZ0F/PppLfDcGqJYnS/IEsPeJe4B0O8u1ZSAByjt9h6TFX8Kw2RRfeK7S02bDtl30/ESY5v4SQmqsOdufLp744m3V25/+y6vQ++CaP9pD997oI9RXzQ528+Tqg+GL4OiqVafrZUFvSL9ZfG2o/nOFa6j4vPUfZHjoxmHSqVKOPVqIQQVcDXQ8juO4zknys9k/m1X51RW1KqWzgbI538A1za3OdDzOmV7EYNKuOw1OoodHezKdiMrGxHlO/HsLw7nhKI/6Zwf5PT/7lhf8T/8ALT0pjqRem6DQsjKCepUiA0zn9EuFfd8N7V/WAdkOFfd8P7V/Wc8HyUY/7xR9r/6Ia/JRj7/2iiPN/wDTGlveI/Jxw6qpUUFpkjR0upB69DPP3HuGnDYirh2NzTcrfa4H0TbvBBnqLCKKGHRajg+jRVZ2NgbCxJJnmrtjjlxOOxFWlqj1DkPNgAFBHja48YovWlTg8I9V1poLu7BVHedNT0nQa/yXGnZK2Pw9NrZsjX0vzALDpvblKTgXZ7G0a9KscJWIRwxATp/vOi9peF4PG11rVqeNSoyhAq0yLhbn8CY0XL+sRxn5OKlFKdVMRSq03dEzqD6pdgobc5hc20kzEfJl6Bsr8Qw9NrA2YFTa+hAJ6rvLTifaXCUqVLhuHFZilemXLpYrkqK5U82YkW285Y9qO1uMOJFPCYQuvo1YipR9e+ZrkXv6tsvneBW39co7R8LGGrGktZK/qhs6fROa5I3Oo/OVd+VpreOcG4liazV6mEqBmyiy08qgKLCwEy1WiUYowIZSVZeYYGxU94N4LlNgS/4TjsyCmRYoDY9Rv5ayidSCVNwRyk/glWz5ftCKzhWNsq6DHnvJOHr6yLXJuT7v1jd5jlHVhk0dDFjnHncNylHhq1t5KrYyy6GZ3F0zLg7iHF7C01/ZVxktzvOf4EF2ZjrrpOidmMNlTxMqRG9zacy+sxMZqYdGGgB9kmY2mMw6GUWOxQw9QDZW18JOU0rHk+uGVTf3c5KSsOUYbFK/rCJLdN5LSzjlKSpc90k4rELSoPVc2VR7eg89pXUV11077yr7bh3WhhkOrlmPgouJpg5fNdMX+12+yfbBLX+hlbqvtME04YezoFP5U8CSBmYXNr+rpc7nXaa3iWAp4qg9J7NTqJa46MPVZT1GhBnlenhqmhVHI5HIx8xprNFh+0HEaNNESrWyKuVVHp/VC6AEAi3d3S+WKx4DwR8HxrD4d/q1fVPJkKsVYeXvvO+42sUpu43VGYA9VBNp504d2gxHzzD4rFeldaLEklXuFsdMzX0uZqcf8puJxjjC4SkqGr/VqWIucwPM6DSFoIHyy17f/BT9j/64tfllrX9ahTtzsHvb+PSZntN2Aq4HDJXrVEZmcJkUE2uCb5zvtyEyLN8frHoPWaFatNWZQysobKwBGoB5+M80dtMKtDiGJSmMqpVJUdL2ewHQEm0fo9tsfoiV6h0sFVqmwHIBuglPjUr1XepUWo7uczMVcknvJEUDrPyUdpMTiGr/ADiuXCJ6gbKADptpKr5Oe0mJxOPQYisaioHKhsoAJBW+ndObphqwvlSqt+iuL+wRspUp62dO+zL79Iy06xj+L8JONem2Edq/pmBcMQC+fVgb7XF5sjUX9qIwYWGEYbjS9QWF/ATzitWxzc+tze/UEc++S1o4g6qtY35gVNRy15xD1ehqlJ8xIWodTb/1agWudQOXhPPXGEK4iur6uKtRWObN6wdrnN9bXnzhilivsVz5VZDemwNmVg2pIIIPedfOOCTRJU72isPVyurdDEqYWa9hGI0pcsubfb4MIdJH4a90CjYR9hrM7G+ORxWirltI0+nOOUyxGm20jTT2OrWZCABdTvbcTY8K48AoF5lEwp+uNNNuZ6eX6RithnQKVJBJPT8NYrF45+v1t0bHcdRFDMdeQ2uekg44emUM9hppbkD+Mo8FRZVDVAz5ltfLounfpvLgsnor3IZCQLggNcbb215Xk3Gtcc5OUPCuyHKfKX2EUkayAiKyoRZh9U39YEbqx5Hul3hKPqjTppsbSZOdLyzlxLTDA2GovfW36zF/KF2jenV9BTyqcnrsV1AIOim+k3mLxKUab1m1VFJ3tc9Nec4PxfiD16r1XYksxIBJ9UHZQDtab4YuDzZ7H87q/v3/AI3hSJ6M9/sME09Yw5eluyLheHYZrbUFPsUmY4fLJhv3LzYdj3y8PwzdKCn2KTMp/wAYsL+6q+79JNq2j7H9sKXERUCU2X0eW+YXU5s2gOxOm059xHAU6PaKgtJQqs9N8o0ALK2aw77X850Xsn2vpY9XNJXUoVDBh9sNYg2/un2TnGOwZp9o6QLs+aoj3Y3YBlb1b9BaEGml+W/+w0/8df8A6NOFAXnpbtx2YOPoLRFT0eVw+YqXvYEW3HWYP/gw/wB7H+Uf9ce4TN/JCAeJ0ufqVT/2G35zr3bHtYmASm7oz+kZlGXllAJv7ZhuyvZY4DjNGkanpM+HqVL5ctrhlta5+z75se3nZE8QSkgqej9GztcoXvnAHUW2iDO/8X8N+5qTX8D4pQ4hh/SCmGRiVKuqte2418SPKc/PyNN97H+Uf9c3vZXgS4DCiiXzBSzM7DIPWN/IDXmYGw3Y/szh04ri1KBloNekrahC2VhodDlDWF+k33GOI4mlkGHwxrKQb5XRMvQWJHtmB7LumL4pja6V2RS65MuX18oyhrkbEK1rdZtOL4XHgr82rU7WOf0yte99MpQbeMVvJ64N4XjePZwHwLovNjUQ29jkyh+VPE0jg29JQqCpdfR1MgsrEi+Z1JsCLjU6y4w1HioYZ3whS+uUVs1u64teSe3FdEwGJ9IQA1F1W/1nKkIFHXNbwhN7KvNZYwLCMAMslrgqmVQR9qWdJgTrrKag3qeBjj1SNpKot6zja3T4vGaePVT1sdBra42vK5HJ85Kw1ADfzgcqavGOoJOoGl9/GOVOKkkMc2l7DLa0GGpoeYHulunDwEDl9Lge/nIrbGS/aMnFKzAKiGwy2BNhpyt0/WLr4nEqhBUAFs1u/Xl7ZdMtFFDZ7sDoDzIHht/KKpV1qNYbEXH4W/nIuTb1lmpULsxi1qtkt69rjcWtv7p0Lhwslib2089rTnOM4cabZ19RwL20vpf2iwkvhXHXqOLXBBUHU32y389SeWsri8srbJo78oHGgqfNlFs/rMN7Dz7xeZfszw2gzXe7vmASny1t6x+1z07pH7Y4vPjapvcLlQf9Ki/vJlbRqsjBlJBGoINiD3GbevtjqcOf21lvt039hJ+8T2U/0gmG/pPi/vFT+IfpBMf+fL9V8v8AEmt8oWK+bU8NTK00RBTLLqzAC2t9riY6aDiFKkMGjUsxHpnBZlVW+gDb1SbiR+zNMM9S6hrUKpFxexCaGba0w+Tct10icP4rXoZvQ1Xp5rZsptmte1/C59sJ+KVmqiu1VzVFrPmJYWFhY915CaajtRwWr6d2Si2SykFVsv0FJho7lqyfqCe1eN+9Vv4zCParG/eqv8Zlfw/CNVqJTUasbeA3LHuAuZqeKcOp1KTLQNMtR9ZAjZmemB65Yfazet4GExlLLyasn6z547iTUFY16npAuQOWOYKd1B6amP8A9K8b96q/xmVuExJptmXKTY/SVWGvc0vu0eNYLTQLTAejTZrIgN2FyQQLjyhqWbO5WWT9Qv6V4771V/jMi4zjeJqjLUr1XU/VZ3K/w3t7pL7NUgz1cwB/qKp1F7EAWMp6e636j8Yah+3Nn4ewuLqUmzU3ZG6qxU+7cS1HbHHgWGJqe0fpNDjKGIXE5KdBTQzKARRUgqct/WtfrrMhxtFXEVVUAKHYADYC/KFxnZYeS26/iee2OP8AvVT2j9JV47iVasb1qr1DyzuzW8ATpNFUoUGo4em49G70sy1htfO4yuOYOUa8iZW9p8KKdREsAVo0g2W1iwWxa43uecPWQp5N3SjMKGYRgtKwr7r1jo6HlIdNrGTiLi/PnIvCpT2F3285c06CuulgOZ6+PWZ9WtvqJdcKxViBbT4taFVjxUjB8MJYktYD23J0A75fUsAjercgb6X1sOXedvGMYVlN1uA2dWJ7wCecmqyMuUHQBSxvuC30AeWmukiy1tMsYdxXDE0vYn6W5J2GmvXT2Wlzw/haU1QlgDrl02vrbuldTe12NgqKMmt9hbW+5Nxp3RNTjqinl+uQDYi9rgaE38fCGhcvw/x/HIyFGJLWIU3HwRodZScIUUkqYhtkQttuQDYe2Mioa7hABve9tFHP47412zxYp00wyfW1bwHXxMXd1E3ibrHM5YljuxLHxJv+cVG1izOuRz0d4Im0EYQrwCAwpkWijFGqdBc+/WNwQPQyYQMAissBomC8XaJIgBXhQyIkxgsOep9pibwQQGgJgzQjCgQ7wiYDAIjGJYYUyBJuDiyOHqtLmPOJpOVNwZPWncSK9IjbzkSrOpjWBkmhjmupJ25cjvv7ZDSleP0qY2vC05FrW4yzA31Onu2iaOZyFUeJicNw5n2BA8NfKarg3C8gvaZ5ZKkkP4DCrRpljpzJ5kzm3FsWatZ35E2HgNJtu2ePyU8in1m09u/uvOfqs18OP2zzy+mi7HcOoVmqpWIByKaYLqhZs/rBS3O0m8R7L01o1K1OoyGmdabgEnY2RltfQ7kcjMlbS0fTEuFKh2ysLFbmxHgelppccvbcqZYauPgp+sERfugmmqXAcT4e9B2RxZlNiL3sbDT3yHbuj+MxbVGLuczMbknckm5JjvCaKvURWNgzKDy0LAGc8tmO72uyXLU6QWEAEn8XpqKjin9AO2Xwube6Qo5lubK46uhjSGIkR6mt4WnJs0YRk3GYNktnUqSLgG17Hu5eciWil3zBcdcERJEcKxJWXtOiYIdoLQImFFQoyFDtBBEYxJeCOsiSRhjYwvRxfobAnlKjGYzNopsOvXw6R/EOXGUaL+MriljaRIdqTh8Uyi2h8Y8MfU3DAeCr+YkZFh2voI9QbroPYziyVv6p7CoouOjgdO/umuxFUIp9s47hsI6FaiNYqQQRuCNfZ/ObrF9oA+G9IbB19Vl/vHT2HQzK47vC5lwyXabHGrW7l08+ZlOIpjzO53iROvHHUZXmjvCZgOcES6X3jIPSL1ghejHSCHIRBFK1ucTAsxUXeGRABFWESp/SLSThq5Rgy6EG48YyViRFTnCTiMQzkliWJ3JNzGIAIrKYpwdtyuyLQisdVYsrHsaRssBWPZYlhHKm4mSIiSMsT6OPZXGmYYEeFGPphD0iuchzDK9Ido5S3EkGhHEoRe0Hx1Oo07iQcTQs9u6W2GFrSFjDdyRy0kTLldwRClhLzs5wrP6513sO7mZUFSeVprezdYKFHgJWWXCJjyXiuH5B6qnLMrj3s7Kp0NiR3ja/tnROO4pRSL8gD7ZzQtmJY7k3j8M3yMuCbQhFNEXnSzLWAxIh2iArQ4nMIcDQgsUFi4aL/vOe1cgwkWKcNUjgXSRa0mJorCyx3LCCQ2fqm8K4earhVBJOwl92p7Mrhkpevmd1zMv2drayT2EZFqXNs2gUHe5I1HgAfbIvFadSu7WDPbuLaCcOXly+XW9SOvHxT02yrLCvH69IqbGDJO2WVz+vJNfLZct729Ynrfl3SNaS8nWMskcqcolYR0VHzLditlPIXOpPltIWTWOBeUUqQ6Pvg5hKYvrNlxanh6dCmKRDVGW7sDe1/q93SY2mpElq5I1M5/Lhcspd9NvHZjNG/Q3MdxOEKWDaEi9uYv16QqVYqwI3GoiMRULG5NydzKntv+HZjrY0rAKevKNIJHcxaPNdac9p15f9nvXVbbhiD+UzgeWvZvGimzg7Zcw8Rp+Edm4hK7U4rakPFvyEzhMfxuJLuzndiT4d0iMZvhj64ssrugxhgRF5Pw+QISdWOgHS+7fp4y7RJtEtEj1jbl+MVVfMbDQfGkdw5AIit4OTnQfNz9mCaT9sYb7sf8z+UEz9mnpGTKdIFWPKmscRJhclzEkJpAEkkU9JKwWFzHw1J6CZ3PXLbHDaCaBAvb43iQsveMYpCq06f0FF7nQux3Y/l3SpVIplbN1WWEl0RRrlDcG3eJpeBdqmw6OqqpZwPWOpG+3XeZtkifRmTlhjlORLZwVja2diTzN4hBFqmkfakAq9Tr5DQe039nfLlkmh67uzvoh6PNzzEHwygj85Vta8sgxyFORIPmL/AKyvq09Y8Mi8k/CWi6aQIkk0acrLJOOOxIkJzYyUixeKytbKuWwsepPMmZe3Lf04NYGgjsA7hF5sQTYdwGpMh4nQmxuOR2jliNo26yse9s8utIBfWBGjpS3KIdJvtzXGnENoF3iBpHl0ErDtNhljEExVSNFpttjYVAXvoNuZjV7x6lTJ0EWxP4lcNwZqllVguVWbUE3sL2FuZl5Q7MFgjistioYnK3qjne34yp4IpSuoIOUkBrX+iTY3tsLGaKnTTVDm+kUBu9sgGZVa263BiyylmovHG905/RQfvf8AtMElfOqX2H/hb9YJnprtjBHae8OCc96axIj+H+i/gPxggmOXTfHtEfeEsEEr6GXYc4VSCCVEUlZMq/V/5Eggk3teJBkapDglY9py6JXaSaMEEeQwOCEd4IJj9tjLRLQQTWMaj1Iy8EE2jHLs3HIIJePbLI3UkStBBNWNKp7Sw4Z9KHBC9Hh2vsH/AGip/h/mssW2P/L+sEEjFrl2jwQQQD//2Q==",
            },
            {
                id: 14,
                title: "The Adam Project",
                genre_ids: [28, 12, 35, 878],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhYYGRgYHBoeHBwaHRwcHh4cHBwaGhwaHBoeIS4lHB4rHxoaJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHzQrJCs0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0ND00NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAREAuAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAACBQEGB//EADsQAAIBAgUCBAQFAgYCAgMAAAECEQAhAwQSMUEFUSJhcZETMoGhBkKxwfAUYhUjUtHh8XKSs8IWNHT/xAAYAQADAQEAAAAAAAAAAAAAAAAAAQIDBP/EACURAAICAgICAQUBAQAAAAAAAAABAhESIQMxQWFRBCIyQqEUE//aAAwDAQACEQMRAD8A+TG1VIiiFeaqV/6rpMSq0VRVzkMQfkbkbcgSR7U8nSW/1DYH5XFiobt5ihNAxAmqlaaXKORIRiJI25Ez7QfaqYeCzHSqkm9h5b1QhfTVglP5bpzuTPhggXB59BvcW86vjZEqBHinsDvIWL73tRoGzPC0RMM0XEwSphhB86ewensZnwkRYgz4jAsNr0ybKZNO9MmJioMgw/MBuflbYWJ29fY0njFlMMCD50WQ4sPoAkg0EiaeyWVdokEAiZIMQRIP1plumNPFvI9p7cfvTEYrIe1AZK1XwiJ7AxMb8j3F6GmULzFrxsd4JoGmZjRQSK2P8KkCDcxw15uLabSJO/FDx+mum9x3G03t9qXZd0ZWmoUrRXJOYhDBMC28TP6H2pjA6dqBm1wPQmIJtedQooMjDdKCwrUxsi4/IbkgeqzNt/yt7Gs5h6VLKiwRqV0ipUGhophMwJiQOeBbaT+lLxEVo5fMMuG6Izy9nUAFSghgZ3kMO1hzvSqJeIB9bfemm92S0tF36hikglySDqBtIJEG/pRFzuIFA1SAIFlsIAtbsKWRKZRKtJENnRn3HIFybKouZnYdyT60LDxXVi6sQxm4sb7+lGbDqhWnQrC/1uJbxxBBsALrEEwLxA37CoueeANUgREgGIIIIkbyAZoRqgooQTEcsZMbAWAAgCAABtTR6jif64mJgATB1A7b6iT60lVgKAGP6/EgguSDvIBncH3k+tCfFZzLsWPc+pP7muBasiTQFjmFnnACyIAAFhaLAi2/nTY6o42YX4gf7Vlaauik0EtGmuMWW8XjgcCAZjeLUJS62U2kmLESRpJ9rUNARYVrZfK61EWNMRmJjupseANhsNuOIouYzJKwxtuBxN9vc1pjozswuBWX1jD0uQBAG3n50lQdii9RZBCtESbRPv8AU0I9ReZBANrhVmREGY/tX2FZ2YBn9/8Aehh9qGy1E0X6nijZzMzMCZvfbzPrWc6jeK6eJqjGbUikgRF6lXGEefvapUlWPIlE+DTfwIJ5/m9TFDkEzcAXN9hAHparozuxVsHtUwFiQTe0DvMzHpFKjqDCJ0km9UzDsz63ImCbHtxbk/vUuXwXGPyaumhslD6ZjKw0kgGbDmtD4VWnaM5adCLJVfhU8yChFJNqBWLhK6Fp9crbzq+HkCeRQFiIw5q+GlaeNktIkEH0pUYZoCzgwQat8OKIiGnUQWtQTYtk8OZgGaMrspjavQ9FyqwYAnvSma6Q7M2m5ubUr2VR3IZliBG+3rXepYKqjaxJO3ke4rKWUMMYpg9SXQEIsOe0+s0UI8++UUzP605kukYJPjBYniT62p9elo6lkcmOI59aXwMJVLMSYHvR2O2ZvWekqjSqxJsOB9Zk81hvh7iLDuTf716frmZlEdCBAiGvPFu89qwFyb4jeAFgBJtt7fWk0XF62KJ6A+Zv/wB1K1cjkCDJKgX8TbA9jUpYjzNS0edK5rOLhq48BZl2YExJ3Ec2j601pEAg358u1+aR6zlzCeECQCHMjnYHbuYqpdEQX3GVk8Y3QoCjGSIGoBQT4SbgWv3igRLAExNpII359KZ6fjKmsmNQB0nuTbn9qpj5Yk2uAAWb/wAiPMzc8VglWzpbb0BbAIk3IVoJgwO1+Jg79q9VkNDYagE6+RvHqBsJrz5YKSjlzeH8RvpspibkXgGtHpGYGA5Cqznw+ELuLNvqgGCJNXF7M5q0bmB04kgkWp3MdPA+UAVv5B0xkLqLAwe0wCYPIvE81XOqh2FXkYYnk8bCM1zDEWFbLdMdjKqa5hZAmxA+tO0IBlskXHnRsTo7IJK1v9MwVWFAva9MdWy5AiZNRlsdaPGNlo4qYeESdq1zlTvFP5LpxI1AAetXkSidMUIl4k7+lNrlFcgg6T3o6YSqIIk0DFdVIIrOy0J9e6Oh+VhtzY14bGwYd8MsNSRIndT29K+kZrqOEELuLKLkIzx6qt486+OZ3Ms2OX1ghjqBUHTyYAa4AJIg0KTouMU2bQx/hmLQpmx3tb3tQP8AEC7DYfTmgrgMw1YsJqEqCQCRsSewmnl6aQVZog6jYiD9R6gVomJr5MrPanYR9rCu5XMPgyNlaxgn3pzMZQ6dasCB+XkUo+NAKOBqm89v0oF4oHi5gxo/Kdt4HtG9dpcYRnSWMbD05v3ipRY6RqYeLxVOpZgMmhtMf3Ayv9y9/QUnmnKwQb9u4/ah4ykBC8NrBhR8wt4S0eZn6GolJLRUONvYsmJo1BWBmIIEi17f6b1ZMVSwLamm7AGJM7f+P6VXA0qZIDRuGt/6jv8ApV0cGV/KYI2sfb6fWpNlXk1M3hZcJKsA7qSVKt/l6ZIUNyzfWxF6F07KKdP+eF1nSwUMXAHEDcG3rHlSSMGAEXWbk2YRwOGtVlYKVZSVIvEdiI8U3P0ERRGNeyJSvR9Q6Sq4GGESSBuW3JJm4/biK0cJg5gIL9hzWJ0brODjqIVwwkGRItzq2rdyjQfAN6ujBuuwWYLoYgj6UriZgndYPNe8QoyLrCkjvWRnOnoxJAvST9CaryZPT8QzYRW0pDCIBPnSaZQKbU1lzBoaEmWXKADYVxcvfypxmoWHM7Uq0VoTx8CTFJHJgmtrEncQaHiZcxMRNIdHn+qYDrhP8PCVwRDhm0gobNeDxf6V8kxsNC5EjSDAgmInkm+1ev8AxDmj8Qq6/DDgEvhuXEgGLKQGBOkmbjUK8XiIW1MYHlfcnjc1WOi4sumOgO5ddQOlvCHiYk8Adv7vrWlh9RZgSZueBYCJ0qDeB94rMwQFkyVGoEMUkmDcCTpBgm19qocdg5AYNqNjMD32iknQ2rHUBd/CSJ/Tb3O0VzEwj3B7/rfvVcFtNiwDdlPPpV8BRMtPPofryAf0q0TQHEUn8wI4nj/muU3ncFSFggzuYjSZ2J9L1KdhQDNQAJIby/UHzrLZiTAm1hef4KYzeK8+JdI7cj696VZiZ7elYt2bRVIKmIZFhY+V/XvRETSwkao2HB9Z4quEsCTPFHVNRt9KcU2xNpIoUInvIjnbaD7XpvKZ5lgEBpN9QB5kmSDFW+ApgIGIIEzFwL6rTzxQkw7gwQpP88q2hGzOTPWdLw8NPChUs15UzY+U+EfrXq+ms0gCbmvLfh7LIcTRgjVqEs2IBCAbkQQWM8WH7+4TDCkKPetZQo5pS2aJzH5Tv3pnDSQTuYMVh9WzQRCBdiJB7X/Wn+m9TV8Ij85BsOBwZ5pf8nV0S+RJ7LdM6kj2ddB23lbeZ24961TkwTxFeawsq4ZiQCG3BH1t2Nb+Sx/8oJdWVQAxAadIsfYUubjUdxFxcqlqQ9h5UCocuKBls44HiUE9wCJo75kaTYi2+8Vg4yTNlyREsUAK7LfRMjm1J4nUg2AXRtrG6qVMcFxpJ7AxNZXVM4QGVGA1bnzid968+M26oV1HSSSV4NwTweQL+Qrpj9M2rM1zmH1TNO5LumHBedUBSGG4aLAkRMCLCKwcPKk6WRL6isgyJiQCCfDHfa9amcwxHBn7eRtVDqVGLPBgOgS8szTc8Ebmjk4sejWE7MMjVHxGKoAAImTFiV4P19KtkckzBT8EsjahIMajtqubaTfzq5ABBJQhrEyZBPiDG24LEcjfeuZNsLTDHGBLRKfKeyG/PkOa5a2dHgOmXQeELpInWSQdiQL1dMEQAADwBP8AIpjB6WiAEt4jMKSbmYEDmkc7iHDxFgkFTe3JgmxsRVLSIe2a2JlRp8cKANJAktIsZHG29cp/BAxcLWqxNxPij1HI96lBLs8rncu3hB+WJseZJJI5O/vSoxUESJI3jY9pvVuqoxcWgGNK6pF+0iw8q0Mn0DEKF1TWLxyflaPKJj61l5N/ABsXWg8KjSSZm8RGkj15865gzqAG5AuOCYprA6doQO/w1DagFZiXDRykcEAeWqk8uTrlCJBEWub8Dv5VrHRm9lkzDpIBj6A+fO1M5bPOAUtpmSIG89z8t6maRlIbFnW2kqYBGiLGPWLGnzmUKfDQSGANpMAKJG4vqB+hHat4SIkq00bn4e66vyMFQQL/ALDk9/ITXp8POBl1AFlHIBuPLvXzjI9OxHAKANuZm4gxDDivYZYvhYIBQtBlyhg8XubkRwa6ezlnFeAfVOoIXkBSrQREny5NjXpPwznMIHxQv0ufKvnWNmV+Ixkss7kENtYmeZ/StrpOf+GwbSGYbTe58vv7V0SipcWJhKFSUj69i4SEAxEj0rGx+rYeHihDyN+x4B7Upk+tsyNqhmW7adlB/LN5aL+VeO6hnNeM7WMkwRyOD7VwcH09ycZdGvJNdxR7/IdcR2KsI7fob1r5nFXTt+n7180yOZOoXiL+162RnQ8LrZW2YwIE2FzseKrl+lSknFkQ5pJOLVivV81h6oXY9pA+s1g5t/Fp0yJ3U2PoanU3KuyltZG58/rSmZzIdvFOm06YBsPYf812KopUTGFi2ZVnOlU8WqLCDMfLG3FYxcKW1IGkEeKfCdtVjuPatjMsoAbTpn5Qp4EqSZJM/byrCxgCbVzc0lJUdfFFxL9Mw8HXGKCQSI0tpgg8mOxoWZVtTYaurg4kgLs2qGkGAQLxJ/00MJDDmSP567ULGwocr4pgbe36VxS7OqJ6nK5XCw0TG0EswI0zJDAkkkz4gJgegrE6/hQ7AaoMFZG9riZPJPJ7UsuadBoAO0QxBG8kgbXt39a4mMSIe0avc9uxqQ32F6bn9A0W0tufzeRVjZPPvepSLkEEQD7b8XqUrA1cuUvrTXpkKdUQbBSLGYEW/uNXxsPGdi2E7yZOjUyqN4VSWGoAcn3pTBI0oARc7KCYFzLR9LUXMZhkMqhI2lm0x5QRESN/KoSV2W5OqLdK6Q+IznGVpEbgz3m1ueTBv2NZL43wsYshEoxi1rWFua1P/wAgfSyBQSyn5SWvfm8wL2FY+VVXc6mCAg3iQDbjub1dkq9tjyY7Y7Eu4k2HrBIgTYD9+9C+HoAN2sRY/K1xB70TKYeAQ4xGYODYrfUJPy2gHaLwfLet/p2RyzMqriux0wyFDqdjPGk3vuDwL1rGSJlrZj5ScRgRrU2DMll2jxCReNzNfQUzafA0YeKMJ0UDWx1KewFtQ2PiEjeawn6UmWDB5diZRWYwFmASAYJAt/3Q8640SRExDCUAMXCvcX2jY+taxetmE/ulroT6ngOMbSzo7kTqSNLb27Fv+KZybDTNwzWFgL2k6yRH8vSmWQlC7jVBBC+AMdYIDkwSRqP2p3oYwNDtjOQZ0qgBLTYk2IgHa81tHkaIlHQ82aZFbD0wDYkkDzhIJBWeb7UsmLF7VnYuZl7uzATEySOwJImqjGq1yUZuBvYGahpt/wB70/hZ1VbVbSJKhxIZojxRePevMDMVxs1RLksS49hMzjHUTM3pZsQ71XGxgdv550q2LbeolM2jAfz+ZDeLxybljsTbYDa81kYrx51fHzJIG1hH8+/vSmJiTxWE5G8UGGMV0ld1IYeooZzB1qTsJgDzv+tCc1Sdq52aodKA3H8/4oLETXWc7EUFjUgzj35vUqxUGpQIZTNlSilfDpHyi4JABvO1pPpT2LDAgFVOoARcgWNyRBO281kYOYfUWWSWmYEkKIEEeopo4haQpUEsDAhrxpjUxnbipWhtW9BX6RGIGV2ZRdiJDBiD4QdiYvbYetYhEOeIvvB2B962MTNEppVfFYfO8mDYlJgfSsIuQx2JBP8AL02xqzQy2aUQrojEn5idJHo62O+/E16PonWgHCqqxp0kgs7AXIAc/W3F68YhBI1SFnjgcx516HLYC4aa0JZXFgwHh8mINz5VUW2yJpUaHUM5441M0WloJjtPImlM9nWKaQzRyAbH1E1nPiX/ANqpivIH3n9q1ciFEfyLstxHe8EWHnV/6ltJjafaRxzcfpSWG0bb+9B+JeOJpqQONjxxpJiY84n7V1sWlFe9xabgdvLtVxiJGzccjeb/AEinmTiNDEJ71xcTek/ibxP/ABXVxPv/AC1GTDFDkni/lSjsasmJVMShyGkBZq4XPrxUiuFah7LWjgFX011RRUAj9qhlHEWa6yEWNXUWq2mpAEq12iiACSdt54qUAZmWwGtDQCNzAvvEmmEwGUw7aSNrcd57edKpaL6frP8A1em1zZQR4G9Lbc9jUjth8fKMACDIkXFjJnZhcistMIF3X/ygm/Ij1p9M4Nio+loneO01n4LgYhPEtQNHXybqJI4kRf8Am1OZLEYpEiO20e259aMcS02v/L0BMTe3M1UVsTeg2ZwisTF+xB/SuKkig07lzatF7JbTetFANKmD4u3EUmAZMVo6AfKlHIkxzQwRXDxIJOkNx4hYHf8AaiHF/sA+nddPbvf1qYOobWuT9SIP2qzll57fYkj7k0hAsR7zpjjtcb0MGr4uIzbmbk++9VCUWBZXosCO9vY/v/zQ0o+DA3FAaFiKOcvadaHwhoBM3MaLj5xvG3nRcwwMwqiQNptESRJ559aTJI4qW2Vpey6rRUSaW+MbeBrjUNjbjauYmc0i6GYpOSCn0OiBM2ApPM9RC2S55MWHl60sJxJJhUEnynsaWwcIyGtpBmSbW4772rNyfgtRXbC5vM6hBBJtBttft3tXaTxTJJtcnbbfjyqVNlUOLtci228VdmHAtyIqga2wrs9rVZmWVeRb7R6AUDCnX70VQSaphiXP1oGuhtjauJXK6gvVkh8OnMMUvgrFNpWqM5MKuGRcGLQfQ70muVYtCgknjk+laSGmMtl7zefLehr4BS+ejOwsuRvag4ySa3Hyh22pZspehIly3oy/6UAAswXUYXVPiPYQPuYHnVGwYtW5iZclCImDqNg0AfMb8RM0l8VXZwFIKGDJmd4Owg+VT5ov9bRm6aufSnXwBFh9aXOFTFYJ7iqaPrTC4RFWEBWGkEkghryImQOL/tUyCLQJEmw3NCbJ6mBZiY2AtFMiYA4E8d4/2FFRDSxvseVdCD5QtCCFSb+f8NXzvTVhT8TaxkCBczEbnmn1wzXXy8iJ387D6UnEakYy9NVlcgkBB4Z8MiSZaRvvbzFStXGwiF0trfk7qGAn88wDc1KjAvI83V1FVU1cUAdAoWF8x+tHT3oeWSXP1o8j8B03uJ8tvvRMNK6E/npV8Na0Rm3oZwwYjijqhoWEDNaSYcitEZSZXAQmtEtoQtedhpEmWsIEjvQ8HCir9YQ/0zld10njhhO/kTRJ6FH8kD6VjF0KEkuhIad9zf0mR9DTJQk0L8M9NxCrs6kEkkk86tLA+c39L1uJlIF6UZKtD5U1J2ZGawyUIB0g2c9ktqP0ANYvSlGIcVwIlhbyv962fxMSmAwWPGQp9NzHsKV/DeV04M8uSfYx+1L9ir+w42XMWBP7CqfBAg2P85rTNpnkUm7gAzVEWKtgE8Uu+FBg0zhZuDapiOpuRQCFnw0C2mZ8oj/ferK4quIojehqwip6KuwrP6z9orvxthAEe5vMnz4+goetR9vOqY2NJsZgQLAEiSbxufWpb2aRWhxYc6YB2gEzJHrbzqUrgpO9SpK18f085hoTRhhGphuR2poY4Ed+8bUkNsUAiqZYS1u33ph8af8ATt/PrSuASpkUeQ8Gth5RueaawMt2B9qycPqLqZBrVy3X3AiFtz2q7M6NLBymr8taOBkGAFt6Ryf4gYRYA/rW/g/iYWmPIDv6k08mQ4lG6e67obfz60PMoVw31CBoafanMt+JAGIPy7gA3APFA6z+IcN8F00MGYQCWEbg9vKlbDFGt+D+qhcsiOodbxa47wfWa9BjZHCddSNHlvc8V8/yP4nw8PDVQBI7ib3mPqaq34tYEMkDSfLk7X4rnnxyu4ujohJPUlZrfiTojMFWAQrrMczb1FZuQyTYasjD5HYD0N/3ouW/GjkRpG/a0glhepn/AMRfE1FlEmxIEGf5apjzTX5IuXDFr7WL42kmNQBH0oOPlZPzCOb71i5nHM2bfvQjm2BMt7VuuVMxfC0az9P5BH039qJgZBtzt/BXnTmnEw1zfY+W0V1M+9wWN/rVZkuBq5nBMnYUri5UqOKz16gQxjaO/PemMLqTEce1PIMQ+WICuHTUSIUyRpPcd67gYCxJtMX7RSxzR+p7Glsdie8/ap1dl26SNxVwkX5wSe1drzofSJI3m/n5VKLHQr8QC9qq+YPFvtS5B4k1ZJ23+tTYUiyEHc0RMQcCaGUroEC9hxFMGkMzOwFGTDAiTY3+va9Jrji0bg222q5zZuYUyTx/BzNVaJxZpI4ExHt5VzMZhQIjgH/n0pD47EAQL2PBvFL4rx277zQ5CURsZ9hfv2oWLnS1tz3mkmeauqCxMj9/Sptl4pBhj+9dGKbzsfOgMsXv6H9KIIAEj9bccHekOh3AxyRAHe/pedrUZczcSReYiTIFp3rNbEMGIAjuT/DVRmPDEbc/tUtJjTaNI46n96vj5hSPTbb7xWL8Q0RcWoxNLNB8QECN/wCW/goIUkxf+b0uHouDqmRxvxVoljKZcn8s99reXrTaoE5Mi4Ej+GlXzbCL2g88QBtNqA+ZJiLwZud/oaZD2OJjjXBIIkCbxfmPepmCqsVBDDggmDFrVl6yCfKqLiEQadsElVDrmL7Hz/8Ar51KZ6x1rFzJQuEGhQihFCiByQNzXKiNtXJFt1qLMxcSDY1dWBsBc/rQSsRPN9uJ3+1UYi/aruiaNZui5mJ+C8d7e29ZmNhOsEqRq2nmCRI+sinh/wDpn/8AoH/xmncycEYOW+IuIx0NGhlURrbcFTR2Loz8v0vFf5cNjAVvRW+UyeDx3quayb4Rh1ZTEgGDXpMw2F8PE1K5T4OTgBl1fKYlisH2rzOKELgYauFtZyCZ5uAB9qb0K7G8v0PMvhnGTBxGw1mXAJUAfNfyruQ/D2ZxwWwcB3VbEqCYO4B8+a+u9OwUwRlcu2NhIBhlcTDZ4dmxxJ8Mf3LFefORxMHIZnDTVrTMoDpmbBgdr06JyZ8+6j0DMZcj42E6avl1AifQ1fN9FzOEi4j4OIiNEOwOk6hIg+e9fQ06c+Pk8lhvq1vj4g8UzBIvfymtXquGmYTN4a42E8hXw0RpZfg8aYt4QQYp4izZ8ixulZhMNcV8Jxht8jsvhPPhO3Bq/wDheY+H/UfDf4cwX0+AcR2ma+pphjFyuFlDBOJltaD+/Dd2AHquoUt191TI5nLKRpyy5ZD5uWcuf/aR9KWI8j5XlMliYjRhqzGCTAmADv5C496LjdKxwyqcJgzmFEfMeQvc070AoVzAdiq/CMkDVHjT8sifenOjZnDGJgYKM7j4xcsyhIldOlV1NwJmRxSSRTbMPM9JxkBZsNlUbmLCdpI2omF0bMMAy4LkMLW3B2IBuaeyC4Iw8c4TOz/CMh1VRp1LqI0sxJHhgGNze1A/Eh/z2tcrhxbj4aRH84pYrsdvozApBhlNjBtBBG4vsa0cHK4rkouGzEAMRyFaCGM9wRfzpnr+UY4+M8SvxWWSfzABiPYitHHVP8/XqK/ByshSFM/5XLAj7VSQmzBxen4wZUOEwZ/lG5MbwBXMx0rHQamw2AkAmJAJ2kiYmn+n4ifEf4Suv+Tj2YhiT8LE5VRWflQ+nF0WXQS+101LbbvHtRSC2MjomZIn4L39IntvWeuKUJEQbg7ehFOhh/RmwEY6T5n4b3rMLDtxSfRS7DDEj67/AM4qUFvb+b1Km2FIsikztxcn96q5M7i31rmqfp+lVYX9aBhVxHK6RJWdUAW1REwOYmpiFyFBDQtlBBteYH1M1zBzLLIU2PkDwV/QkfWif1+Jtq4jYbRF/pQAfC6hjpJV3Wyqd40rZQZGwn71THzeK8OxY6bBiLDmJA70HEzrMCCZ1CDYTvO/rQ/jtGnjtxSsKHMbO47v8Vmdm/13O1p1RxA9q0MH8SZ5SzLjYwLnUxE+I7aiYvWRgZ11EBjEMIJMCd4He596aPXMS1lttY/707E16GsXrued1dsXGLrIVvFKzvFrb/ekMvnMfCfUjOjmYIkN4pB97iijreKCTa/kdwALX7Cqt1ZyDIUkgC4vYk7z3NFhXoIvVM0GRg+IGw7IQDKg3hbWF5+tBfPZhg6F3PxCGdb+IgkhmHN2JnzomF1nEUQNMeh7Ad/IVUdaxNQaFkReDxp8/wC0UrCvQqi4iggBgGENY3G8G21vtXcIYiQ6h1K3DAER5zTOL1nEYydN44P+/mamJ1d2iQlvI+W9/IUx7FsLWs6QwBEGAbqeD5WHtTuD1LMoAqviAKPCINgO1thVf8axCumFiANjsPrVcbqmI0DUF0zBSQYMSJnawoEXy2czGHqCtiLqMmAbnuZG9Vw89mEZ3DOGf5mgyebkiup1jEXbSdtwTsAO/l96pjdWdgwOnxCDAO0R37U7CiYvUsZirl2lT4W2j0MUTHzeZxF0scRlO40mDG0wL70gcw2nTbT6U6/WcZo8QGlSohRtAEewFKwoUZnCaTqCFpgggFgCJ9YkUEU3mc8+IoVohSSIEXMTS1qBkAqURDBkcXv5frUpAq+f4CP8/wCa4D6VSrCgC4e0QLDf964FkTUZ53qpamBIqEVyalIDoqV0vVZoA92v4RyhYqudWFZgdWlYlAEWWMFjiG8W0wd7CuY/CmWVNS5hnYYYZkVsIFW0qXJZyohSwkbwVM3t4YVIoA9dm/w9lkx0wxmdaucwpYaRpOGWCapjeLnY8TWHncmi4wVGLIUw3BMTL4S4hUxaQzFfpWbXRSKTSas1MnkVZAxJkkyAeJEcev2rn9Lh6ZMgweeQQANvOs8N51U1GLvs6f8ARBRSUFdVZqf4essL218i8RHHnWZXNZ7muE1UU12zLlnCVYqiGq1KlUYkqwrhqRQB2uVKhoAspqVyalFhRwVKlSgCCuVKlAEqCpUoA61cqVKAJXalSgDldqVKAOV01KlAyVypUoAlQ1KlIDoqHmpUoA4tdapUoAnNSpUoGf/Z",
            },
            {
                id: 15,
                title: "Pil",
                genre_ids: [12, 16, 35, 10751, 14],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhYZGBgaGhwdHBkaHBocGRwaHBoaGRoaGhocIS4lHB4rIRoZJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHjQrJSs0NDQ0NDQ0NDQ2NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAQUAwQMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAECBwj/xABAEAACAQIEAwUGBAQFAwUBAAABAhEAAwQSITEFQVEGImFxgRMykaGx8AdCwdEUUnLhI4KSsvEzYqIVJENz0mP/xAAZAQADAQEBAAAAAAAAAAAAAAABAgMABAX/xAAqEQACAgICAQMDAwUAAAAAAAAAAQIRAyESMUEEE1EiYYEUIzIFQnGh8P/aAAwDAQACEQMRAD8A83t2macqs0CTAJgdTGwrbWyNwR5/flXeHxDpJRisiDBiR0rq/iXeM7lo2k7T0+FdYtkGWtgV2BWwtGhbJFwrFQQjmcxEIxGVYzMDzA59OdbfBXA2U23DRIUowYqN2AImN9auHCO11q1gRhWtOzeyxK5xl7r3mbJllpKZXbN4qsA0Vju2OHfHrisl/wBn7BrTLCZwWDAFAXK/m6jy6rcr6Na+Sg+xbLnytlJgNBylhrAbYmOVTtw68N7N0aT/ANN9hz93bxq0cQ47hTgP4K0l/uFXR7ns/f8AaO7lgp5q7LI8O6I1b8L/ABCRHVrovvGHsWzqs+1Rib1z3xIbu/1ZYIAotyrSNr5PO7eFdgCqOwJyghWILb5QQNW8N6kHDb3Kzd12/wAN9fLu61eeHdrcKlizZNu8xt3UvZstsTcF5nchM2kozKO90EaSZeH9v0Rref27In8TmUZT/wBW4GsQM49xMy7iJ060G5fBtfJ56+CuKudrbqg/MUcLvGrERvpXS4S4rZTZfMynKpRw0fzKsSY+FWXj3aCzewP8Mj4ouLjPL5PZtmYwrd9mCqhMAbtqafj8SLf8QbjWXKIoWyBlz5nFsXWcsxVRCEAINcxmCZAuXwHR5v7JvZl8rZMygvByzDGM0RPhWmwN3ME9lczkSFyPmIG5CxJHjVr47x/D3MA+GtJdH+OzWwwVFRXuPcghHOfunKJGhkztViufiRhzdRvZ4gqCzEvkzIWtLaCWgrjuEguZYGdt9A2/gY8vu4S4yEhHIQlWOVoU7kOYhSNd6Ev8OvKSrWrgIUtBVh3F3fb3R12q8cP7YCxYxVtFZmv4i9cDP7otPbZO8A/eeY0OZeckgUd2g/EbDX82W3fWcLirADBD3r62gjTnJCg29QPAidanLsCSs80u4C6DBtuDmCQVYHORISCPfIIMb6097J8NurezNauKAGAJRgM8hcoJHvTIjfQ1dsV+KWGZ1b2F1YvsxdQgco2Haytwd4gXhmCxqMqDXWBzwf8AEHDKli0Dima1dvPnuC2zOHa6wL/4gDNDidN5gjmsXTTDJWio8Vwd69eyKjnvBCcrQrHZWMd0wdjrTXFYM2UyBXORdRlMgad4iNASRv1q3cK7V2bgcpbvBBiVuDORoAyO3ezkuxCe6wOUsIaAKW4rtAj4vE5Q+W/aAAIUxGQkN3zAhDtPkBoLRvuuyTS+SrYLB+zBzHvMZPh4VDPfPl+opriV1n1/QUnZof0/anloCdmrw0pbfFH4kkAUtxTwN6STGRDNZQvta3SWMMgK7ArYFdAV0JCNmgK6C11lroCnSFcjkCtgV2orcUeIjkcxWEVJlrWSjQLI4rG13ruKwitQykQkVyRUxFckUriMpHLDuDxf6Kf3qEiibg7q/wBTf7VqErSNbHTOEGsddPjpSy+hB1FMzQ2PSWkcwI8PDyFRyIN7F71Lw8d8etRk0VwZc15AeZj41Ohn0X7DWv4fD98QYJYeJ/sQPSlPCrDm8LrAAOGgHeCNPpTjHD2twWpMfm/pGp+Og9ahxuIC3EiPeAA566RXU0tfYgmaxLwD98/70gf/AKq+NNeI3omq2bjG4GEkBtSPPWp5HtDRQ3xsERyn6VWsU+ZqZ8VxU7fKl2HtzrzmAPqTUnK9DxIfYt0rKL/hD/NWVuI1h4FdqtaUVIortSISZtTH7V0F8K2iUZYwxNUSJtgy26lTDmnmD4SW2E1YML2Yc7iPOjpdiORSBhT0rDhT0r0ZOyvUitt2T00YUOUPkFs8zewRUbJV7x3Zp15T5UgxXDSOVGk+gqRXylRlaYXsORQrJQaHTIrg7qf1P/tWoWFEXxog/rPzA/SoiKlW2VT6ICKgxPu+X6/ZolhUbrIipzjaGQpK0z7MWpxFv+qfhr+lB4kERmOvTwp52JTPiknWFc/+JH61KKXJDN/SW1LeR7lx4GYwPBR/c/8AjVQ4jine8CgJykHTYQdz0q09p7oVIG/L1/5qKzg8lhUYQ2WT1ljOvl+lWkuTpElrZW+K4rOco3J+M1rGIEQINufUmjP4BVurOrCW9BqJ9aFuDPeVRqF1P+XXX1+tSlqxrOb1nKgUjXc7anf5TFRjDFFkiC2vkOlGXlzOF2E667idY+BrriJ5dNfKliu2zIVSKytwPv8A4rKI4SoqRFrlRRWGSTXZFHPJhODwuY1c+B8ALwSIWhuzXDM7AnaryrhQFQaeG1GUmlS7JN2ZhsIlsaAedTtiV2mgb5APeJHlrXK30BMwAPOY8dKi43t7Mm/Aer5tvsVyXdWgiBVbxfaELc9mhCxEseXMk+kD1piOPJlDlQyr7uY95jHvR+UfEnpXNLNUmktHZH0+k29jZmmgMXw9H3WD1FQ4Tj9q9oTlblodfSmKGavCaatHLOEovZReNcBKSQJHWqpisKQa9lvWwwgjzqocT4EPaouuR2A03EmOddEZprYsbujzzELqn9LfNqhIq7r2bUEl9SQ6oskaBiDdfog0gcz6TU+JWVS46oSVViASIJgxqBU4yjJtI6Z45QSbArtsqYIg1AwqdyTvUTCtJGiwPGdYnlTvsAn/ALn/ACN+lK7iyIpr2MJS+/8A9bR/qSoVTsZ/xG3EsO74u2vLRj5KenpHrRvFMUAzFjEff71vhzl7jvoQoCg8+9qfovxqtdpccGbKu5+n/NUuo2Ik2DqXctemF7ygcz+w/auuz+FZy79dAT8SfpTLE4cKgQaZVA8fH9/Wu8J/hiF6R8dzXPNNddhTQtMB1jTvDTpJj9a3xQQa4x4g6fHypdxDG5jPWjGVJphianxPy/asoL24rKXkOPUFN+GWMzAUqtCrT2esy09K9JHJJlrwKhFCjTlPnTK/eyIMuuupNKkaCPCpL1zMfSg1bJnL4gsdTpUeMc5GbkIJ+I/sK4ArnHqxsuBzifjp84oT1F0PiVzSKRxO8oYsTLORt0VdvXT40DieLM6ASEjmQM2u8c/U1hss93aAjQJ2kCd/vlXoHZ/spZKe0cK+YaHeeprzXtnrJN9FD4LxHLeQhiDmGZwGmOcEz9K9lwNyVUkMARILcx15a0kfg1lNQiqBzMfU1riXHWS1byNmt58pyQSWE5ROwG/ypoZFHTRLL6ZyV3ssTMTtqOVL8JiQrzcIATXvEAZtgNfE7eFCYXiWVtcwHQggg76r6iq5284kpKIg1MFus/pXTkbjHXk5fTYXPJXxt/gZ9oOKCWb7YjaeoHyrzvEGSTT3Fo2dw2627UjoSkt86S4hdaPp8XGNvtlPU5vckkukBsKjYVKwqNqpJEYshYUXwe5ludJVh6xI+YoVqY9nuHm/fRNcs5nI3VF7ztPgoPrFSl0VS5aG2Gf+Hw4djrcl46ToB8BPrSHhuAa45usDlBkT+ZvDqKtnaHAq9q2paFQACIzEkAAEnyri/hsqBV2WFHpFBx/0JdAHFNxqNxz31qFjB3+xsP71JxJY++ms71BeuREDfbxP2a58j2AA4mynRZO2m5mPr/al/wD6bHvnXoOXhNWD2YXvaSo+B208aW4l4+H/ADQjFrsomL/4VOn1rKz2h8Kym0NsbYerj2eTuk1UMMw5jyq4dnm7hr0Uckuh9hrcgnoP7Vy53G9R2bpGk1KRsRzokzRQ7Gu0SQyGSGUiNp8uh0oy3hgwnXXn0qf2GQj41OTTVDQlxkmeW3LuRndgSts5VUyAzN7xePA/Or/2K4ibmGgxNskeh7w+tUft9giLyv8AkuPLRvOkgn0pt2G4wqI6uMiMwCtByggRlLeUV584uLPXwTUnY0xnBzimus15bbIwCBxmzaScq6wuoEqDJBnwY4DCJYQKctzu6q4ADHmcp2Xbeu+J8QCgBCI60ifjKIe93mO3Opxduki0oKP1SZZcViLL2FZlVHC+8p0WJhBoARHIda8uDNicWBvL7b6DU/rTjjHGjcDLAAAB8u8P3+VJeGY0W7ucidInnBiflNegvTy4q3+DlXqIRtRXa7LPjcIc15yQcxQc57qkGZHzqr4pdacrxlStxdB/iZBrv3gJgeH0oG3YDvrsNT5CtjyfS78EXg5ZIxh5oFwnCLlz3QI6kgD570Pd4W4mMjR0dD+s1cUuABWGmgiOlVftLwuD7W37je8o/KefpSe62ro9PN/To4ktt/cWfwT8kJ8hP086unZzBth8FiMQ6lWcezSRByjvORPKQo9DUfAQluw7OJCLqdvd1aPEliP8goa72jR7Qts8qoIG+5JJifEmub3nNuNHI8cY7TB+NXy3sAP+zT4GmWJTuwOkk89T9ai4dhM1y251T2BIOnvlQIPiATRPE9p0jQCeX3NdO+LZwt7oU8STQ/fn+tA4a1s7dNNOm5/Sj+IyFg/8mgBe/wAMa8jr6x+9I0r2MiHE3tOlI8Xit9akxuK0IFLbdpnOnx6VOUr6HijPbGsoj/0//u+n71lLTG0O7Jq29mLoz5TsapyGnPC8TlYGvSRySRdr1rKxHOjcCFZSGOtCu/tEDjcAA/vUaOQZFN2iQ0wtzLAnSu8W7sN50pfZcn9qmVyGgmI5UjjswJi8Ct4ZXEg+nOQfA0JieCFVyf8AxrbCjprAJ8ySTNPfa5CGgEH1rXG7hawwX8w+Aio5oKSs6fTZZRlxXTPLuIcbe1CMpI2BneNDyoq/by2rd/OGz7x+Q6gqZ5glfiKrfEizMZmZLf5s3ePr+lWPhHDblzCXMslUYEL0nQt6ZVqOBRU7R1ZpNxpvQtVzlfxKknwkj4SV+VQE96iktFQyHcrp4wQ36GhG3r0XdUc0afRzg8KTdUz3c0wPj9aaYzHFAyhTqQM/LxHzFG2cSltLeVmLk5mEAAIc0iSsmZj+24XHsQrhcphBJCdGMSZ9Pl41xuN420tWdvpsnDMt7rX+QkdoF9mEyd5dASe7HXr6UBi+MXkXLmAzCSIG3Lek3tNYFZjr5Y6nkB8BFcqdbR6uTO5RqTDr3HHNg2YAkiSNJE5vjPxoJRAFRWLZciPsDU1O6kRIiRNNjSUmeTnVq0Wvs5iM2SSRlhAOUak/+IHxo3i/dBmRHXnHhUHBYIRiBCZCeX/xAb+oqLtPjpDHqT85qzk0mjja2dcQEgnSADP38KqGNxpAyAa6/CSTVrvtCePpr8aq+Pw+Rs5Pe1MctdI8edSnbY0ewLA4NrrHcKNz9APGmnsFRYA+/GieEOvsJEDvGfHp41ziRz9aMYpIZvYDm8BWVxJ8fhWVghaUVh7kGg1Ndo1dkWc8kXbs7xPKcre6dDVmu4EEZlMg7eFeZ4TEQaufAuPZRlfVad32iUkNmwrKAwP3yrLdvOSW00+go+6q3lGRvSagsYZx3TsPvSlsUHZiFjWDy/WicDlbMrcxHxrdvC59yQfI/OmGD4cqmd6WUopbDFO9HmHGezjrfZcpMtKmNDP7givQuznDfYWFWO8dW9eVOnsKYJAJFcuYrmikno6cuRyikyqcf7IJel7ZyPvH5Seumq159xDg920zq6aqpJOmXzB58vjXqPFeNqgIUyetUDjONZ0uDMfdk+MbfWumpOLsnjlUqEmMxjvkVgB7NQgGvIASdSJ0A06ChsesiPCpltGRGokfuSa3i11qkcaWPj9ijnc1IQLcrgD96Pt4VZzHqfKosThzMr6j9q8/2pJHb7yk6J+Gd0SefXoN/QmB6miuIPndQgkwJjWXO8fKhcBbZ2CKNTy8PuTVw4dwhLXfcgRrrv8A2qUP5W/AZtyVIXWMQbOdOQa2PjbEf7RSxxdxLMAIC7kzp+50otcWt28/8rOhHiFzKP0qwXUCo0aSNuXQR5D61enLZxzpPQtxLRlEcx9/Wqrxq/Jjxqw4nFKRM8vv4VUMRLvA1JMD9KEn8BiifAYwqpXkDP7/AKUeuIz7HTnUS8OyDqTv066VEvdcCI8ev70qTQ2n0FezPX51lR/xFapjE612K5ArsCutEWdq1G4fEkUABUqiqIk2WLA8XZNiRVhwfaX+YTVBUmp0ukU1J9iNI9Ps9oLZ30otOP2+teWriTUgxhpXiizJ10ej4ntMgHdBNV7iXaJ3kTA8Kq7Yo9aHe7NGOOMeka2+w7E4pmnnS8NOYdUcf+JP6V0mKZQQDEx8tqhR+8CeuvlzrO3aGi0jfDm1B/7f0qPFCdak4akMVP5cw+BqO4N6pDcRnqTAuR8D9R/aomomyBmKn8wgf1TK/PT1qFhXNJFrJMDi2tPnWDy16fpXXEeJvd30X+Wfr1oYrXJWouKu6KKbqrMwzhWXX8y+neqw8V4lACgEtMRzPlVXdcro55ZSBy0Y/tVwwVhc7XDHdEL/AFRJPnH1pEm3SEl8lafh16HLArJBUHx303HKuuG8Pyd9/eiQP5Rz9abcY4iAyqSAcw+vOq9f4jqZ60HxTCrY8xNplTPIgiY5xyqs3bxa4POjsVxkuI20pZZfvg8poTa/tNFPyMMgrK6/iR9ispeQ4yFg1sWabnD1GbJr2OCPJ91sXi1XYt0Z7E9K37E0eKNzBRbrYSivY1sWqPFA5g2Wsy0YlipDha3FG9wXZKzJRbWo5VoW5rcTe4CFK4NujTZrk26HEPMiwhi5/Wp/1Df5Cagx6ZWqe9ZMZl3XvD03+VQ464HUMOY+xSfxtHTB8qf4FuJUkab8vPlUtpS6ho1ImpEQFDvmB+X2R96UbbTQRtGnlUsaU5NlM0nCKBEwhNEXsOGiFAgAac45+dNcJgs4JzAQJ1O/lUXsYqvtxbo5HlktlWx475X+UAfVvqad3OJAWtD3jlI8e7Bqv8QuQ7k9T9TTPs3w8XyxeclsAx1Y7eQ0M15zf1tI9BL6FYNh+GvfGdiQs6dT5eFSXuGW0GozHqf2qzXbYUQAAq6ADw0pHxJsw8Ooj9fSl4pGUmxVgsGjlu7oInpUly0oMbAVzgMSEZgecfKf3obG42SY59KVNIbbZv2i/f8AxW6W+0PU1lbkhqPTAukRtzrkpQmAxBzurbEyPPn9+FMCwr1ozTVnjTi4ypkIjnUlu3mBIE1wVWZaSOg+lRu7EtkBVWO3h0nprtWc2BIHxVzvZQRAMSOfrz/tRmHAKyaF/hjU1o5NwaWMmnsMqrQWi1NlriTAIG+1ctfA9KraJ7NtbnlXDWwKZ8Gx2FzZcQjQdnUt3fBlXceIE/pdcL2ZwN1cyd8dVuMfQwdPKoz9TGDpplseCU1aaPM3g0M6V7Ha7J4NdrCn+os3+4mosT2Owbj/AKWU9UZlj0mPiKl+tx30/wDvyV/RZK7R5PgU723I/Q0F/wChXEDXDCpyXeevyjx7wr0DG9jmsOHRi9qe9MZ1HUxoR4iI6c6rPa3iyIjITqSYQTO/PXTXXxjlNLlyxmk4s6fS45QtSKvgMOWZug3/AG+VOMPhhlJMAAbc/CKR8JxhlhHvRA5Cj8ViXQwYEgGRtBAI+tWxOKjo5/UcnOn14DE0ouxZZ5jkMx8gQNOu9IlxRPOireNbYNy2nlO2nxp3lXgh7cvJX+N4SLhB5mfT+1WHsmgW20Ddvooj6mkfE7he55Ab9df3p92YBFskiO8T8gNPn8K4HXN0elG+CsnxV7QqP79aRYslRHPpz3pxiV3Y6b6eRNI8W+ZpOn1pZDRQus4TOSSYjlvNR3MKgBIH1plbAKyOp+QoLE3N6RpDpgXsh9xWVvMK3QCXm5i8MDIczOncf9qxMQTqoJB2MEaetV1JZsqiSx0HOTV2w1jKqggAwJHjHhXdFtnBnUVXyL8zc1iurZ51NirsBio2+FKjxF+WUelNyZOOJtDFr3hUL3aXNi36/IUVa740MNzFByZvZo1cuHauUXWtthm61LZwuok0vLyHh4R3a0O9WPsdw72+JnvBUUMzKSpJmEWRrrB9FNV9rCzqwUczOg9a9P8Aw+sIMMWQhs7nvAzooCgSOkH4mp5slQ0UwYblb8AH4icZuWWsJbuNbzC4zFTBOXIAJ6d8n0FV3hfbLE2zmZzeURKtlkjnlYLIPnI8KK/GAlbmFYCZS8Pg1o1QfatpHODU8Si4bRTLyU7TPoTh2OS/bW6hlWEidxyII5EGQfKvBvxL7PmxxDKk5L4DoCdASxDICeQbUdA4HKvTPwtxBaxcU7K4IHTMuv0+tJvxXtI+IwuaZRLjQD1e3ln/AEtUlGp8UdHufRyZRk4PkUENLHcxA05DnUeJwpmCxO1OrFprjBUBZjsFEknwAqfiPCLthgtxcrMMw1B02OoJ1rtfFaPPuT+plfNgD8p8J6fATWLh/wAwgdPGIn602QZSGEmNvs1BdYk6beQ/SsBSbK/cT/EjxX6gVbmOSVAA3221mkWJQpeBMbK238pn9KfPzPgP2+lRS2zsTuKF2PXQb8p+Umk19M2aR5bU4xoMePy+9aU4hACY+/2pZDoHt3FCleQ108uvnSrE3KIxikCdj0+NLLqHeZqUmURmesqPKehrKSw0XLCOqXUYnKBBJjzPLem9zHOWGWQpO5EactTsdqVYBJugkBgFWfPKNB46GrReuEZe4IIIjly9K6VNpIjLGnK2LcQYVvEH6UnK1xcsXfaEvIQMdJkROkAHoaYDC9TVeV7AkkBgVLbJBBH351OuGExWYm4qNlHejcjQDw8TRrVi2m6Ir3FmU5Ra1++gqQ41ggZhlM7bc/HwopHXQyNdvGeUVxj8KWHl4TQbbM4pg+Fd7jqiqWZyFVQJknw8pr2nshwlsLh1tNAOZmgGQMxnLPPnXmvZ3iz2ASqW1eMpuMhd8oAACjMoXbXeTXoPYri16+lz2xBZWWIULAZZjTfUGubNyr7FMSSNds+zLYxbeR1RreaMwJBzZZEjb3RyNec8X7NX8NLXbcoIAdAWXzOXVfUCvV+OcZGG9mSuYOxU94KRClpEiCdNiR50Hi+2GGS3nzMxOyKJeeh/KPMmPGlxzlFaVoaeOMnsg7F8N/hMIWvEKzE3HLd0IIGUNO0KATOxJrzntLjmxWIe+ARbhUtg7+zUmGI3GZi7RvBE05GPv8VxAstCWV75tgkqAv5rpEe0YMVhdFnymhe1GGw2HdbNkl2Ulr7zOTYKgC6AnvEjcADrTw1O5dsWauNLot34eW7HsnNtHDBgr3HChmMA90KzZU6CZ60u/E1ovYXqUv8AyaxH1NMvw4uI1m6UmPaRrO+RevnS/wDEhUN/DZ82lu9GUEnVrPTyoJfvGcf2qKna7xAMiTAgEknwArAltdid4gqwEjflvUGJvFGBRiPdIJEMrDbX9qEOJzEBmJkkmep3NXbkpfYjGEVFo1xd1BVhHdOvkw1+/GjLb5gpncAfD/ih8cqojFlDCD3ddemvLWNaV8Pe6ikOsAgkDXug66zMb86EnTDCNRoaYh5BG8edKLoGbbcfOirt8ajnv60M5B1HX5UjdlULHs52if8AiK4v2gO6NqnxQysp5T9/rUGIuD7+tIx0DezPSsrMw6/L+1apQnpHBvZokZGLE6MBOnIag+dG28YgMuGiI93np1FDWcaoUA8hHnoP2rd3GISI8T8oHzp3jTT+4qytNU+gLH3LTFo7oOqgzt/Lr0/WKFuYtBtJ8v3qa5eBuo0aANPqaSYi+czQOZ+tPG0qEk7bYQ2L70hYjXf+1QONZOpOv71AkkzU3szIp1ITSZLw7E5H0QMSYE7iTyphieNFZU2gP8xn6UHYt99SF91lJOsaQST0Fc8WvodipMk6FTuZ/WlcqYyQbw3iKux9pCAbQCSfPfT96vn4aXj7XFKSDpbIjwNwH6ivK8G4ALMBHpJIGwnYbaxyjnV4/CbFE4y6pPv2Wb1V0/8A2aXJuA0dSLT+JGK9mmHMElrjKI1IJtOZH+mvMOJF3J7kLJI5MfOvTfxOn2eGymD7c/D2N3+1UQ23P5mPqRS4YJq/JSTfQR2K7P4u8Li2rjYey+UXLo99lXN3LbaEe9qRHKTyMvbfsrawIsDDhsjK4bM2Y5lykNtzDNOw7oq1fh1irrNiEuOWVFs5FIAVAfayFCgATA8TFcfiiBlsT/8A1/2Cl5NTM0nEl/Ckf+3u/wD3H/YlBfiVfdb9jLln2dzcH+a3tB8KZfhfhsmFbvZpuk7yB/h2xA8KX/iLattiLOdgsWniTG7r+1FO8tgafGiprYv3h3gFXrAE+Q3ND3ODsrAAzrv08aMV0QQj/wCkiPjMUywl9sui5j/M0AekDar8o3Xkg34FnsWlVcKVkagbZSCPoKmxG+WB3ixnXqfv1ozF2y2pEBdSB5czSZMRmKE/94PmQeXnRk6MrK3xLCOGLptPunQadDS9cdBgjKdJHkat/ESqgICDodvH6HlVSxNsM+Uj+37VzyrtFV8MCx+LzbH9qGS6SNaZtw1BuCT50JfshdBSNO9jpogzeNZXNZWMX98UgUNn0O2+usaep+dZnUtkDgsBJEHTWNfGaU+yw6oWFx2jl6jXegv4tUYMubXaTA1G7DWfjVeTJcUWSGGoYekUuKg0Lw7Es5d+QEdANeX1qZDRUrA40ShRU1m/G0fAGg7l5V95tf5V39TsPnS+9xU7JCg9Nz5sdfTajyoyi2PnvajOwUbBdATJO4G2vWh+NBGAdY5Ax6fvVabEknU1NbxRK5SfKlcrHUaDc8gCdBsPPerr+E4nHGOVlyfLNbH1IqhpdECN+fT0pxwbtBew6NbslbXtCA95Vm9l2CqzHKoEsdFnXfatJ3GkZKmXX8SO0qnEpZQhhYDF+huOAAkjmqgz/XG4NVE9omOgVfmf1FY/BbSt3bqOZky+pMmSSVMmd9edd4Ps8jt/10XQnvEGNtJHP05Gli5RVBlsvX4VcQz3MSrEZitorHNVNwMfQsv+oU3/ABOwAuYX2ntEtmycwLmFYEZSk9TpA5kRzkUHAcKewyXcPibSuDoc50kaq4CkEHYjas42L+Jf2uJxWGYrORM7LbTTXKmU97lJJM6T0nJPlZk/pply/CXFhsNcQiGW5miIJVkVVPxQj0rX4pYBClu+XRWU5AGaCwJDQi/mOhkdNeVeb8O49ew9wPZYZlkdUcTqCNJU78jttUGP4nexFw3b7s78iRAVd8iLsq+A35yaEo7tAU2ohQvRoxzEeGw00FZY4xkuBACCeYmNp2pLcxJE6xNd4xC7Io3y6kbxv+vzp4k1Cy1LxJ37ubQ6baa+O9C445XR1iARm/Wk+G4fkIOZjBnemePxMpy3J+VVtrsdRoBvX+ZPU0vtMJYncmPkKgu3yPe25GswzSpI5k/pU3LY1BN28APn/alOIeda7uvrQzPSsZI4rK69rWVtBNWrxysM2kDT/MKxT9mh7bQD4gfUGiMPB3MCl5Goa4bFqiQO8T6AHaDtpvUd7iLGANB0GnPbTUiPGlquJ128KmsoGcTOTMM0b5ZEx4xNNYKDEtIzR7U8vyMNJ15nUCTTO5h7ErABgS3cczpBLDoCfkKXY+3ZR0NsuV/Nmid/y+lDYi4CNGefIAfI0b0YsVyxYVPcXUDUWyYMKB8ZJoVeHAAEIDqBsYIyk697eRSpMke9cGmuikTA/wC4aTUtt0zas+WNIjNOnKYjehYbHK4VVaAiy0RmWQBI7wk767TyFdW8FJAyJKxPc811ObXX6UqcoYKlzrrmy7c4g711intgHI7kwIkeOsnpTJClmawgAZkUZlUaIIzGdB4yd/CtezAGiL7ja5IOYaAb89dfCkNrE2iIBu6AxOSM3LntPrR9m7gsgztfD5dcsZc0cvCllKmAYnEKpUNp5JJ8pmRqInxrVwgqcyIGL7ZJ16b7HSfOqsLttffe4fBVGnqW1+FRX+Ip7qZ8kyZK5vTTTn/apuUnoyRZBhrYcAoFcwSMrZROnI9QR8aLGFKiCq7D8hPPmZ57VUBetQD/AIs9cyT4cqJwOKtgg3XuHqFbu+Gm/SipuKGjTdMs7YcGSyDwi2wBAgT4a6VzbtW5nKJgEd0mVG06wAT9artnGob479z2QkkZu8dNgeQmD6Gt43GWS6hBcCT35aSdRlA0ERrPnR5NpMdpJ6LJi8VaTJmyDPv3RAyyDEb60mxd1CGl4WZ90+76fSkeMvWy5yl8omNv1M76094Lj8KiP/EqGJIygoXIABk9BM9Tt5S3J0K9i/EOkSNQdienlS9HyqQOs/fwrm/dGoUjLJiJAiTEAgEetB3LlLfkyR3cfWomeoi9clqFhokmsqPNWVrNRNZUTqJrQrKysjG13FHXLmUCBWVlFGBfakmTrUk1usoinU1rNWVlYwTZbumoHbWsrKcARgDrrrRGNsgAkaRp8K3WUr6MKmumajuCsrKn5MaLRXSXDIrdZWMT4I6t971q+86RtNZWUwyBHOtFPeOSKysrBBxtUL1lZSgRCaysrKAxlZWVlYx//9k=",
            },
            {
                id: 16,
                title: "Hotel Transylvania: Transformania",
                genre_ids: [16, 10751, 14, 35, 12],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUUFBcUFBUXGBcXGhoYGRoXGRkZGRkXGRcaGBgXFxcaICwjGhwoHRgXJDUkKC0vMjIyGiI4PTgwPCwxMi8BCwsLDw4PHRERHDEoIiUxMTE0MTExMTExMTExMTEzMTExMTExMTExMTExMzExMTIxMTExMTExMTExMTExMTExMf/AABEIARIAuAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAEUQAAIBAwIDBQQGBwUIAwEAAAECAwAEERIhBTFBBhMiUWEycYGRFEJSobHBIzNicoLR8BUkkrLhBxZTVJOis/FjlKSE/8QAGgEAAgMBAQAAAAAAAAAAAAAAAgMAAQQFBv/EAC0RAAICAQMCBQMEAwEAAAAAAAABAhEDEiExBEETIlGRoTJhcSOBsfAUweEF/9oADAMBAAIRAxEAPwDxqsrK2BUIarYWpY4s0ZHbVaRVgaQk1PHaZo+OAUwt7TYs3hUHBONy2PYVSRqb06czgb0cYNkFcHDi2yqSfIDJ+6tvw5h9U/EYHzNWSa0nJSNECIdsSyLGdmPjeNjrO2+QD5AEAZ54rZLFpE0rZbkyIGQjY5Qu6sy789NG8ZdMqf0apUstWccxvj0pw/CZMnQpkXo0fjU/Ecj6HBHUCu/ophOZFOorlUII2YbF/IYPLn54qljZVCI2eFyRz2A/E/Dl/wCq5W1ppNlzk8/65eQruK1LZwNhzJIAHlqY7D41XhsgqFrXYtKaPCUOGUg89+o5ZHmNjvWKmavQQW/Q66FnTSOIscKM4qYWx6lV/eIyPeo8X3VFAoSPaUO9rVj+hlvZKNnyYA58sNg/dQzWjHVhGOn2vCfD+95fGo4FiP6GSCV3I3I648x5jz/rArJTwxYORsRuCOYPpXd1B3kYkPtK2hj9oEFlZvNtmGfJR8Q0EK4RWURPHih6AhlZWVlQsyp4Eyagom1O9WimMoLenK2SRnEgEknLuhnCnIz3jgjcDPhXODzIwVIEB5Dqdqf3ZxLOVI1/rMAbjWFeRcnkV1Ny+z58tOPHZcVZGLWVBiKMx55nvE7w+jSZUgfsqAPPJrhuIXEfgZyCORJDsv7j76P4SKLg7NxGOCaRtQlk7vu9GnJ0sW8avkAFT03286g4nwl0uJ0s4maGAgMCda50gsSWOc6idgc7CjkqelDPDaVvYXe0dzz5k7+8nzoyTEqYf2kHM/XjyqgOejjbD/A7YqS24XfOiyJaxlHAZThfEpGQQDJncelTQWd6jb2qbZBARTncqy51+8GpGS4/2RQaEX9mOSoxq30hgB1AGGP1SMjmdt+gplGjxjSLmEqPOQFAQeisuzZ64yKYI11AssndxKqYyxCBly2jS8erJfJAxyyo5ij7GSxeOEPbr3krMg0l0TIYjfQfD9U4GB4vSibVf1lqDbr/AIIXuQ/gjlaaTckSLmNwOYj7zfUMZ1bZ6UFdRyuoHdhVBJVFAUZwATkczgDckmrW0NtI7x92IGikOju+6cuFUMzMCoYjxJtnbGM5zSM9nQ87RCYqO7EkTaCwkTr9ZdLb5x19KFvbkt45J7r2FltDcqMKpC5zjO2epwCd6LS2kOdUDjOxKYHXmATge7Hy6aXgqFIpO/YrIxRsIQ0bjUMEF/ECwAyOjA+lFWvZ6OQFfpRErDXEpUhe71EGSQ5OM42Ub7g+lJc0t2yLG32ZA/D5cYWM458xkn1zj1+ZrgcPm/4Z+Y/nRPD+AJIsgaZlkSRo1GcI7hS64zvggN/hNRXPBEjSN+9Z9UndsFGNLK+hwGJPLfBxvtRqe9bWTwJc0cC2mH1GHuwPwqdEnypCu2k7Z3wOoU/VyNsipeJcAiRZXjmk0waVdXUO3eFA/hZSo07kcs5U+Yro9nVjdlkuQUERlDKjMCoJyANYIOChG++vfGKNSrcrwmtqZJPw3XhpFkViACQAwbGBkgtqDcs+1vvnB2iuIVUGIMsaspzq1sxbAZGLKnIMq7YxpJPM08sez8YkktJJ2dRGkrAIQU1hsMj6z4gAuVxuHHPFJZ7REjWSOTvY2JZGdTsinSF0nOMFTtRxqXCKca5RWb/h7L7WkgjIZSGBBJAO2/MEbgbgjmCKTSx4q6wqj5STZSJHDppIjDIQ+pNQ8GUU+hX1zVV4nCY5HjYYKsVPvBxWXLDSxbXcXGsrZrKSQzFTW4OoAAknYAcyemKzRTXs5eCC4VzgbMocjV3bMNKyaeuknOOeM43watckqx3wS0mgLTSxvHpQiMOpUs7DwnDEeFRlyxIAKrvuK7swrtK4k1HupdW5YgmMjOrHi5nf0pZxu+kkcrONJOCrJjQ68g3gOl122ZfLr0K4BAQZiCMLCQ3TeQqApDAcySPhitKyJLShmNeZIttig7rh5aSNUWUv423fLkaFABJbcjBxjNL7m8eB4pRne8ui37WW7og+5HcfGi4bB5bK1AQhoroZyCPAwY5HmM4FH9pOFd67woQphuhKwYqo7mcK7S5O5CnI5/a8qzZMrU6/JvUYpbiW4199fxknEds6gb+yqZTbphZCP/dcWCy3trModVBlU+J9woXUR5liV1epyaP4ahupuKSIpxJDKkedsnTiNd/raVTI6ZpdwDg7S2E2mSKOV5I3jEkipkRndiDuObcx09aXKcqfZprn5K1Jc8UA3HEZJLGR3O8lwgJ6n9GX3PU5UEnmaF7MgNd26MTpMqHTzGrkp08sk4Gatlz2XaS2ZbVO8X6YpwhypUR91LpbPsiTXuDypNZcNEXFUhTJEc4xnc4XxkH1AyPhTcWZOMv3fsDJXJO/Q0IWF9dgA6lWY4HMnAwPiWHzprZRNJOBEpkEEccTMgyupmHeANyOlfX6vuqVBHHxG/M0qQkoyIZGC51qpUrq57KvuzUlxYR/QnvlY4nNvK6AgYkjlxMFGwJzq2pGTLJrT2aS/cZGSjv35FnAoAY5YW9pZZWX3xGMkfLJ+FD3EReyiuIWIaMdxLjGcKwK788HwHboTRs/H7Pv4pYO8Ui4MkgkVQO7lURy7qx6ZPxoxLVLe0umDxGKaFI40Vg0j3OGDeAb6wzMD5AeQoFri02nu+P5ClOLVIVSyA3VuqggSk3DD9uWMgD1wAf8RrjgKd9DKh5x3MUv8Lvhh7vB99OLnhyx3dk8skaRx26K7M6gd4kZXSN92yw28gaFtlhtoZAs8UsrpcY7pgwAGl4tRHXKkj94ima5Vtu6Ve7v4Jqi+fV/KIo4ZZLS7k0PomM02sqQMIyiPB6gr3mPdXUqa7F36x2yo22+mSCKRDnP2lkriyv7aFLQu5kVYJ45Vj8TK0u4UqSBtqIrmPi9uWljjZxFJaRxMHXBDwacEYJyCgf13q1LJeydWC5bNfah9w61kN9NJofQzxRM2k4VUtvGcn9soDjqapDTFIYFBKlVkUlSRuJXbYj1arVf8Xt9aXEchfF2bhkVSHCCJY8hGx9n8KqPF9LRNJHq0xzMNwARHL4l1AE/WBGx60yGaWzargXmgnB0d2uZ2EZAdgSckqH7tkPeb5XIAXcncB85GDSbj8yvIAp1aESMuBjvCgwXx5dB+yq0VwC4PekH2TFMH/c7iQtjHXAP+vKkr702c9SMD4BsVlTd3WUkon01vFdYrMVdEDrC+A0pKivGucZUFkJ1EFSCCw1Nq0E6TvyJzTaPibRSuspPdSowfuFRCSQWimj5A58JBJ+s3uqt4ou3vCF0OO8j6K31STnMbc0OeeNj1BouVQSk0WXh/Fw69xC166sclC8EWo51ai4UnY75ztiirjhU7e3YyvzGXvSxOOS7AZJG4HMjcbVVJ7HfMZyMAlSfGgIBw2wyN/aG3LOM4q3pw8BY4DGZPo0DXEsaISxupDpjWRV3kGGiBAPJTvsRUWNc7+4xTkyu8S7mF9Etmoccx9Jd8ehK5GfMZ2oQ8Rg/5NP+rLVltLIzLIsvD0iJVhCwSSN2nONKhWfxjBLHbACnliubvgRMdtbLGYybiRDLIhVpRojJlK4yUH6TA6Ku+DmqeLvb92TVL+pCFeKRLp1WpVdj4Z5R4fNRnFGW/Era3cvHLeBtwHTuoyVJzgMcsM+e2aY8Xtl4g9rJCoQSO9tgjAVYm1R5IP8AwWQYx9Q+hJMl73wzZSRRS94yaJSofuUwsCRNKCoVUGGAIJIGSdqnhc8+5NchP9KFyxdbS7uW2Bdp5JGxnYEqhxueWetQXjpFgScPlj1ZwJJplzjnjKjPMU3a7BgdrtjBIZljYxxeNzAj6yVUqFbMygsMHwnOSd110YIGiiljM2VRpXd5FZRKquvdAPpGlWHMHJHrtXhJLlkc5Vz8AH9pW/Wz/wD0S/yrY4nbf8l/+mX+VWqS1mRYLeK8jhZRLFoYyYkMdxKoOFQxsWGkY5sSMjcUPxC3gurWeWJAHSV5EYKIy4SKIyrpIyE/WyBcjTpOPKi8P7v3K1S9fhFcHErfpZ4//ol/lWf2nB/yh/8AsS/ypvPw9RwuMKA0plSYk6QwWUTRrGudztCHx11ZxtUjcAhiuoYzmWORJIpBqAZLlUYSIPJlYoRt9Yc6rw/u/dk1z/qEv9qW/wDyh/8AsS/yoq07uSOSRbNykQDOVuH8KkhQd0PUipbfhqpHKQFlTMU8UmkEvCshjkQI2Dq/SLqAO2nHUGnkUv0Jb9ol1/3lIjGQTGYj3waMnbVtttgirWP1b92Wpz9SsQ8StQQ3czAjymRvmGjGaJeeJ7do7dZBqkWSYOUJESjICleaBsHzGN+e4nH+FiN+8jBMEuWiY52GcNGxbfWp2PwPIiobV+5w741KcpGDjxfalxvpA20nBOccs1Wl8OynklwwK1uWjkEi6SdxgjKsGBVlIPMFSR8aJ43ZiORdKsgkRZO7bOqPVkFCTuQCDgnfBGc867HFpQMIyx+ZiRYyfeUAO3Type25ydydyfXzNQWR6ayu9NZVUUS6a1pqXTWaaZpBItNbxUmis01NJYdwQxm5iadtMasGY78k3AGN+gFH8Q4wTFqSQ97cStLLpONIUFI026HU7Y9R5Ultrd5GZUR3IxnQjNgEgDVpBwM7ZNMF7O3ZJAtpThtH6tgNecadRGM5IHv2qJ0i9dKgjjfFyxSRGDPLbxxylvEyFcxuoPIFwisds4bHnkbhfF+6ikjxliHMTdUaRVSRixP/AAwygY+udxUtr2YvJQpjt3IfGklo1zqVmGNTg7hWPwpXeQNE7xyDS65DAFWAJXIGpCQeY5GpqJr3G3CePCG1mh0Zd942+wzK0bnOcj9G7YA64PoeDd2Ozi2l1gJ4O9Aj1KBlg2nUBkeyc+0dxikneen3/wCla7z0FTUXqYw4pxaS4H6TTvJJKSM5Ly6dXM8gEUAeQopeKwkpLLCzSxqoGGURSmMaUMqFc7KFBwfFp3xkmkmo1mv8CKrUVbDrniUkixhj4omkcONmLSOJCSR11bg/6U1h7TMq6tP6QSxS7EhG0RmOXUAR+s2LAbHfzqvryHy+411pq1ZNTRbbDjEMlw4Ze7hJhZQ7bJHaqcJq2Opl2BGDk45GuLPjUUjSJ3SxOZPpKSGR2HfxkPjDbJrGtcjG+jyqq6azTV2y9bGttxzuxcRqmqKbvNKsQGjLagrKQMAjIJA2JUeQw9uu0qJHcNbzSJJLOkqhMr4e6YOWJ+sWfp1XIxtVN01mmpbJrZYLbtE8ytDdyuVZf0cpyzxSA5DZzkq26tjoVO+kCq2w3rvFZiqaZTdkeKzFSYrMVKKI8Vuu8VlTSQJ01mmp9NacYBNaNAuwTWMn310HHrUapmi7e1ypJIGdh6+f3bfE+VAk2G0kPv8AZ9xuC1ed7lsLIkagaWbP6QltlB5DerBxbtfG8TvbmV3MiPEoik0Oyy207kNjHhKSqRz3HSvOby1ABwc5Br2JO1VkjL3dxHGxyHOrw6jHbMSMA4UiMqTj2gw50qUGuSnFciKLtQDcO0dtdPH3ttJEiQsW7pIpEfw56tr0+ek77VSr3gdw8zCO1nUSPI0aSRCJiF8bgIMKukHOkbAYq6J2zt1MDd42tbwiVtD72Uclw8TbLuALjGkeLw8qite0tmjwO1w2beW6YBYpmEkdxHpXxyEsNPk2ScDlQkSoqcPY+/dkUWsgMgJTUUXUANRPiYdCKntOxN7IkbpHHpmAMWZYwWBTvAdOcjwjOOY64qw8O7ZQW62zLJLIYbYxmJlZT9Id4ndzKzHIwHUDGAFAGzbAW/ayCOW3dUk0QXV3LjSgbuZ/YQeLGrc5Gcbc6hdyFn+5F9iMmIASKHz3kZ0JlBqcAkgDvEJwCcE7bUku7VopZInxqid42xuNSMUbBxuMg9Ku9h/tASFU0wO0ndhZCzJpZxHaxHSAMlGW23zv4vlTOLXffTzTBSollkkAJyQHdnCk9cZqItX3BlYHA/azRGmhoxvRxWnY1aspkaRkkADJOMAcyScAD1JIHxq6cY7Axx6I4r1PpBUExSFQGOPqBd1HPmDTHgvYtI71ZGfXDGofDYz3it4UbAwRnD529gD3seLWy3FwNUitExwVKHffcA5wduR2Od81myTt7MdDG+6PN+L8FltWRZQuXXIKHKnGzAEgbjI/xCl+mr5214RIglfU7xq6OmWJCI+VI05wMNgZxyx51SNNaMfmjYE40yLTWtNS6azTTNAJFprNNS4rMVNBCLTW6kxWVNBA7TUF2nh+Iphooe9XwfEVplHZiIPzIXC3bTrwdOwzyG+cfgaw6ujEY2osyEoF1HSMeHpnfp8ajZKTGHqatgTQfM1y0e9FrGM7077N8NEkoLqDGATuFOTtgYYHbcZOKXlUYRcn2LSt0IrGx7yRUzgHJJ8gFLHHrtT+17PRGMFiQxA2zydhkIfMgHJx1oril8IHaOMLpbZmUAaB9rAGdt6RycQcPG5OQWaQRjAC5xpLAcyyjVz6iudLPKe8VSH+HGP1E152fZY9aqTgsCAMkePAz8APnSd4tOxGPft6fkasnBOP5kIkwcnOkjkRuWPQchVi4gwnTvAoJUYAOMEZzuCN+dFj6rTLTOPIM8a06o7nnGmuZV28vw/0qwzWkcmTGMMBnSPZPu+yfu91JblShwRg5wQfwIrdKpRtGdSUlsQRIQaMQZUe6hDHtlDjzU8x6g9RUf0xl25+/wDnQwyKG0kU1Z7d2aYtbRMxyzorMfNiACT8ql4n4cOOnUdCOR/n8KV9kr7VZW79CpQ+hVmX8RinV83gNY5026NcexS+0XFHkgkYgLjEXhOQ+p85x+6jVSNNO+1l7pCx4zqYuf4QVH+dqrLXTHyHurVgyRjDfkTl3kEtgc63pqO3gJ8TZ9M/jRWmtcLkraFEOms01NprNNMohDprdS6ayppIOXtiKDvk8HxFWl7fNJuK22F+PL570eq0Z4LzISBOQrpYieWT7vgOnvFdAMzhEALNsPIDIGT8cV23EFiKIMsqAPIwwDJId12+yqEADoS2d6zzyKLo0vZbDL+zUhh7+YamJxHHnYtzGsjmBzIB5DHM4oCx4w8chdvFtggAgop2+qQBtjCnblyNR3/ETPIjOcINkXoFJwMj1OCfMA+lb4lJI8wtY8BdUcejo7vpOGOOWWAJ58ycmsuWWtOPZgw1atTHT2PeSASBmjygwGHidkVmJyRsAVwBnOa74z2cjLOU1IygEg5IZcjLLv0z8NvSrPwuzhBGmZ2dWLSIdKiViQwbRjOkYTAB20jOedHpZEd48hRgxbSVXBAIHhc53OdW+3PHQVzkqWx0eeUeNyWzJIysDucnoSD1/ryqzcImBjMZkIGgk5AyB5Et60sScSSSK+8eWCkjPgDNp/8AdOeApmSGPcCWRY+WToZRup9N/lVSbk0u4NKKb7CdI2QsUfZvPf1yCKmaLvFCyKGI5N7LD+Ic/cdq7tWEkYLYz5jbO3OuywXH5c/lXcWKFehw3kmpOtxObN1cgq23xyOh22oKeNSPXenEdw6s58HiOxLbgDlsoPT1FCXQMjFncEnyUD8Sc0jJODj9zZGUnyh92P7Rxww9xKCFVjpf2h4mJ8QHIZPMZq133Go0iDatSMPCU8W/ltXlb2qgYDEfLB+AxU1lDpVvE2TzGSNv2V5H8ayONmiOSlTIeM3xmlL8lAwo9Nzn7/wrq1teTMPcPzNcIPH7I2Ox2x8RzFGM52268vga1dPCD57dhUm2zvFb01MIWCljjGQBjrkE/lXOK6C3Asj01mmpMVvTV0SyLTWVzK2JBjkuAfed2+ROPhW6q0XTPQDHQfErfUPdsP699FRy5qRlzSHaAhXY894ipjkZdxlVXy2ZmVvuzSuKbUzMepz8SSTVg7aQaZI2HVHz/CRjb+P76q8Gxx6fgf8AWsmR+ca90GICXCqfaYAbZwSQAfhTHgbMb5GdskSSZYDGSsb4IHT2RQfC1zNH5BlJ+efyqe0zEybHvM6sHmWOcjHzFKkXHarLt3PEGujHBIsdsSrd4ViZlXSNajUCxOrVgHbcb4p1x/iSQRBGcJqOhWb7TZ3OPmTUHBLuaRBiLTkA6mIA+XPlvyql9qgJLl1kfV3eFHQDKgtge8/cKzpanRrlLQtXJ1f21tBDhJRLI3IIwZEyNyzLkDzG/PFb7ISs18jyHIhhnlGDkeGJjml8YVfZbb1xRfCLuGGacu2nvbWWJQA27y+Hmo8O2TnYbU2MFEzTyOZzwyVQoHoB/XpUd5INwNtzn1wSBS/R3UrR5yFIwT1BAIz88fCpbpvGQeZAYeo5HHuI++tc5aoWZIR0zoFlJzscGuGl+fUeVSSpUDxM5AQFn6KoJLAb4AG5NZzQYXrEcjkaG1EHSwKsOjDB+RrrVVEO2TJLA7+p335g0Xa3BGzYZeoI6/aB6H1FAF8VsTYz67e7rUIWuG37xfCcgHO+5Gx6/GoYoCyhl8SkZBHUUBwS+MYds7BG/A4p72CmUq8LHl4l9x2bHxx8614c8k6YOkWupXmDUltbvIwCr86vcnDIzzAru3s0TkAK1PLsTSVjh3ZzJ1SHnvW6t8a74FbpfiMYVuOSj4HyKDuLJkOcbVqKbFOklJGVRakJeMhZLpS3JJYY19GIeR8/DQKq/FbB4XTY6ZAGTA+0BqQeoJ5eWKsn0OSVrd0R37yV7hiqlgqgDuw2OWU0in9xYSSypaxpp7sAs7DBHhxlMjbY41DzwK5uWUFFtvjc01sVHhfCn1Ab6ydkXfScY8WObfsjlzJ6VaeH9gxERJOcsUJQcwhBUsznkpK6lGM4LBs5AxceF8Cit8BBkgYLHmfMDyH9b021715fqP8A2/PWNbfLHLC653E9q7acRxM3qf0a/AsMkfAV5z224fpuA50B3ABWJju2T7QOSWwV+GBXpHaXjK20TOT4uSjzNUjgXC5LiTv5B4j7OcnSDvnHUn861dD1OSaebJUYr5FzjK922/ThFTbhwMId2dX714wCANkVCTyznLj4Cn3Z+HVaX8bNkEW8YOFDDVKrHcDyU1L22tSuGjdmC7ENpxqyMshA25YOc5wOWN4uzJ/ucj43e7iVsnOdEMrdByyVrrY8kZxUo8MUpJ3T4EV7F3Zy+XCuYyw56QAEf3jlS6/nJZXU+zsD/Cp/nViixIHRuTF8/FjVaubVozJG3NSuD5jDYPxBFN1bUSKt2H206uNWOWNS/wDrfB86u/DeByCPVKO5Rh+qiDI5XoZ5S3eH90uoHUg5WvMreZo3V1JDKQQQSDsc8xyp5dXDTZZpJHDeIh3dhuB4tJOOgoWrGRdMsk09phoHaJ0Ix+sZyhG40sQ2G6eFuvOqjxjhbQHUp7yJvYcb/wAL45N9x6dQOHAToCD0PKuH4o/JTpHkNhQqNdy5T1dgZbWV+SN8RpHzbAqc2AQfpJAP2U8R+JOAPvqMXMjnma5dgOeWP3fOiACLS3MmqOHOdLNgnJbSR4Rgc99vM7daJ7P3fdSxyA7ZwfcdjS62u3jbUrFT+zttRrXUcjFySrMcnABBbqcbbk7n31Fdl7Ueprdbc65a5pFwq9EkasDnA0n94bfyPxosyV0YpSSZRYeHNnet0JwfUfdWUEluXYe6K1KeK8NHdsF2L4jyOY7whNQ9wYn4VLFdetc395p7vHMvgDzJR8ffg/Co7SLpBFtxiBdNusih027sFlbI5jGCCdj16Vzw/jAVxrQhnLhCSpyurw6cbhcajv6VQrW6Q3U7sAVRlxnyU8/fzJp/DcpkI4Pe6tSNk4EY27vT0IDZzzJJ8hXE6yPlkr5NeN6oPbg9ASXahOJcREaaiQMkAE5wM9SQCB157cqEguPDQHF5FaCUPnHdu2xwfCpYYPvArzOHporKnJWr4CGJSOVdLhXUnJ1BXU+o5jPu0mt38yQQakGC7GOP3nOp/goJ9+mqB2BuisTLqO+cZJwD7OB5DGDV17dRhEtNByq6wPUlVIP3ffXosuFSqHZb+3Bk6zI44HOPLRU+0G8J/rkRQnARosof/kuLmT/pxxID/wBxonjxxCfQUJZyaLK3B2Iimk/6k7KD8ox8q19P9Jzeif6b/IFw9CQSOv8AOt8W4Xqie4yxKhUIx4cd4N89Tv0z8KH4ZfouEBZmbACoNRJ9ANzV1nsSOHyxsMMY3bBxkHdgDjryrVCNm+C8x5WyVLbyEeHqN193Ufn8TWAbVDJthhzFLClHuTz5f0odlC9M+/8AlRb+Y5HcfHehpKgBCzk9f5V05I6/PepkiwM/18K6aAsyDoxwD+OfXrVkDeCcGN1IIw2g6GkJxkAAgAYz1yOvWib7sbdx+yqyDzRhn4hsfdmrB2Biw0sn7qD0AyxHyKfKrS9xvT8eJSW4Uo6XRRey1nLF3neIUB04DeY1ZOPlVhQZpjNGr1Db2xDitUUoxoEf8OjCR586yububSmPSspdWWVtZMHFcST6pY1z7IaQ/ABBn/GT8K5vEKtnFAQS/wB4f0jQD/G5P5U6a4Kg7QhsLhVvJdRwDJJjbbOtv6+FHS3X95QZ2yT79WwoReHFp5UcgFg8iMN9OZNSk567nI8jRfBxmSVHjAkXBBxnYjB0Md9OQSP3sdK5WTpXOWq/VGnHl0w01yy92L5FBcaQmOUDqjD5qRipeGnYA0fLa6wR515rUseSxvKPOOxb5bR0DE+8c/hXoN3C84iQbsrtpUkDdgcjJ934153dxvYXcgG6kB849lXbGT5DVtn1FWyz4uJIxMvNHUsPMEEH7q6HUuTlHJDiv5Lx4ceXDLDPv8Gu2/CGt7VmlkjRtPhj1AyOSwBwvkBkn3UivnCW8WOaWkIwftMXlP8A5Ki7b3aOPC5LKXVlI5A6cHPXP9cqzjyELImfZEKfBIo1x8xXQ6d3BOqOe+njgbhF2d9k7hI5TJpzlShAwCviBJwefLzGx61eJnEiHTuGH3EV50kWwON8cxnJ8htXonC7AxxKrEnA3J5k8z99bcT7BxbPIUTGVPMbfKoZxtTK9i0zyr5SSD5OaBuBtS3GkPnDyWSRDUq48sb7ctqlWBAM6gT6kfcBmuIl/Rr7q5a4bGk4I9QM/OhRmOnjGM5GfhUit4SM5O2N89NwNvKgXuPTHxNGK5Ma5AG55DyxzPXrRIZjjc0eg9jrJvowYD2yzffpH3KKMuYGBrfCpDHbxKOiL88ZNTJfatiK1wtIvJvJkFpAzGmfhQetQPcKo2pPe35NFvJgcBt5d6thW6WWQLNk8q1R0lsFRZbu1XByKqt9arHNG+cKxMbehbBjP+JdP8dXpAHXBFLbvhvluKq+xmxtoqMUCJxLS26vBkZ6sHGR8lNM+L8PQgPGQkkeSr9MdVcdUPX5ior7hfjjkIOpM6SDjGrYg+YpLfdowNaRRtKwU6iAdCjBydgSQPPYetLkkk22N12WjhU2vDbb4YgdCd8ffVmgj3rxvhfH3idSI1HQjLKGBq3R/wC0EKpBgbWAQuGDLqxtq9k491eS63oMrl+mr+DVDImtx59CSTjBSRQySWBDKRkMO/wQfgKoHavhBsbnukc9241RkEgldR8EmPaZeWeoxRzdrH+lR3DyuhELIWWNBgFw2kAA5HPfnUPHeIwXClmleSTSdJbWcdfDthfPbyrr9NjlDDGM6tGeUvNaK+0Zcov25EX5sKf9pQO8kx9aaT4qshA+4Un4GS1zbq+AFmjLMTgYDZBPlyphxPUyxykEgkuQNz4yTnHx++tADGHAwGeLPmNv3d/yq9vcgCvOez98JJl7tT4Rli2AAvI46k71dzIrda04Y+WwonnXGB/epfVyfmM/nSy5HOm/F1/vUoHmP8gpVdjc0GRbP8m6S/TOof1an0/A4oWQ0Vbj9EPe3+Y0DOcnFJMBETmmpTwoPQfeSfwIpSg3FWBY9UiIOrov/ciflRwRo6deZv0RfUlBVQOgA+VSw2zN0xRHDeHaedOEhAra2lsgPyIpOHE9agXg2TvmrRoFYqCqU2C5JCL+zyg2FZViGKyr1MDxUbQgVtiDQesA4NTD0NXKO5mhO0A8ctS0Eoj2dkKqfIt4c/fS+84PHa2UqRqBiJhk/WYrjU/nvvT19wR5/wBZrV9CJIpI25OjofcykfnQNBWeb9kuEJIokkGpstjPLYlcgcuhq3P2TtpI2URorMNnCjINLOz1u0cUYxy1g/8AVc/nVwsATjAPyryHXz6iORuF89joQUdJ57xrsVKq6ljjcqMDu20Eg+atgffSK94V3GlZIWi7yNiMknDKNyMMQRuK9kv5VT9ZJGgP23UfdnNUbj86TcQiRleSGOGRcxqT3hljdG05xsDIn+E+YrX0PVdTkaWWNL14YnI8ce+/5KPwa0WSfQWbSkckrbjP6JC4HXAyBTGK97yNY1U7DTkg7Z5nFLeHXfcySDAJMckZ8sONDEeexJqxWlymgnAUDY+XvzXRyZHFbdwdNg3DIxbyNqX2xjI6b5yB+NOyr8xuDuCORFK5rmORdmGpfPrTTszfrrED8n/V+jdV9x6evvp3S9U4vRLgtruVW+z9JfPPb/KKW3vtGm/FT/fJsdJHH+E6fypVeczTsm6Zvkv0jUB/Rj3t/mNBOPF7gT8hRcB/Rj3t+JoRj7R9MfMgUk5xlkmXUeoqy9nk13kI85A3yDP+Qqv8NXxg+QJ+QNWnsWmb5P2VkPyQr+dMxr+TRiemEpHqCIBWFqhlkxQ73NbFCzDLMEvLih2uqGknoOSWnRxozyytjE3lZSjvayi0IXqZZZE613CRyqLXiuJZMbiltWFF0HdyDWwmKht7kGilbNJdo1xSaEF9wluUbso3OASMZOehqr8XtZ4gT3rsARkMzHw53xk16OyZoXidqrxsCAcis+THqD0xl9SEfZ/hcLqHYa/PV0PUYGKudpFGo8CquPIAVX+DwaAMciMH3jkflTpGxuKySwuISjBcJI8V/wBoPCWt7+UqmEkPeLjliTdv+8uPhUPDbjMYJGQuNQ8zXofbi3MsDsEJeH9KhAJ1RscTRH1GFcfLoa80s51Q6h7J5jyPlQSi5R3QYZoiLErlfTofT0qVJCZIFj2k1qRjmPENz/XnQNw6AM4JHM0z7K2pBa6kGAFbu88ztu/uxsPPJosGJzkgZyoWXL6p5X+1JI3zcmgrmpLc5BPU1FdflW2X0nSnSx0cQ+x8/wATQj+yx8yB+J/KjIv1Y+P+Y0M6+EerE/If60mmcwn4cMaj7l+Zz+Aqz9hgTeNjn3b/AOZRVYt9kHqxPyGB+Jq3/wCzc/31s/8ABf8A8iUzHyvyParA/wBy+tA56UFNZyeVPjOK5NwtblJrschpFfFo3Wop7Q1Zg6npXLorUXiMrSU9oSK3Vjk4WDyrdF4iK0sAtpdUQzzqE3G2M1xOjRwn8qr/ANMarirGaR/b3JU04tbvNU2G7Od6bWdzuDmhyYxsJVsW1GzW5UyCKFtZMijM1lapjkxOkxQ6aPtrnNcXdqG35GgYiUbBpqgpozZcukfhlOxAwQQfcar1/wBmreQklAG+0ux+J6/HNFPegdaHbiG9SOCthX+Uhb/udAMbF8HI1nO/qAAD8RUXE+DOI332K6fnt+dO4r3JqS4m1LiijBwVJBxzxclJ9ijW/ZoYwanbswhPKrC1wFqNrwVaxMbPr3LZCX/dpNOAB1/GknFezRVQU6ZPzP8ApV3S6rt1DjeqljVUBDI+Tyd4CmlSNwN/jv8AnT/sI+m6Y/8AwuP+9DRvaPhOCXUUt7KN3dxk9VYfn+VK8OpKjpSmnha+x6A0rE1jPjrS+W8UDY0ulvz51rUbOLRYGvAvWtDiXrVae6J61x3586Lw0XTLhHxUedZVPE586yq8JF7lsj8QwcEGkPF+DsuXQZHUCnItyvsnIomGYHY0tScXaNCKIhxTC0kwaa8X4MDl49j5edKYLOTnoNMU1JFNFksLzFNluMiqdDIyHxAinVpdjFLlBANyQ3WbNDX0BYZXnUfeDmKJifIqLy7oRNOWzKtPOynBqAXW9NuN2wzqFV1xWlSTQmOIaRXVGC62pDE+KI76qdBPC72Dpt+tQGI+dRLPXZuaFsbDFRMhIomC53pabitJJvmgaselRaBGsi4IpeODxrIGKjr94IrOH3eDTdtLj1pLtMcpuqKxxLhunJQn3UiZ+lXSROYNVbidrpfI61oxyvZiJRBA1ZqrRjNcEU0ElD1lQg1lQhfRUEntVlZWRDEMo/ZFcNzrVZQdwwHiSjTypTaVlZTY8Asaw0xtqysqmLYNxLkfdVU+t8ayso4cFIb2ka6RsPkKHuEHkPlWVlTuWgGuoOYrKyiDCJlGBtUQ9msrKpcFhFvzpzCdqysoZkR2vOknGOdZWVMfJUxc/KhmrdZT0KRDWVlZVhH/2Q==",
            },
            {
                id: 17,
                title: "La abuela",
                genre_ids: [27],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxQUExYUFBQWFxYYGCAbGRkZGR8bHhseHhkeGRsaGR4gHiojGRsmHiEgIzQiKSstMDEwHiA1OjUvOSovMC0BCgoKDw4PHBERHDQoISYvMTEyMS8vLzEwMS8vNy8vNy8xLy8vLy8vLy8vLy8xMS8vNy8vLy8vLzEvLy8vLzEvL//AABEIAQMAwgMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAMEBgcCAQj/xABKEAACAQIEBAQDBAcGAwUJAQABAhEAAwQSITEFQVFhBhMicTKBkSNCobEHFFJywdHwM2JzgrLhFSSzFkOSovEXNERTY4PCw9II/8QAGgEAAgMBAQAAAAAAAAAAAAAAAgQBAwUABv/EAC8RAAICAQMCBQIGAwEBAAAAAAECABEDEiExBEEFEyJRYXGRFDKBscHwM6HR8Qb/2gAMAwEAAhEDEQA/AMsCU4opAV2Kfi89iu7GLuJ8LEDpuPodvlFcZq5FcZJAPMMWON/tp81/kf5miFjHW3+FxPQ6H6Gqwhr1gOcV1SlsKniW8ikKq9t7qAMpdVM5TrlMGDlnQwdDG1P2+NXFicrDuIP4GPwqJWcB7S62uF5rSOH9TEgrG3xanWdlJ26V6/AbuYJ6CSNIJ6qI1A1lhp/tQPDPiGGYYLFEdbdp3HvOUV2eNm2Yc37TR8Lq6mJnbeJ196Hf3neWe6woeCX/AP5c/wCZf51zc4XeUhTbMkkAaHUAkjQ7wJqLa8TED/3hh7k85ncd599d6c/7RyQf1hJBmZSZgrJ6mCfrXeqRpX2M7GBua+nYwdRvMRv1pxuE3QNVA/zL379vxFMHje/2yeokkympJDH8QDHalc8QkzN9NZnVOcz+Z/oCln/E36Kr59pIVO4McbhziJyjMJGvLTU9NwKkWOB3GnUCGZee6kA8us/Shj8eGn22wgQdtunsPpUVuOr+2556Busk6xzrinUEfmAP0uSFW/ymG8VwvIrEsdAD8O5JiN/f6UNihlzjS8rbE9yB/Oo13i9zkFH1P8vyq/EjqKdrP0qCcZJ2FQ7TV7EInxMB2J1+Q3qvXMVcYau3sDH5RTKgdKtqEMHuYZvcZX7ilu50H8/wodfxtx9C8Doun47/AI01k6UkSpqWjGoiVYrqvYroCikzmlXUUqmdBs04tNLTqVWIYiWvRSFJTUyZ1FWDgz+Thb143PLN5hbtFFzXGNsrcuASVC2jmQMZ1MCCJBr52qVhMayrkhGUNnCuuYBiApYe4VQQdDlWQYFQRciWLxM6+XgbbZhaTD2TcZQJ+1Rbji2DoSAWadpuAGld8X2cPI4fhbdgCYxF0C7fPcFpW37DMPahZwV+/btk3FZVkKC3waglYA9PLTkMvKKh4nhLqyI4EXDlBBkGSAR2OvOgGngmWnE4XVpNe9bfeX39K+Pv2zgUF+8Ln6sDdK3GTO3pGZgpAmQ3LnVGu8WxFxBae9duoWBCOxuerlkzSVOsemJmtF/SPwRsZxTyw627drCI1y4wLBB5lyIUEFmYkAKNTQDgODNu1et2rNq9i1xfly4UxZtfG1nPoPtBDONVVgdIBAoQFgEG4NveE764a1fKXc9y8bQseS/maIWzxuRoRGXoZqvEVfeLPdThGCtJcZmvYi8PQ5IujzHRRM+tWkRO8ioPibwouHslrRe41l1tX30yG6y5slkRmOWQCddW5QaJX95BEqCmu4rTcF+j+0lrFWL2V7qXrUXlBUqjG1JUEmBDXARrMDoKF43wbbuX7IssMPZfCWsRdLZrnlm4SoRATmcswAVZmc3YVIyLOoyjVYcL4Tvthr2IZLts2jbCW2svN3zGy+iY20OgM9qnYLwootrec5hbxN2zdSQFbyh6ApGoD3It7n4wREVYeOYYYTB8UWy7qBjLSqwdswHl2bhGaZOjFdTsNZqC+9CcB7zObGAZrwst9m2bK2cRkMwcwMGR0010o/xnhiXcRh1W4uR7qWFUbrbDrbRswJDFhL9gUJ+MU7xvwkuHw6MzFsQbRu3FBGW0C9lVtssTmIuE5pg5CADuImE4TaIS4rXQYDAhlBBB3Hp0II0M1zOANVy3D075W0qLPMHcZ4U1oi4qRZukm3BLenQrJPVSrDUmGHORQ7y6O+IVKqi57r5iX9bAgH4dAFEHT2AiBQcCjQ2tyvIhRyrcicKlJhXRE7VyKsgTwMK7WuCNaSmK6RHIpUs1KunRniGByGV+E/hUYVZsoOhGhoPj8AUMr8P5f7VQjdjOVpBavVrwmrFwjgKlQ92SSJVJyjUSudhqJ0Omw66gEzBRZjGLA+U0ouV+a7VasPCrdt2uWrmHtKyCYXOCNcpBJck6ldZ6701xXg6oC9uco+JTrGsSDzEkCDqNDJ1gfMGrTLB0jnH5g3A59xJPh8fY/wD3G/0W674+xFpWHxLdUrPUK5/MD6U34eP2R/xD/pSpnFbiLZzPbFz7RYBYgTlfVo1YdpH8KoP+SbPPh3994X8T+MrZxLXbN11t4nDWgzWcpvWXt3GYqVYgAwY3G4YExrA8Nccw9u957N5VuzolmGe7cVQHtqHy5Ze8XuXCSNVT7tQ8CbN5M3k2hqVYZEkEdGCgwQQZ0O45TQjjfDPKYMs5GPPXKf2SeYjUH3HKTYpUnT3mVl6TIuMZQQVPtDuF8W2VtYQvbLXsI91rduALTG66urs0yPL1hY1OQyBNSLfi+29i4rgqy4n9atJqwZsrHKzACT5xFxiYBBYDYCvMLfYqhLGSik6xJKCdu9A+PDy7qvb9DFA8rpDZmWR0On59ahWUtpqFn6JsWJcl2DX+5YOM/pFa499rduFv4ZbThiJRxmm4kTI9UCYOinSIpkeNQUSGv2mOGtWLhtBQw8h3ZLlti2zq5BUgFTqCYgzLt98zDM0ZjpJ67VUsdhZxLW0AGZtOQUMA3yUA/QVyMrbVUnquibCFOq7+IWxvi8NhFwtm15YS+r2xOYeWoBCMdC1w3VDsY1JO1GOJ+JLDi+L1q8bd2+mKVShUFhaW22HvFoAXMo9S5gVnY6VAs2lsW2NsQVRjmI1YhSRm7T93b86GeHeIXC7qzs0qW1YnUETueazPWB0rgQQSBxBfpGR1Rju3+r4nvGPExv8AmFrYF295fn3AZz+UoVQixFpZAYgEywGoAiiHCjNm0f7p/wCq4qBxvha5fNQBYjMo0EHTMBy1gEDTUbQam8GEWbf7rf8AVeoysrYrX3jnh2FsPUlW5o/vIniUa2v3WH/mn+NAhbLEBQWY7AAkn2A3o94j2t+7/khqfwq2LaLliSFZj+0SA0HsJiPnuaJcmnGDKcnSNn6p1BrvK9/wa+NfLPtIn5rMz8qi3rRUwwIPMEQfmKOYPCC1fuIvw+WCAe5RwD1IBIn+dTOIWA9pg26qzKeYgFiB2MRHseVEc1MAeDATw4thZwd1JBH0+ZVWtnKGgxt7/wA6cwljNry/rSpS2MyIJ9MEn3zEfWI+UUetcXUqFvWLV1QAAQPKuADaHQagf3lNS+XsJm5BpNfAP3gjIKVGv+S64v6Wj+POlS8qqCV3H9cq6NCcBxcEw4juNvn096K0QIMkgiDMdw2ZKfT+XSrHw3GreGhhxGdSG9J+QIyzt23ioWHtZmVepA+pAoxYAMAaLOg6A6T3PU0OVtqM2fB1yFmZSAO97wfYtqMRdZmi41sRbGuVA1sA3CNAxABygncmdpexh+zuf4b/AOkmoOAsN+sXrjfeVj7TdTSp+LHouf4b/wDTaoP5hNDo2DdLkI+YP8Pf2Tfvn/SKf44Jw5/xF/0uKj+Hf7O52ZfxVv5VK4uP+Xb99f8A8qJv8kDHv4d9/wB5D8N7XB3Q/TOP4iiHF0zWHn7uVh75ws/RiPnQ/wAOjS4f3R9cx/hU/irgWWB++Qo+TByflA/8Qrm/yiDgIHh7avmd4EfZ2/8ADX8oob4mX1W/8L/9j0d4UgFhHMGUKKInWGluxEV3xrgYbK7sFsWki486s0lsiDmxmBpHPsQTIFym/md1TB+kRRzQnD/G/wC8fzNC0X/mrp5i2I+a21/IkfOiX3m9z+dCsVeCYok7FVDextKJ7xvHauxDdh8S7rmCjEzcAiFL5ARyVDfZvoZg+g75SD9CKr2DxZDfZYe1nIIGXzWOo1gG6Z0qwMJV0O5RgO5KHLHWZEe9D/D4HrAjMQI/dElh/pMdu1HhOlW2i3iCa+oQA1YG/wCsi4/iF8Ao9pUzKR8LagiNJYz71P4R/Y2/Zv8AqPXXFSGtEH9oZffmR8t/cV7w0RbQdj/rauYg47AreWdMhTrCC2rbv+0i+IR6bfu/5JUjg6OFXzMpWPSCDmjlJDAARtMmI5RXnGFBW1m+HO0+0JP4VNY+pp3k7bdZHaoZqxgQsWDX1eRrIquDV3/EiriR5721Eek+Yx1ZmUTlnZVUiIUASJ6RJRJVhvKOI90YUOw7EYq4vltqLjZuWUgsG20U9flvRTCkyIMHWCPblQZGBIqH0FthyBttzA+T7KeWYZe+hDx1AhZ+VMV7dd2OZ2Zm6sSx+p5VyTVkxfEMeLGERGBIBsjjc7Ce5jSrilXTNi8H+HUvqbj6gGMu2x/P3nkO9GOL8MS0qm2TBMZSdRvp2iPxFRuE8U8oEZcwJnQwQecEda94hxBrra6KNhz+evc0uuNw99o6zoUrvGbZIII3Bke41oot5Dzy9iDHyIB09/x3oUp1A5n+pqx8G8K3r4zZlS2Dp6ZLR78uVW5WUcy3oXyoSUP34nGHwtsrcvklVMguZhnOuW0kAuxIBMwFE9ogu9sggvAZWWQraZlKztymaLcf4Q6C2CxOUZVBJiN4UEwpn66UuGeGZAe+xUESLaauemblb+cntQhkI1XLB1GfFqQAU19veVrhqJaV5YksVMBeS5gNS3PN+HOdHcXjBkjybjW2+IsuTbbIwLAGdZM7RBmtRwPh421DWrVu13IzPHUsZI+UfKn24HiLnxXB83J7aabVBzDVdXOTLkGLytQC/SZHZxthFhFuETMHKJPdgdOnw/maewnBsVjTmtWWZBop+FB1hmIDHrqT+ArWbHgzCoQ720a4onUenNyJXmJ6zRm7fA9I/wDSNqPzgNwN4DvkdQhPpHYbTL7XBHwlhkvvbLBgyhGLZc4yw0qAJidO/wAw3FsYQFDKLkywDklQZico3n395q5+KsA19iFKHN92RLHSN4gaDrVG4zr5aeXke2pV5kEtI0IIkAADfqaqxDVk1GWZMgTFp7xleKc2t5m55WCg/wCXIQPl+FTuK8LU4xLIJBbIGbfXLGggchUXgOCz4iypiC4J9gcx/AVpF/C2cObt8qA7buxk8gACfhEaaVe7qjWBBGR86aXawKqc8Dw9mzNq0Ph0Z2M675Z+c5dAJ70SNsfsj3AFVPw5xclADq2pYE6ySTrpqPlVjt3ww2dflI/CYpvHemzM/KfUagq5w2xfdhcRWI+8NDrIIlTrqCf81P2uBYZQALYgDmSdz3PWaE8atXcMXu5w9stmMboMoBJ6iRMjryoNgvFZZZPP4ROw6t0ga/XtRkAwEd13BI/WG+J8CsEBRKy2h3iR3PYD6UA4hYaxo+VlHwsZ+kggj936VweKXb10G3LMPgH3UB/7xl+853VTtuYqXxHBW1KvdBgQcwPqaCc3qMZn2Oum+kTC+fQi3GsDZnyagxvub3kKzwXFX9TdNpQ2ZEVduhbXU+8/nXF9MRh3XzGXLPxi2kA/3gV0Hcbd9quvhriNu7YVgwJ1DQdQV0M/1zFRPF9215L6DRDr35VkHKwM2AvpNE7975+so+NtlWIMT2Gmuug5CDtUOa6GIzKCeg/ARTRNaS7gTzrimIizUq5pUUGeg08hqODU7g+CN64EBCgAs7nZEGrO3YD6mBzozDqOYXhL3iGBKqGC5tgTuUHfKCdNtK1Szxezh7Hq0VBAAEnTt/E1m/EuIhyqWgUs2tLQ2Pe43/1GOp6aDlR/gWJuXEJuJmUMFzaCTGaI6gCT8qUzofzR/pcoHoMOXrHmXfPuP9mYCoQZAIHpIjcmfeewj3B41bBEoSg3YLOUTuei678vnTHFHd1mwEFwABM85VMxmIG5AkgdfevLt39WtJNxmuQQGMZm0OZmGwmdvak63uaDgEVDvFvGKWvSFztpGU+nUaaxqe0UJT9ILBgpw8+mRlfXfnK9B1qkcSLuVyMQ0jLtptv1A3+Ro3/wy3awy3L1xmkachtOscqtZtMURNUsieLFxCny/i1BUmCvTN7dpqJexbeqWjMZkEgg7mGnYmdO9VbDcIYFL9q44EEgONSNwCY+W1G+G4oO+uvvBA0n09f4gzVerVLhhIkq2hb4QW9tfx2rrivB/PtjzBluDRbn3o/ZcffHTWR15USFxRBiY1GvURttoK4xmIUrPTX+M/WrF9O45gHGG2aB8Lwe1h4eczDdm5cpUbD3P1qH4x4j5qqkHLIJOoUwZAB2OtV/xB+kC2ua3YUuQYLzC945t+A70c8MY83bGa5YazM6gMbbAnQqAxy95G9cWI9TbzlVSCq7QHZcgypgjn/XKrbwLiRuCJhxuJiRtmX+X+1AOIcOKlsuoUwNARyMAHT8AdaEWse9lsx0IOh6dQe1NYerUmjFc3RMq2N5eeM8POJtPhy2j6AjSBuAwnWHC6cxPeMlOHuWrjWrgKlTDD22+XMda1TgHiBb0lWAZT6lO+u5XqvfroaXijw+mMVb1qA4EFhqGHfr7/nNN5MiqNRMUx42c6QIB8NwEYiBp9Z3Pf3/ANq6wfE7llgrKLrXJyOSPQRPpI+hnv2oaPC+NtOty3kIGjiSJXp8PI617isPezj0BSNicxI7gZZ+dIZycz+jfaanTacKevY3PbzmwVdA5YOxuAAyxaMxDdJEgd+WoI/ifGLmJhVBFv7zNAJ3+7vHfaZqyYThkgeZmeNTJCg9uv13rjxLgVFtLltFRfhIXvJB2HfXnNSnSNeppXm61dJVO8qwWNBsNqaY04WphjTNTLnU0q4zUq6p0QNH+It+r2/1Vf7RobEnod0sA9E3bqx/u1G8OgWkfFuAfLISyDqGvESpjmLY9Z75aGZySSSSSZJO5J1JPc70fMskq0a1zwjwpBhrWbQ5SY7v6iT3jKvsveshtCdK3Pgtofa5TtdIg6ZYhQPoAfnVGbipdhG9yJjODL3HIldCO9AsRwa8r5bllcRZI/tATnX95OfWV+mlW7EXoIMrMwQOm3OnWIXSlgaNxokkVcxXFzh7uW6DIOXNsCGI9S84iZ5jblVst4p8T6HRTZXmO3NTJG3KD70d8X4VMRYZLgnKQ4H7u8fKaqvDbC2VZLbyhHwueR5AqNB7g0DqT6hLsL76TC93M91Lan0AmRA2yaexzR8o0qslWW8qqSpViNPckgyD6Zn27jSi2E4kLakhQjRDZiW7k5tiJMz366VD4ZZm8rzILj6k70vVGNXtO8XjXZWAIGXT1aAmNQTuj/UEHQkbUvjPiHEKjWGDKdWBPME6ww+ITsRV74ra0KT6W5fmAeRG47GOQqreOOGXjaRTFxVJysQc+gnLpzMR+VMqN94u72u0qfg7D27uKtLdEpOo69Ae019AG7aVVQ5AGEKhgT2Ar5nw19kcONCrctPpW0cDxlm9F5s7SPTPI9SOo27a9TNXU7EGd0o1AgR3HrfW015gFCg/YzMCJkQJHSNZ302qn2McmJkKrTsNB9SZ0HerfjMc5e2gRjDRdd4+EqRCftakH2B35ZqmDewZAYFHKE7aqRMHodvearTSDbRl9QG0Pt4eLuqs+QAGWXQQFJO+23Ou7HFsRgSLa3ptT6TAIBOuU9+dS04paZbaZiS7KrMwIH7bAcjOX+FP4trbXnBUN5jQQdjlhB76Fj9K3fLxutCef8x0YmSeGeMsR51tLotPauNEj7N1nZh6jOvQfSm/EHihZtqxBeX6D0i4yK3uQPwrO+L8WCu1vDzlDQLhMkhT6cs7RE5tz2oFezGWYk9STJpMoiOCvaNeaz4yrd5tfCuIK/NB/mB/r+tKg+LuKLlFlCDBzMQZ6gAnnvP0rPPDfFbik2yzFSDlEmAR2/hRN3mmvM1iJsuk1HPMrgmms1LNUVBnc0qbzUq6pEL+IMSodMNbM2sMMgP7bzN65830HZVorw3hjWgLjW7WItXEEhfWyTBlJGXONiJ66iqfZbWrtwPhSW3Vv1gG4QrKthwR1i6Y+HkRHPeq8+y8xzpxb8f39ZJveFDNt7DjyrkfHIyd9dSB0Os9eWo3L/lpCSSSza6EkksfbU/lVbs4z7T7TRRtG23L+utMnjLN5jgGCcq8vhJGn5/SkRkZxXtHnxIhuuftOsdxaXTK4j70iJgiZHIzp2+Wpa9iswkH3qgcT4kzXLgtkS3xPzJgA5eQ23qr4jCsmY5jrvrvPXrXASsmaTxPiQWGnTY1zwCwtxGOxzRpppyjmNI586zTh3mufKtkxuQToo5sZ0A71o/g3DPbd08wXFKgwDoGBgmen+0E61O8lWAM841wxxBy+aACMpOV4PJGMCQYiTy3qBw3FFkbKCjKdVMKT0J017896tXHLFmJuMiNuCWCn5TWf4tXS7kZmuKRKOreoSY15Nr1+W8VG91GAvmDbmGbsldQYBOvISQIjkI0577UL8Y8Uy4YkKS4ICvuqyCM0j4TBjWNYqVYv3rg8vUkjUKNSOpjb+FP8S4VdsZPMAUuDoDJHUGNJ7U2mCx6tjHMPhmoacjaWPA7/O0zTgvhY3cxuF7ax6TlBkzzBIMRPvpR7gXCr1gX7IDC6CDbuyxttoQFj4fVG++o5DWx2BrJUsBvvp0Jj67iYprj3EjbtZ1AzEwsDmoURl2AAI2NVdXj0L6d5bm8PTBWmz7n6ys8K8ZXiwS5bDNMAaiCORk6EHkZq3cQKumoJ/azLl1O/KN5rgYC3cIxCWg+IVPtbR9JvLpLqI/tF/HY7iGuO+LbItwkMxHMfnWTmUuw0CL47UEMblXXCKXNskgp60PTkfz/ABofxzit2w0BhJVgIiRJHq996I8MuPfJNu2bjAR6VmOcSdPxoF4jwBDkvbe2/wDeET26H5Vq4sxVAh5mZm6e2LDiT/AXD7FyWvrm9WUAgwNAZMe/OtH4ngMK6iw9pNvSRlWNOWsk1m/gg2SLlu6xUg5h3j+v6mtWwr2Clu4ULG2q5jHwwMokEaxrrSuUnVG8CAoNpkP/AAS5h7t4MBCNl33n1Kw7QPxp2as36SrxcKiwPNfMTGpC/Cv4z/lFBcFgkW2FJkx3n5dB2pnD1ICi5K+C5OoZjj7Dv7+0hTXD3QNyB7mK7vplYignFfjnlGlPM1LYmGcZVijbEQvmHUUqrk0qDzfiT5cseHbWrBa41bs2cqjy3YfaOWkkA6BAB6RG9Vuy1MYizMmfV1O/+1FmIGxlmOxuJZ8H4jtPNq7dusjR/wB4ylWEwVLECNToe3SrJxbjwW2LdtHW3lADupWNfhT+7AiTJOtVnwLwmziDcS7aVzEq0Gd4PPuNulWzAcOsXFu2gi2rdtmEglR6N2Oo096z8mfcio9jwEgG5WRxRBuY/r8BTWLxysPiHvNCuJYrK5VB5iidSNwOevaucBL3YyBARI+QltOtd2uB3qWLw3hbrMUt3VtAx5jmOsBUnU7nTbftWh8KcWL5tIcwKRpqZU6FtOcnXrWbC9Yw5W9dU3hubeaNQCPmAY051b/Afis4m66LZREVM0KZKnNCjYTIk7cqFH2ljY6I3li4nZYox2Yjc1S8BZzMqqACzZQNvUWgz86f8ZeKbTv5C3yoUxcGxJ/ZPSCAZqJw24Lbh0uBxKuonYqQY9jH50x0ppj8zT8P6gY8mnuRQ+D2+8sfhvjq4dbiuhYNqAIBJ2KknYR/HrUTi/HLl8Kr5QgMhQOcRLMdS0c9B2prjIQublogo5LQfiVjqysOk7HaParTw2zg8Olq/I9Q+J4Ztf2FGxB0kd5mnSQN63mllOLGRm0Eu3A+R/Mp2Htq7IGJGUsVhsoLFYAfqsgdOfImmeO8JuPbtJa/tYuFrWucgG2SQMujAMoKkyRkgHnN4i6XL7m2Cqu+maJltyY0AJkx3qF4W4Fj3uvirZVcPiJPls0m5bOlubcgaJEHNsPov1P5fr/ES8UfQFK7FqJB+P8A2ULHG4ozMzB5iNQwjTL1B3n2pjhnB3xDMC0ZSMwmSJP48/mK1bxT4ctXEN29bazdDKMyqrqFyCTcIJzosBQ+jLoCYihXBeE4GxcZ7eId7jCDIkaaymUT+JrPYhBtzMzGTlo9u8J4NjhEVbdjMmWVywJjcfvc/wCdE/ED2b1i5buZZySUaMyyJBI5e9cXeKBbWhOWQCWUqI6SfhPc6GqR41xVpmOQkXLoysFjQag6xtrG1VDeMMKmZ4fEsjhhvPPn71ovh7idkhbl64AE9WV3YmeWn3h01j6VAw3gAMMxuEAakQJjtV4w+Gtonl20VUEQBpOXaesHX3q3LlQjaUdPjdLviVTFebjJxFtZRH8tbYkvqAc0AbDQe5NM4XDOwdspi38U+mO2u57b1f8AgSKue4xEvcOv0BnrtTHHcM13zAFDkA+kTCyIDafe5gdudU3R2m50PXNjpK2vmUDiliVDiNNxQXE2Q4g/KrXcsACN5EUJ4nwe7ZVbhAa0/wANxDmWeaMR8FwHQqYM7TWp0uTUukzM/wDo+jGPKMycNz9RAqYAwNvoKVPzSq38OswPPb2E6t1BvX9Y+v8AXOpamunQGjzIW3ElGrmXL9F9oAtdJgk5I02kfyFWvgXEQ6Xb36uqyS7BRLGCJnUZjzFZZwa5et3PReKruQsaxrsQQKsWI8Q3suRSySPUQASfaFFZOXEwY3NPDnUIB7TvD47Dv5oICi5ezCT8KzO55DX6noKgcXx+GLZrJJYc1BynQiRO2lCcbw0v6i5IPKuXshEIUQPqdTH8aPTA1n2gniGK8wA5jpy68zV+8OYQYPDM9xSReUB2UGQJBAmdTBPTnGsVTbOEtKZYH23PsTsK1vwxxexibPlqoDIsNbInTae4NBkJUADiWYRbEnmC+I4BcttrNsMp3BSAoG5MDQ8u9BOP4dbEPbVVZXXQbMGXMCs/Dpy2jlVts4pbN1sNbXy0y553AnkByHasr8YcY8y7kRpVCfUPvMdyOwEAVGGy0tysEW+/b6y+2bysguAgIQDmJgCdpJ0B7UHx/ieyj5EBuN1g5duQEM//AJYPWqM2IuZVXzM2U6LJyrPzgSelE/CkZ3YwCB6CSRBkyB1JGnb51pHMahZ/GM+QaV2965lj8PYu/dxTWXNzPdXLblYy5iUDhYAQCWaIGq661rSsFcZQciwFH91RCiOkCPrWQ4DjD2MQt1che3ETroZzBtZgz+M1r/h/iFvFWRdVGtkkhkJ0kfstsVnmYqrITdGZbu7qrMbG4+kc4PYxKurNeS6JhmK5WiQTzBB00+IUG/SV4Xw6Ydsek2LtkSMnwPmIGUpsGYkeoQZiZq8YPDnTtWbf/wCguNZLFjDKdbjG4w/upoJ92II/dNVAXK0bcVM9x/jtnTIbX2k7gwD+9351XziyLxZwSwO/8gdhUfgmDN28qDc6f7mNh3q68e8D4vzc6WTcVlGqAaQoXUTodN+ZoCqrsJoY2Ln1NUh2/FZUaK34fzrjE+Jr5XRCoOsjU69KM8G8AM8G5eRW/ZAzge5BAn2mmONeDsRhpLDPbAnOmoA7g6qPfQdaAIsPLlo0vHuZP8HcYV7OS4/qUliG3gsSN96P8R4pZUs63M7KRAV/2ramDG++/aswxtowpA1XfWP6E0Vw/DybLeQbdxwMzKhk5fvMok7GNN+fKu8jUfgwV6tRyLI7Cc8SxjKYPxRt0nXXv2qBw7jF6w7NbbR/7RGAZLgO63EOjj8ROhFQrt0kknc6k9TzNNTWriwKgoRPrvEc3VMC52HAHAlh/wCMYA6nhwk75cVdVZ55V+6Og5UqrualVmmI6jOwadWmKcU0cOTMO8EHpRNXDiBJJ2HOhNkUVwSGCF+IiFO8E7nTmBS3UY1I1GXYWN1IiiBJBk7DWddp1+f060ziJKup5EDTb1LIM7Af7VZeHcJtXlVrnmIMxNxtggnVUg+pgABOw1iYipOM8JW7hJw90XVT1MsjNO4LCAdflIUAUl5iLtHhjYi6lI4XY82/astILXFQwNTmYL6QffSjviLhmI4beD22OUyFuRoRPwsOR7UdwPgq0LyvN83QRczN6fVuDAE6HWAeVaF4i4fbxOHuW3Gly2XBgelo3H4H5VQ2QE7QwhUbzBuM+Jr10GWAlcpKyJGpjcx/HSoFvhAI+MyBJAHpH92eZp3BPbunI6hGI9MTl2JgySQTRfhttMVfWwSUtrOZhoSFHq5enlv0AG+lxXSNpQra29U48IcAe7czhPsgYDsYWRoY5sfbQVfsRbsPZNpCSrqVF1CCAdRpvGvPrRu1wzDX7VlbBR7a+kr93KbbCCPmPrQ7i6N5lu2IJR/XkQD0ZWADEACASGE66d9F2csbjuLGqipkTXyt8LOqsUI2BIMEjoJ+lb94JVWwuGYKQTbZiJ0guQG06wT86wziXC2bibWUgs14AdCWAaPnNbhwkfqXD8zZAyW8oK/DMwpGmpLESY1JJpljagzIzE/4x7zP/wBKXjBmu2rGGxFyLIPmPbdkm6SQykiJygQOXqNZ5jMRevuGuPcuvAEszOY5CWJMVcfFXh5Vi5hyhU7g6mYkx3pXeDJbw6OpkOfUzaAkqSsnZROnzArkcGgO+0vbH5YquBD36L/C5tg3roAZvhnkOk9z/DpV341xpMOAryA/pQ6elipIB6AxodROmlVTwVxO/bww+F7YbKrO5AiTmVTlbNCxA056xS8WcRtXLLLcQqM3wn1L+8NTlHLSOc0g65F6gk7jg1/yMIAybCQ0w962ua2xbYAe/XpV44fxu06orgzGVm3Bcr6kAGpGse9ZPg8ZilUKiG7bywrZ8h7ZpHrA01ie/W94FLNo27lrP6BmD3D6VZgM8zBjv3O4q5ttwZaBqG4lM/Sfwg4fFFVXLYuDPZEQBoA69obWOQYVY/0c4Fb36viLUI1oPavKB8Rj0vHUqRJ5mO9CP0qlWuWLgxS4i4VKuqQVSI1UAkJM6g66VD/RdxRrWMt259N2VI7gEhh7ER860iC2CxMxCFy1BHi/Braxd+2uyuY+cNHymPlQOas3j+0Vx+JBP35+qhv41F8OcBF0G/iCUwqGCRo11t/KtTz6tso700rAIGPtKGQlyB7wDm70q0f/ALRlfSljDKo0VfJLZQNAM0+qBpPOlVX4ge0Y/BP7zPAaftVHSpNogAk7CmTF4Y4Jw83XC8tJ6nso5sdunMwBNaBgrFjCuLRtsWcaPvudYMbDTpPyiqT4H45atO1y4pOmkcuX1itSwfF7OIWbZzAakHcVjdVlZmrtNTpkVRfeV7j/AAtMNaUWCfMAGcalXA5FdQG71m3FcVeF7Oj3LTQqDIxVo1OUlTz3itCZrli7dbNNtiSDz12Edf4+9ZZj+IP5l12EMzcj8OugHfvQ4BZh9QRpAm78G4sq4ew90l3FtczH4tREtymOfPehHi7jCvZuKDFkKZYyCwgyDr8MmI51nJ8c3YUPcukJAXUKdBGsD85MVDxnG2xOlwnJM5Z07aCpHSktdytuoVV2laUNceFBZmMAAb9ABV0/RXhVe+xIzELEdiaB+Uv3LenWI+p/lXXBsfdwtwPa0cHXSQY5R0P8quyLYqK4WprM3PA8BWw1y5hhDuDCsSVk/iNaEnxI9lLi41VtRMGQcx6KBqxO+gPvMiq5/wC1jEFWVbFkOPvksR/4dPzrPOMcTv4m7nvXGuOTA7dlUaAdgKXGInmON1AHEOeFbVzFY4XfUC90uCCJBHrgHkVXbTlWx+K8aiC3aYZgvqZev3R8iSTHVKxnw1g71otcQtbvWmBXaAWAhiIMiJHfQdatuFJe0xu3blzEG9mWSToQNZ2UA5oUcyO9WZBttFsS3kDtwJNxnh/NNyzcUgHVSR6SdQO1PeEeL2lDWWKwhKEGI02mdIyx+NCTi7Vs22VlZGDJcSZa2JCye0gMJ3ihn6ncs3rlslEOjIGBEgyZBB0G8EED+Kz4DpIP9qONlDEV/bmm8Qw1tpZW8m4VID72zJmWWQG15mNyAxmqd4mwzqIuCR+0gJX5jdJ7yO9COG8QxV1Qli4A5mVOXX1Zd2iXHckarOpE+YoYuyxW7iGUruDbOUzGikgBtDJjTeNKrTHkQWzCv1hLudKg3+n7SXhMTbzpmWUbcn4dEhVJ5Lm1ManbeKvfB7SpYa7ZUOWQeidjzM+x/Csu4bxVbLobgGRjKlFIGhgwp5e0x+FXu7xV3cOroLUKVaSAAIzljtETA3JMexk3Lr2+Zn/i3CEYhioVDAzBBAk7+/fvNaF4F4kmLt2bIVLT4cjMAuggmCnTNz16786j4/4rbvYjNbMgW1Wdp1Y6fWp36KVbz7rLEZFLSYgkkD3kB6ZUnRUQyAa7lz8VeBMPiMR5tx7gZiMwUgBlUAEbEgxpIqi+JnIvG3NspaGS2lv4La/sAH73U6knc8hff0hcYa3YQ2mAdyULfeAiSU/LNy0jqMozVeGJUCFgx7lp3pSpmlXRmALe9PXRKkdaYSpKmtFhYqYkXCMUqRmAgmCPyNGsFx3ybwdCQomVHNTyoBdwgYzsetdW+GR6ixMctqzm6c2Yyuaoe4r4l855MhR8CDUk7THtOveo1rA3XZS4Kox5ATGgGnzHX2or+jbhVp8T9sAcw9M7da0Pxd4bW5ZYIcropKnloJg9jtPc0scmn0rxG1XULbeZxxTwrYUSBdZzqxJnKNCDpuCCIjXtoaiW+Bix6xkugiYIOo7VaLOOt3MFlZLnmkAFvSQjcgoUkkRJ13ObbaqpjeO5LeQAl8zEabAmJPPXfbc1C6/feG64gLInvEeLo6qLaqMykFRq055IMgBRp30jnpQy7ZklnIDbkj+JO/8AW1R8DhCvrufEdh07nvUv9VLn1aL06+9aiYxp3EwsmQ6tjIS2x90zmHWecQY2qwrhcNh8P5qNN0wJb4gTuFHIf1NCb1y1b0UZm6DWmbitcg3DAEkKO8SSfkPpQHCO0MZm7wxgOKHzEuSoAlXLNAZIkyYieY5yCOdWXjDeRacg+sgqnuRofYb1nt26CCo2IjTkNtKsPEOJ+e4YytsQFG5VdAWPVjv9BUHCCwriXYsxKm+ZxhrbPCIuZjyH4+wq4cQ4Y2Jw9lX9N62MuYqcsNplY8tRIMGNRzprw7x7htklFW9bJAm9d9ReCfTltyEHtvVu8Pcbs3M5RiASQAREjeRPXeOXalupdgwIFVHenVNBBN3BvBfDSWTLMWufenQSIJhdokTz2HQUf41dw/kE3nRIkAN6p02yT9oO2+hgjeo3GuI2bQlmAI2A1P06d6zfxNxJ790OFGVUZUneW3JjltprqAe1L42u7lzgCvqOOahvxHwrDXsGt1SLNtQGWFJhmUGMqkkhpGsk7VmYwtwQfKuMNxGo+oq++H7Avrfs3bikMoIU+mHkMCAIAGbmOfvU18Myi2pUq4JzkAkEKp1Ec2GnznlJJauDkRtj7yk4HhmIxLoEtEd20WPf+Umtm8KeGVwtjJbabrHNccjQmIiJkADQQe/PUFbxqpBJ5jKpACmNI31/H5Vb+E8RUgHZTt0B5gHp9KIsOJX5TjciVb9KGVbFmVAuF2iNsoUZteepXpWZtdrQP0t8QVrtm0rTktlzG3raB+CfjWatcq5eIzhHpkjzRSqLmpVMtqD1NOI1NV1WlPPyVbuU81zSoSmng1CRYkgwt4f4i1q4rhScpkHTTnBH4VtGN4rbvYfNmCq9veRpI51gMxyopw3hz3B6B6SYliYnpzk1l5cAvdqEfxZydgtmXDCi1YdRfIt25mAfU0rGbKASqjeTzB+cLxP4V8gHEWmNy03qzaEidjpoV215VO4X4OzQ952c7wOY29U6t+FaJhcJb8oW4lYgDl7dqqGUI4Kb+/tLnxF0IybDt7/rPni/ZvfFkYj90j6GpFm2jj1BgeYzN+U1pWJ8GIt8ujlBMhVUCQYJDHWdZ+IUG4tgcJZvsrWbtxidAhPsdAyxtPz5U/hza+0ys2DR3lRSwF+BAPb+dQr6QfW0dhrV8wZtXCFXBFZU5GfRWLABBmKkSxMDuV6zUPDW76AgcNRiZgvkzAtJ19M6chpAirtcpGImU9FgTkj3rprlWnE3rrkA8PQfZn4Xt6+ayrbuTlImUYLz9RiBuzi8RbcXUHDXW4FI+zAY22e2TbYhFHTN8jRKZaFqVnNVg8OeJjYHlXBnskzoBmUnSVnQiNwa9unh8faYfEWDoTIeInYFmaJGxI+XWNgeG4W5cYLiVChhkLkDOMoJDElMpLEieXTSocK4phCVipsS2fr2FvKItXwCDF3KMkjUgkSRz5VNw/h9bKtdZ86hZURp/m7e0TBq12uH2vLUW1UW8oCgbRGgFQb+DZJAnLEBeQ20HQb/AIaVmvhI/LHkyi/VAVrg9lWDqYYn4vxgCjPDMHbLNkJF8GR5mkGZgDYTtz3nlUjhmDFxGtWspIaUYEQpjNBO8a5TExParVgOGhwly7bAuACJjMpjUSP9xSyoSY6+ZVEzjCYZvPAynKIVQBJENDTOzROv/rVjxlvVbdlwsEs9vnrvB23EfM1N4ngzbutcUGD6ttjqD9Yn50P4eiG8LknsOhIAiOQjl1M0JJBow9YYahG+N+Flv2/XGeNLgGs//wA9ulYtjbJS46MIZWKn3Bg19KXCoWSYAEknSO/tXzv4ixQv4q89sSr3DkgfF90EAb5t/nTWEncQUMFxSqzf9hcT965hUPNWvKGU81YcmGxpVfI8xfeVCva8r2tGYU9muwak8N4ZdvtltoT1bZR7n+G/ajn6jYwrhWJxN/KT5dsE5WEODEGVAzSCCdFOUCRQ6hOqDOHcExF+Gt22yftkELp+zzc8oUE1ZOF2rdi29vEXrrAXGAtWn9BggC4rLqARyzLqNR17xNu49oPisSlix9yzbeS4gCC4BzmBuMwOp0nUfw3jKWrTWbNsPMr5jKfWpnSN5gxvymNTSr49RuMYSL3P8S/4R2UkWLAGHiTdeUM5ZPpy5tBOrRJMSaKYBi5JF3MFMkqwgaAmem/XlWbrgsXic/nXblq1kctmLBfRaF/KyKMxlWV9FJgkgNEUT47wmOHWb9pmCnKLqqSLZPqtGVOoKugEMPv6bGln6UlhvGR1KgH/AFUL8S8fYdWIt5rpWfUAcrHb0k/F76DpVTxni/FOTpaRSdoJkH7rSSGHyq12/D2GALWUz57LshyG+wJSzftBbblVuObLXBoY0GsyA5Yxli3btDPbtXf1ZkceYmHdHNtAFDBZE3bL5mMlWccnFNY0VBsIozsxsym8P4vjEtC0gl3yraueWWdVVYC2gBDNt6oLDXmZrjjOKxl8C99vbQ5UYoHFtro9JI2Csx+71nrVoHiaxbt4XNfzNYAOVM7EMmGxNn0sUyepmswZ6kwBNeXfFeBICBnCfrIxB9BMr563zZM7DMSZH7EbNVve9MCUdlxi3Lk3r4uW1BuBycyqraZgzToX0H94nmaV0460BcNxlF4L6sqevKvozQCSQrCM2sHpRfiPGbF+9fuG46efhrasWGci4otB5yhc0+XOYAAk7Cm8fxKxcfDhbno81WukqRkAtYe1zEEgW2OkjUb0s+Zw+nTtvZo/HeGqKRzIFzjOPAFtwHCODDWyPVadXynKF2IWR35TNc43xH5qMl3CW8xQgXFAZlOUqrDMCYGhjMNQDOkVYrXFTetm42Jy3RbuQAUVoa6NtU9RW2GJBJ9Wg1incJwY2zkK2rxVizZxMh3ChyYPpyWnIPLNOpiqPxwUHzFog8C5d+GB4YGWjwJxC3dwqeUlxFtk2wH6LGxk5hrE8iCOVecZ420i3hxbuwcrerc5WLIkSAwVZJbTUaHWKNxPA+UtkWkuWb91gABcPqDidgZGUsqfJtzTGN4G1klrd9cqgEOx8oklrgVUkmWItlh6tQVPOKMZ8bUbq7q/r8SVTSabt+st+D48MNp5b4eJOUrKMQNQpURsABGXf63S34pUWDeIZ9JCWhnLafCuwYzz0GlYxb47dCoLq+ZbzBhmBGbITpmA9YBmQZopg+IYZz9jcfC3GIESDbbbVgYTTcQV22mKJsYlukNuP+yT4l8f38Q/2BfD21EZQRmY8yxA0jYAbfkAw3HMRbIZLrSOuv1miuOw6DzP1i2WY5n8200rOYwCSs2wQVUZgVgAjnQziPh69bVXSLyNENa9Uz2EnXlE6ETB0EaVriMIVAqXB8U/EsMyJeKMPiSYE9HjVkPX8NIqtWrQwPQ4thJO4wysNlOxvkfe2Uba05YYYDbK+LYQ+spYWQTb0MPdMDNyXYayasGJs2uI2cyQt9Bt0P7LdVPI8vqKIKKoSBsbP5T/AH7Shef/AFNKvHtEEiNq8ro5AYr2i/ijBot1b1kfYYlfOtf3ZMPaPKbdyVjoF60GmtAcXPNEQpwTHMreUbz2bVw/aMoBIEH4ZIyk6LmkciZAoy3iFLKm3gbYQGM15xJJBzEgMPVrHxCJHwiq1aw/Nvp/OpVDoBMmKxaGZSVNwyBlmJGgCD9kRoOlavwa29tbmHt//D3rrWlBIDlHN1HSTmulL1q5hmyyxW4JEVlA10GtFOIY29iSGxF03CogSAABMnYCSTqTuTvNQ63tCVSZbMV4ww9l0OHzXcmQoIa2FFt7iKmozZv1a41ksJEqhEwar+I49fa01lBksMSSjMXYyy3CWdpZjnUtOhl35GKgooGwgV3NcEAlgT3jF57jAK9x2AAAUkkAAQAAZAAGntSGHXp+Jp0mvJooWkRryVHIV7IHKvHBNeGa4SY5nFI2weQ+lNV2zcqmTOnUdNP6H5UktBZCsyhgQ0E+oHSG5sO3akj612RNB5YO0t843uL+sdXH3lu27xYXDbJKh55yTqNTqSRroa74pxkXMP5ZtZGDhgdSiqEFtQpzSsIoEEGfUdCajkGIrkVWekxkg1RHFSpt7+ZYMck238hmv2lt27FpVhk8x8ym6QCQrQW1YKQ1xRyFCW4PZe7dRLyp5KwSfVnZEY3XIn0WwVIzajVdyai2khsyEo41DIYO4PLuAflRC3xq75Zs3FDWy2Zygys2uYqyghWBbKCRBygjnSTdLmxXoN/v9eP7cm97kWxisVgmhkjOB6WhpAJGX0klSCSCoOhOoq54C/atFlVrNnFPDOs/ZW9ZKSCqm7GhZdVBI1KzWeY3HPdIL5RlGVVVQqqJJyqo21JPXXWmUuEbbdP62plcL6QWq/jiEudSab7/APZPxN3O7MYJZixIECSZJ7DWvbF1lMqxXkSpI06GNxTa3A38tKSr2quprAgjbiex7f186Vcf1tSroUdserhV7Nr5WKt+X/d8y2fMA7NlBI2kTvQXBrz70qVPDkzzZkmkeQpUqIyV5kxedd2tqVKhl8croV5SroQnhrx9jSpV0iNTTlKlUzo2m4rw70qVdOnrVIFKlUzp0KQpUq6dPcu9OJSpVMKROI2xGaNY3obSpVB5lGTmeq0Gam29/lSpUtn5E0vD/wApipUqVUx+f//Z",
            },
            {
                id: 18,
                title: "Svart krabba",
                genre_ids: [28, 53],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBgVFRUZGRgaGhsaGxobGx0cGx8aGx0aGhshGh0fIS0kHR0qHxoYJTclKi4xNDQ0GiM6PzoyPi0zNDEBCwsLEA8QGhISHzEqIyExMzMzMzMzMzMzMzExMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMxMTMxMzMzMzMzMf/AABEIAREAuAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAECBwj/xABDEAACAQIEAwYDBgQGAAQHAAABAhEAAwQSITEFQVEGEyJhcYEykbFCocHR4fAUI1LxBxUzYnKCFiRjwiU1U3SSsrP/xAAZAQADAQEBAAAAAAAAAAAAAAABAgMABAX/xAAgEQACAwADAQEAAwAAAAAAAAAAAQIRIQMSMUFRBBMy/9oADAMBAAIRAxEAPwCu4AhGLndVOUf7qFW3JE8zqaOGG8qw2a7KOAixOEULO0c6HV2yxNM7eGkjvASn06GsTCCPSdetGgWKQtdtijbE0ysYTMwEb0Vj+zrMn8sEkkaesUrwK1lNu4tmbU/2q69nOz1q7YFy5aliSBmJ25EA6RSxez62i2eGYRpyBjX1P3VbuzOKHdupIEFT5DQg76dKlJui8UrFb8OS1cAVAqzsNKF7WYdcocEdTv8AWj+0/GLIJAuKWGwEH5x8o8qq2K42123DCVgxlI385FBWzSpYRMuZdBP66GgG4Y8mSo9TP0FR/wAeygRMH1H3zXD4xjyn1NNYqTCU4SOd5B7E/jU/+Tpp/wCYtk+YI/GlZxTdFHzP41wcU/8AVHoAK1hplow2Ht2yHa4hVdYVkP1eh7PEw15TJZQ05j15UgS8Zklm5EE6EcwfKprTKpkTHQ9Ola7BVHo/afh4u2hdQeIQT8vxH0FUlUmr32V4mtyz3ZPiUQRzKnn9Peq1xPBd3ddeUyp/2naKMfwWa+oS3LcVJhsVctzkaARBB1BnyNSvbqNrdNQLA3FcBKLKVvJS0HsBulZRBSaytQexesThwX0251o4SmDqFkHQ8p5+Q86rmP45BKjw+v5cqdMm4jgoI+HWh7eEJkGaqZ4vcZtbhHvFGntFeRQc6vHJgCfzrdg9GWD+DZTIPzFWDDOFTM2wG/KPOqCnbO4PjtIR1BKn8qSY3i9x2MO4UmSuYxSSdoeEXFly45xi0jH7XkDr9Iql4vHtcJgZR5bx5xUb3gVgc6hFChjVazkaA6dPWpIrkisYxD7jpXDDpUgFcsRWMQ1kVISK1pWGOBUiGuggjcVIlsRM+1agMY8GxZt3FI/YO/tVm4wNEcGdSB6ET9aquCt6wTodqsGIctlXkvPqTH4ACmitslJ4APB1iD91RslHphiTpRlvhRI05b04oj7qu0tTT9eEiPwNDHAkGeVYwlv2o2rKZYlBzFZWo1jXtPiv5ypsQCQT12FUrjK3ZLMrRuXGo9Zp12t4jbfFlrbB1CgHKec6+9ZZvhgIblz09jSrVRTx2VJLebnXXdEc9KdcW4Y1ohlAZG1DKNAenlSbPrrrr6GptUUTskt4cH7Y+ldYjAMgDBgynmARr01G9T4ewfskHcjqPWjMX3mZbbP0kaEDSY8v0pTCi2j7AawDHOOo60ThsHcufCAY3EgH5GjsS5MIoDOo0OzDmFkfF1oVDmM3AobrqJPKY3NNZqIDZO2316V1asLGpbfYZRqN95o5reUSuXcfEY2M+HWZ/ZqfhWH7xgGAy5us6n+24oNhUbdEGB4Slx1WSJmeYHMSYHptTxeyVuNXBPp9SDpVk4RgVUyAI9P35U1xPDgJKb/38+sVJzOmPEktKbb7IyJVFP8A2Gu+2kj9ajODtYcxfwiOv9UyJ8yPh567UcmKuXb3cW0uM3RXt29ftQbjAHnpqfWgeOXu6uHDu95LgIzo7JctlW5Zk2IHXrrR1+gfVeD/AAHAOF4lJt28rAarMMPPfUedKONdgSoLWLkga5H/AAPWg+AYK6t4d3sDBMxHXb0r0DiHEbdkRcMnoNyY1j86RyadIKjFrUeN4FD3mRhBmCPOrlbwpgabgUswPZy7icW9wKyWpzFz0OwA5kwfQe1X8YNdNtOVdUZ0jinC5YILWFK8qYpaAFMreHDSM3t+963cwo5ffSudmUBU9sEUBikVF1NNsSmUTHKqrxC4WbU08NElgvxNySelZQ9163TiiK0g+dEWHa2SGHhOx86Ew98AjqORp9ae1eTu2JR2Phc/B6Hp61OOlZDPBcRU2mtudD128qqOPEXGI6/MdaYIhtkozAwYDDY1Di0zaHfrTS1AjjIkvQpcaEae5/tW8E5Z1nrv68yetDI+VlB2Mz9K6vaEQSKiUCrTZLmu2Yz0Ouw9qJ4rfW44geEDRhrKyN/OlEFicx0A/ce9G4ZyANNPTc8zTDHV6yDcEHY++m33VaeD21Cg6bk6deWnoTSTAIHeSKsFi1Agcjr760knhTjj9LDgr+oH7inmHcNoNdPI1U7XhjU6EH+1NrNy4DmtkaRvov3a9NeoqDOxKxrjuEWrgJhcxA8UAGR6c51nzqqXezEYg3LjZ5kmTmJGUIJJ10EczsNudxs3GYSRBjblXd20o1MSee/3/dHrRUmhHHdK72fwa2rpAJ12Pvz+dIOJYV7+PZWtOwV1GcEMiqwJAcGMp5yCd6tWEsfzJEDfQj9fKp7GDS29wje5cLtrpIAUR7D76MHonKmlhAg7tQiiFAgAaaChMQ8a85pjiU9q5w9hWMN86umcTQDgrxYzBI+/2plcuc6jewqNvAPtUd+3Goaaz0ytIGxt6R0FVfHMNo96d8SOk1X8Q4NVgsIzegIQEwN+XnWVk1lMArnEcAUMnbqKHs4oqRzHI86d8XBPiyFNdRy9ulKsXgivjGx1ipNV4WjK1oacULi/fNaL6QaUo5UytMMNdVhtPUbH2op2brRBiEkzzFTvAQMCCxGo6EfSRrXOJXXSffehkQwxmCsGOqnSR6GPnSNDo7t3YDAiC3PlRqMFCb6b/v8Ae1BIS7AEdPKp78xr12HlQCO+Fb9PPpVkwtrTwySd5Mk1TeF4kf3q58MucppJnRxMJCafWj+HOVPM9fL864yTUmGQiBrr7fKpF0O7dwBRH6D0pXxnH5YV7gRIzMWMCBoNetM8OoG8URiMJadSbiqwAnUBuXIHSaDCLez12xclrV1HA6GT7+1G4kgO3PWfeBP0qv4Tgdu3cdlBRy3iZDlEbgRsd6aM0c6rCO2jm5prwy64NDhyp3rm9cigHxXKrJHG5DK5dB3qK45oC1iZ21opcUNiRWao3awXGKedV/FWoJ6Vabqd5pIigr3AW5HSnjJVoji28Ko6xWVZrnZwxodfurVHsgU/wq3E7qlCJk8qGS53lgKRqBHp+lc33BBpdhcc1tmA56is3oUrQBdtwTWrTFTIP60dduLcY6RO/r5VA+HK+etTorYSHzCedR2rYIJI5fTePaK5uKVYZdeoqezdhtBlBnMp1BnyO3tWZkbtYUnUEEjaOdE3LfXf50Km8HSOYpjhsNoBoeY9KFDWLxbKNIqx8FxuwI1oXE4eB7Ute5kMjlQasaMnFnouHuSNNfzopXaRJgc9darnZ7iYYCTrVts4UON/yqElR1xkmhJxNsVbabV8FDEB7amD0ld/U0La4/ilIF0cxBVlgknQZSBOvKn+Lwj2wzd5AAnyqiYriRu3UyQArDLA3M7ny/M9aeFMXkl18Z6NmIAzGWMknqx1NDOTvU3DcS1y0DcADjQwIBPUfWtvbnYTVUcc7vRfjHgedKnZpmnf8EzHxaDpzpnhMFbB21pu6iT6ORUULyYUz5CPSjsNhnYAsI/fOrNibdvkBNQaDQD9+lDvYelAmHshTrTAptOx860qgAZo06aUBdxagml9GxBOIuACsqv4jiBJ01rKfoI5nnxcREwRyND/AOUXrid7bSUm4M0qBmtKLjjU/FlMgc4MVFnLOSSZq0cGtYo4G49p7XdgYsFHD528Ft3YMFyBlUSskTLDnQm8KccdEo7MYsXMuRAYme8t5c2fu8haY7zP4MvX513h+z+LZgDa3Sy48SDw33yW+e5eQRuMrTtVkw9zGPdwxKYdRike8obvCqulz+JLPEsHzlXyiRDgbV078RtC4zd09uwmFcKA3iANp1dUIDhv5as6tGXOxgTSKTHcUUS7EaVBbnf61Zv/AAjdN0We9s5wjs6qXZkKKrlWRULFiHEZQRuKr+NtG1ce2WDlGKFgGAJGhgMAw1kQQDpTWLVE9q/liRHpTPAYu3JUtkG6kiRPMEjYEc6rwM0ZhEzNprAmihWWDFYpYGo+dJcc5YkKJ6mpMQNuREiOXh66TMmoe/Ou3uJo0azjDXntmVMHpVk4d2suW4zz7a1WrrzyUegiu8Kc/hA/ER+FK4oeM2vC2cW7UtdssqgidCx005gD8aS8LUHM0iQNPWQPxod1hlAHhj2nWRTHAYpntspKjKJXQAyOUgVlGhZTbds9T4Tg1FvQ5vwgbetFG0R5Uh7HYvPZcj/6hMTMSB+M0/aSutBqmFO1YHfcDbXzoJ8bGg3ovEWm5bUGLDseQ+tFUIyE41pphYckSagfAKokkmtd5l2rOvhtXpPfYEb0vfDA6n7qJ78Vz34POisM6YL3AA6DpFZUWMvEaQfaspqYlo8rZgD0nSKYYXjt21YfDhQbbi6GU54bvQgkgMBmUopUwY1HM0uyBm3gaammfD7GHKuLxcOHtwFBy92GU3JYcypMHWMvnSPSqwIftvicwYLaGRs1sKgXJ/KayQGEM0qUMsSZtr6UHge1l+3bNo5HV+970uuZ7nep3Zz3D41IXQFWHnNMG/ytSgC3mB7zPnLhxMd3GU5THiBj1oe2vCs5Z++VCSBbGcsoDXMpzagypsyJMAPzIpSidnVvtVcNzvDZs52R1uMBcV7mdUQlnD5hARYVCoBLGJNI+IOGuNcChQ7FsoLMBOp8TEsddZJJ1pxh24cVQN3iOEtlm/mFWeSbgAEkCBAMDedaF4quHeDhu8CZdRcIL58znUjT4Cm2nvNMhZWLLa6imFhQDoPPXpS+3prU1m9APU0UI9CsVezNPOADuQNADEzpUIkVCHrtrtGwUcXTyp3wvAjKWnWRp1nf2FLcBh851E1acGiW1zH9+/pTRjeiSlWAvEsMq21P2iwA67iob1oKcir/AMieZPWmOJS5eIud3kUfCTIB9AadYThNv4rnjYmeij86aXtix8O+wzsC4ghIHLTMPPnVwNwUjs4lVGVQAByA0pmmKXLqQNNudSkrZWDpUSs9DtM1H/FRrQWLxRB3++KCiwuSGJuCP2aVY25G4+VQPxCKHu4776ZRoSUrNPeNZauGdRH0+dCXMYfT26UMcUetUomPHxagelZSBr0msodTWUK22pHnV+7McOwrYC5isQrHJcdWZWYsEQIAFQMATLnc7V5+NzNen9i8Rbt8Hv3LtvvLSXrhdNPEP5IjxaHWDr0qT8OlIVYrheBxdm42CW+HtnxG5MaqzKrISQA2VyGB0y6761bhNlbl+yrIbis6yklSwIJgNy9a9G4ZxTC4vB4qzg0OEfIMxCJlbMGjVdNQpWdwDpzqh9kNcZhOnfW+cHUHnSr6M0R9reHJYxT27fwZUaJJALqCQCdxSuzdI9KfduGnGPMCFRemqqBI9dKrgpkB6WzsH2fTF3n70E2raS0SJZzCAEc9GPtS7tRwk4XFPaghZD25MnI8lAT1EFT/AMau3Zzg15eEXFsIxv4oZjJCgWnhFIPOEDHfd4qD/EvCXHw+GxFxMt1FW3eWQYLgkHT7OZDryzgUt6FrCu9i+z38bfKsxW3bAZyNCcxIVQdlmDLcgNNdrHguF8GxrNYw5u27gUlXcsFaNCy5iQw2JBAMajag/wDC/MWxKIJLINNZgB422k6Dziqdwnh93EEWrNs3XKzlWD4REkyYEGOe9b1m+DJbZtXRaYCRcW2wHPxhGgjkRPzq5cc7Pj/MbeHsW5Q287Z2ZlQBnUvJ6AKAOZqhWcO9u+tt1Kul1FZTHhZbiAjTTQ6aGvb+I8TtWsWltlHeXtCw2CKzd2GbfViwAG2p6Uzk7VE+qrSu8Yt2beSzaBYofGxYnVRMRtOknpsKFe8TsYBrvH8ONi4UklZm2x1JQ7TP2hsesedRhTVl4QfpA2KjmaiPEDOs+lEm36VpcEJHPnWNplnFswhQfnUbsZ8W/wA6OweHAmV3qe5hwTt/ahaQaE7LvFaZGI2pt/B/IVx/BVrBTEz226adaHa0elWL+CNQvw1iPKjaNTK84IrKYYjCMOR+VZRMecJ1q6dku0ly3bbCW8J/E57jOU3BBC7oVIgZdzptVVxFwZdNelX7sNeOG4VjcXby96CyqxAJGVUCxO4BctB0kVCR1R0H7Q8WxlmwQMC2FVyQXWMoLDKYCALmIkZm12iqp2cdxibBt2jccOCtsGCxUMYB5aa+1PsB25vpbu2sSpxSXARDuFIkENqFOYGQYOxXTeln+H//AMywo/8AU5/8HpfA4y523xmYM/Bjc0ysWFt2ZNwCSCZGwO8EjpVC7SYxLuJd+4WyJVWtKMuXIoVhEDKTB5c69M4nZ4v/AB+bDsww2dIzNb7rIAueVJzEfFsJ6VUf8Ve6/jYtxnFtRcjU5szZc3+/KVmdYismZg/Hu1t7FNaWwHw6oMipbuMGZmKquqkToqqB61Nd49iMPhb+Bx1i47XQWVrj+JZiCCc2aHTMNd5rj/DPhf8AEY1CwlLI70ztmBypP/cz/wBKd/4h5MbgrOOs6rbuPaY/+mzlVJ/7Kv8A+YrZZlZTOzHF7+GxCPh/E7kJ3Z2fMwCqdd80QeR969HuY/HjO9nhBtXLgOZ/AfEftECC55+I7615t2bT/wA5hf8A7mx//RK9Z7Q4DiZxGbB3slgIgALiAyznLKVJYbesVn6C8PJThrlu9/MRldHVmVxDZgwbWevXzr0HFcQ/jrgum1kLILYAYt9pjvAj4qH/AMR3t3MXbVT/ADEQi6Yj4irIPPw5iP8AmKO7JW1K50YMQcrrzTTQ+Y5e5qkfLIzbuh9iVNxEV1l1j+ZOp0gyI5wPfWhxw4U4t2uoo02QAPPlS9qH6WVv/L62uCinN50Ub9eROoMEetZh7tsEMzALynmYzajoBJodmDqhamAbXwkxvA1HrXZwDCJUidtN6dW7qCWQhZPqDryPUztWr+JEFcxQnSVI02giZAJrdmxuqEj4eAIg6TpI1mB9wPzrQs+VT4rFqohnzk6qwfI2kxA5rrz61lniK5SrKZP2gCPTb9KOi5ZH3PlUoTT4aj4ZiEW3Fy4WaSZffLpGwEjf50yLpGmu3lM6c6DtDLRNewo6VlPbuHHSso9jdD5oV69H/wAP79rEYLFcOZwly4WZCeedUEgc4ZFkDWDXm1M+H8FuXUFxSqoGILEmVyZSTAEnRpEdKVjIubdjbWEtXLnErgzADu0tOwDasDqVBZicoygaAz6V7sAP/ieE87n/ALW50NxDg91LbXLlwNkVSQWZ2BdioGuwOU67GD0qX/wzeF1UDqDOjAvpBAMQJmSRHOKwfGXq12qe1xm5auO/cuy2sjk5UchcjKuyjNoY3D1T+3XADg8U6gRbcm5b8lY+JCeqMSPTKedBX+z95Bncq3hZhlZnZsgQsBpJKhlkchE6URe7PXyJa4rf6e7OYNwxEkQDMetZIDLj2NFvA8KuYvEB8uIfLCR3htn+WgWWWJJdpnaDRnZbFcOxdq/gMJbvW1e27lbsEa5VzIc7wVbI0abT1rz0dnL7ZVa4AmZVBJfKCcoEIRMS8AqORrLXBnBULcUErbJILgqt2MrHKJC6oCerAcxWoNmcDssuNw1thDpirSsB1W6ob6GvU+O8Dxt2/wB7Zv8AdpkRQO8dSHXNmbIoynceZivIbLd2zSZIYjNrrlO8nXcT1otcazGSzBR/uOv306X0nJ/C4/4mY9Dcs21cG6iN3hEHLmK5Q0czDNl5ZuU0g7JYp7d9J+FjDQeR6/OobPCu/m5bGp1KflzmmPCsLluWwN8yz8x+4p4xolKR6+qbeHpz/ShbmOTMyMhlTvMj7tqMa+Z351GthTuB196iX98FeI4imdLcTnbU5vhjaQ0fWo+JPbtg3GmdpU666bHSYoHjWCH8WgbRHKiROgJiB5zp71x2lEAeZ0HQ8/OnSWE3L0l4dxRblx7dsMFAzZp0Mb6H10phicseIwPff09qQ9m+Hubgcg5YL+WUgopB82n5Gm/FcLCltdAZ15Gs0uxot9bBMGi3lctoqXMsydfDIJkab7Vux3ZcW7dxWYqdgSIUfaYbGOu9RcF4eDYu3C+8wuoANvWWM6kzHkKG4Ng7j4i53TZCUZpKkDJcgpA23yx89YpqW6L+Z6G3EQEWxcAdjpEzIGxMQP0qR7bZlmYAhpMkiI0PX9aXcLBF5GYiA4LSwB1OU776mT5Va79oQIUctaEsdBhtgmGvMVhtOQhpgcpn8zWVyMOBJjfff6TWUlFLZ88MD6inHCruGFsl7lxLoNwoVZgAwSUkDbM4AkHQwToKUhehn98xRVnBM6lpAgxHyj60smkrZbjhKcusVbHGEGEZUzM65kQOqs5VmA8WeWkAHaJG+29awuIsEHvLjEl3kNcu5cgEJtMrlLayTMDYmg7eFiVDahsnwkHYn15HT0oRsJqdfs5pg7Zsuo5daXuv0q/43L9Q3xNyx3dzJddiT4PG+bKVt6MsZTJD5p2ypFLVvMSM1xjpAJdpjpM6cvlUFzDFbnd5gT15TEx++tNOCdnMTi7bXbCq4W4lsgtDAvrmiIyCZYzoJMQCadNEJwknTXgvud4JbO5jc5mJBEROvksHyHSstXnI1uPAjTO0eH4eew5dKsuH7I4rOuiT3r2fjbdA5LGEJ7om26Bo1ZSIrl+zTNcNrNbRxa79TnOR0y5xlUqGzZcxykAjKZplRN2itluuutEF58Pz6eVMOK8IvYJkF4IVuK2gzkELlmc6qZGZSGWQYMHQ1zh7ltFNrEWwJGa3eXRlnaTtctnoRoelFAlhLwbENbcMCRBq74IW79xLoBDq4mIhgd59Dr86pVu33YDwWSNSomNcpDDcQeY0IIPOr12TwkJ3mRlDGVmQWEAAwdh8W9V+En6W5nII6+VTo3U0Dn6aTHy/KpGYjeai0UTOMeAzWydcpLfKD+H3ULc4e1z+axVmVSUtgaZmEDOTvEgx5VFxXiluyAzxGs+ld8D4zaxdsmyWlIDIRlaSNCObDzFGmgWmddnbcWyDmBkgSZAUMSF8jJJj8qP4hbJtuBr4CNuo1jz3pfw+4ASBmnnqZ060VimGRpP2TvNBrTJ4DJbDWTbWUNy5/MgQVtkgHfmUUCR1NT2LgW9eIUoAqKjR4MiKeY2325xXODANskciefTWhzdl3HiggDn0o1dguqOOFIA9tmZZe27xyJe4GQAf1KAT7mnJNIcAFbJK+JQQZndTo09d6b955ffr+daS00ZYdlPOsoC/i4MQfWP1rdbozf2I8Da6DrzrdvGsqlV2Jk6en5CneI4QoPwgg7FfCfupZjuFlBmQFk58yvqBrHtQlxutL8XM4u4umQ2cWzPuFkyYA3gj6E03eyAg20WNhtOaPnVdFF23uMsAyOhNCMY/UNLm5LtSZq7iGL5jE7bb8pNGYXjV23b7tWKoXDwAPiCFN42KMQRzmlhJBgj860DWSQJTlJ22WjD9sMdJIvQD9kKoAOZmLARo0uxnzreH4rdFzvnbNc7vuwSNWHdm1mc/aOQwSdTA6UpwHD2uHR0UATq3LrA1rjH3SrZJVo3ZSTPoTqPSikkTbbwacaxt3FOudgVSQvhVZL5c7Nl3Ziq6+QoLFYC4sZ9U5MDKid/SuuH8ba3mUIjI/wASuAV0BAM8jrvTfhHHrakZrYgjKw1ytynqjeY89KZJCSckJcLfa38BkcxqFg6ERuJHpV04L2xJIW/LTl1JhgB4WhtnBEHUAyDvNLMTw6xdlrTZGMkKYyn0I06dPSgl4W9uO8SJBIaA1s+Zjlr+lNQvZM9XTFrcl0MiSIGkZdIg7DbXoQedZcxgiToPM15nZbEYUo2rJoUbNmUr8JFtwYylSRlO2mikU5xfHjftvbTS5lyoDGdjrqQN5EeJeYM8q1IFg/bPHi54QZC76SJ5eIGIAnT0qXszh+5UOXIdgXKCA2QqVtkEnU5jmI3gxuCKqdjHPbAQjwBpykT4h9/qKlxnE+8JYkg5WUxozFtNdYCBfCByltySaDYUj1OxxVGKC5q58OcDLckATmU6jcaGd9DRd9Dlkaqw0OwI/OvMLnFZKXMzu7SW7x4AObMyoJJyiAJ0mdNqsnBeOPe8S5RlXIbYZT4VLOWdDqRLsuYf0a1jaOrTMoI09P7V2unT51FYezcIIuojGCEYmDO0N0Pn1qRSSxUHxg5SpBENE+m2s7RVMJ6RJo0y3Py6UcLmmh185NQYlXQ5WUT5CsS7AIA3EVmrApUZibnmPv8AxNZUV2PKd4/XrWURSpYjB/y10hgYPX28qj4nbCWVZCweMwBHQ7qw8xsaXLj3bSfToKZYtLyW17zK2ZdCCZSdg0ajeZHWsUA3VbqqzhSSNStsa/8AIAnxewpBdsi3cZQQQDymNfXWr7/GW3tRcUF1UeIZDPSQQNfkdaoeJuA3H5ajmV/Ex86RjxCrnC1uWjdQkuhAZApHhPPNOuummvtQZ4ewPhJHSQD84prgswg5XnXxKyuPRlJkj0rb4sMDJHoc30jSj0TN3kiv4p7itkZhK6jLET1BFQBpPi9zzpjxKCA0rPQDlQISRJ261KSplVKyS46mFVYHIn4j61w9plMEQa6VGQ82XnH70o7GcPdES7mVkufCcwzjydATl9p9qxgexiGXmQfu/vvTF+MO1vuyxykgn0GsT5mPlSpa2o12ny2rJtCuKZabHFe7tlWTNayorMVLIXmfH0/pnfSo14etzNctsqgHMACdOYykkkR1k0HwrF3LcGy7beNPtRzlTIuJ6a67U3sYS3iVd8KndXlEtbX/AEnHOFOqN5CnsRoR4m3yYTGx2ce+zD9zURLMALhBCD4gBnyr9noTGxI96Na+JyXVKN5/CT69f3NcXrGVgd+hB2FZoCdAqNCkqniJIBYhhkI5DKJcf1TG+m1aTEMGVtUZYCugyxyExvp7+tTNicukSPeB1kVbMFYs4jDrZJCuQXgHXN8QZeTDLGnkRFZKzOTXwW8A4iDdU4gjIuUlyNAq7T5kxTCzx3u7rdwwCvA8fi8ImFM6RqZ0qo46w1p2tuZAM+R3gx6Ejy1rMMxYgDXXb8q32mZpVaPVLLP3ak2wmgBEEjXUFTzUjzrYvHnEekVBwsFcOq27ZhRDM4gzMkEFo0GgopbFwpqiqSdHdsvpCgGqLESesge5POKyibvDmKwDNwawG0b5jQ/Wso9kCpfh5ThXDXEAOUyDp18wNxR3FsbdDHOwzkiWUyCNxty0iDrSUW4gkR9P0ofGYglpnX1nb6n1qHbDp62xjcxbb5yZEHUa9QZGo9aW23MsRIM8vxU6EeldWL4nxHlA00PTY1JeykKJGnuPXqKF2MlRmHxShhmVHHSSjgf7WXY/Op1xESfGB6h4HKWA6UGyH1HUeJfluKMxXDmtolwGVcaOjE6+Y3FMmwNIHx1yV+PN7R+hoZLpA0J22G3vO9axN8nQmfOIPvUKmlb0dLAvDYs22zKdevSmVqzauoxH8u6okAa236yp+B4j4dDB0FK7biOVcWb5B0oWBokRiD6aHr0qWziiGBaCBsY2PI+dDC9DzAOux/elTAKRIIGux39uoomaGRh9d+jDefXkabYBipBcXA8zbxFkxdX7OV0PgupIJ5MNdTtVWVyplSR+/vo6zxFhozERIkba7+lG0xKa8LNd7TzbdLlq3f8As94FIXLPxOh8SNHtPSlGREIytCndCZyf9uU9NaDFwhg6HK4+Fhv86x7yOYYZXOuZRoT/ALlnSf6h8qKwD0OxGAKmUZTIDQfPl/eh0VgSFlHMSvIxqI99aks4jJ8Wwjw8ydNM32eZnUaUxs3rV1csa6+H7QjUnTcRrp8qbGJoLhcVb75TireYARlJgECIlj8QGujdRrVpwWFwaEvZtTMwc7nKCM3hDarofrVaTh1xiy2il4RPdMfH0lJ+KNfhM/7aFwGLu23AtMQwIARt1YGYWdtSdI5mRrRTpmcbR6AirpmUj1MfdW2FocnPz0oB+ILcj+Yli7zVw3cudN2XVPWDz0qTEY50AS/bKM2gOYNbfzt3Bo3kDB9afsmyXR1h1cvgGU0PXxz85rKAe2xMg+0ke/OayqdUTtnmT4udNYrkXR+lRIkneB18q00ToNK4LPUpBdq6VMjboQCD86IIXuw0mZjz18xuPIigVbofatkeVMmK0E2205+o3Hr5UzwmMa3bcMA6ETIIBVjsQD576H2pfbw5Kk7Eagbz5dajxtp08LJlPPcEciCOtFOhKTw54hxC5eYNcYEgQIUDT2reGwzXPCiyBqROvmTXXDuHtcMDQDc9KsmD4etsQDPmBrRhxuWsE+RRxCi5wR0GbL3ixqFkOPNQNTHXUeVKSBy2r0JH0+EmOcx9w3qtdo1SQQqh51K8/WN/Wn5ONJWhIcjbpiZbDESBm56ax8qxTrvH751llDMhsvnJHzIprgc7MQ6pcj+r8GFSSsq3QAvyrRFM8bh7XR7Z8/GntswpdcskDMGVh1U/UUWgJ2RhmXYx9KkzA6MYI51FnmNq2vT5D8qwaDFBJ+ISP6jp7Gtq3tH73FcWEjXVSeTbVBdBB108vyoi0MlxUjLcBcCCpU5XQjYqwGpAJ3o25eIK3A/fKDlDsIuJ0Djdh/uM+tIBdPPUUVhW1DqfEDoelFMDjhbeMYO5cUEwG6dREz6bUtwPG8RhwbTDPZOjW7gzLHlO3p9KOw3adGXJftwYAF23vp8Ie3MH1HyoXH2WK5iZRtQy6iDqJ8/KndMmri9GXC8XbuBhbLi2ozZPE7WyTqJ+Lu9yJmDzg1lU66crkhttFuISN/kayh3ZpcSbsTZeg9q5FE2ELGFEn1rWKw7KfENDsRUaOqyJCZox7ca0GR0p9awoe0GG8a+orIEnRNwq81zwhQWykSBJjntqdKI43h0IV1eW0DLmzHpmBOsaDQ7VXrFxkYFSQwOhBgz5HlRlvFMzEuZkkknmTzp1LKJuO2ibhz5XjYGnmFUM0FiPakbrswpniENsqyzDLPn5g/dVON5RLkVuw/GOLQkbedVHHurFXzSxJkD7I5T5mi+L4tiup1pTYtkkAQZ9qXkneD8cKVjLCP3aG4GZXghJUFGkQ2u2xrvBYoIOlBYx4OQZgBupMw3OI5GoUJ5Gpp0UasNxOIa60CtjhVzcD3MAek0VwrBsfHA/CaaGyw3g89NRVYwtaRlPriKm9sqSpEHpU+DdQwzQRrv15R50/v4e26lXU5uTA6jrypHjsL3bQJKkaHc0rg4jxmpYdYnEyfCZEaT+9aEmTqTWm8q2hHMTSWOlRKEBBM6jp+NatMV1Ez1HStJFEYbmAetFGOFvzvRWGvXLYzI0AnUHVW9VOhoHISdBPpWFzseWgHlWTA1YW2VmLKcjGSR9g+oO3OsoYXJ3PKPbpW6INOOG/FRPEvh9qyspfgfonFWTgX+i/v8ASsrKERp+CZ/iPrWWN6ysom+DFf8AT9zVj4z/AKdn/iv/AOq1lZVYEJ/Co8W+L3oW18QrKypS9LR/yTXPtetZY3FZWVjF44P/AKA9T+FbxHwt6D61usrpj4csvRXc5+lLeLbD1/CsrKHJ4Nx+im7yrmsrK5zoO7O9TYT4j6Gt1lFGZ3hPiNR4z4vat1lb4BekBrKysomP/9k=",
            },
            {
                id: 19,
                title: "No Exit",
                genre_ids: [27, 53],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBgVFRUZGRgaHBsaGxsbGx0dGxsdIRsbGxshGhsbIi0kGx0qIRobJTclKi4xNDQ0GyM6PzozPi0zNDEBCwsLEA8QHRISHTMqIyozMzMxMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzNDMzMzMzMzMzM//AABEIAREAuAMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAADAAECBAUGB//EAEsQAAIBAgQDBQUEBgYGCwEAAAECEQADBBIhMQVBUQYiYXGBEzKRobFCwdHwBxRSYnLhI1OCs8LxNENjc5K0FRYkMzWTorLD0tMX/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QALhEAAgIBBAEDAgMJAAAAAAAAAAECEQMSITFBBBMyUSJhUnGBBRQVM0KRocHR/9oADAMBAAIRAxEAPwDyImlFNTyOlIY1SciTAgch4VE1u2OzF1ra3QyBGykEkyM0KJ0/bOT+IEcqBGFT10B7KXgYZkBjuwc2Y/0ndlAQultjJIGoHWK3Dez92/b9qjIEBIOYkZYgtOnJCXP7qk8qBmSxE6bUwFbNrgNzNbEBg8ke9Ai0l2GMaHLcA8waBgOEvdR2BA9mASpnMZmYAGwgyeVA0jPUUxroB2WuRcJZV9mGZpDbK15emgPsHgnqvWkey93bMk92NT3s5cW40+3k06yKBmBPKmrY4hwB7Vv2jOp75TKpM5lMNv0aR6UcdmncD2dxHARHOpWA6XLggOBJi2dBJ1HjAFGDTVtX+z7pet2TcQs4mRJCjLm1jWYB2FTudmbgXNmUkuqKoDZmzLbZTBAI0uLIIkazQFGFSNb2I7MXUW6WZZtltIbvqqK5ZTEAZWBAaCdt6bA9m7l1bbB0GfKYObRGZkDFoynVT3QZG/WAKMKeVIVs4Xs+9269u3cQlACWJIWJgmY2BInzFWLPZK+xKqyZpgrJnMHVGXbVlJMj91omgRzppVtr2cYrmF1NLftW0YQM+QDUAE5g23TxqWJ7NvbgvcQTba4JzCQoUkSR++ADsSCKBGFSpUooAdfGY8KVJlI3EUqBjRTVKKagQo50Rb7gAB2gRpmMaHMNJ/aJPmZoQpxQAcYm4AQHcAjKRmbUSTB11Gp08T1qK3WAyqzCZkBiAZBXYfukg+BimVdCT/nQw1Ay7axV1RAuONQdHYQQAARB3gAT0Ape1fvd9+/73ePe/i173rVY8vxpM3jU0Wmiy964TLXHY6almJ0BA1J6Mw8mPWppdeP+8YRljvH7MBY8uXTlVJW1p81KmCaLRuuVy53KzmyljlncnLMT41XbEPsHaNPtHkCojpAZh6mmS4RsSPU1DLTSFJ3wWkxdwlWNxyy+6c7Sv8JmV9KmMXc1/pH1OYjO2p6nXU6DXfSqYMU5bxoaGmqLIvvky+0fJoMmZoMbd2YgU633ChQ7BQSQuZoB1kgbA6nXxNVwDGaRExvr8PvqOaigtB0Yg91ivIkEjT05aDTwqJvXBtcfefeO8zO+86z1oQbxpi9CQNoIuJuL7txxpl0ZhpMxodpMx41E3nO7sdxqxO8Tz/dHwHShzT1RAxFIClSagQixO9KmmlQMekDTRT0ARqVNRFYQRE9NdvTnQCIqKmRTqKJrqOv3VDZoogx5U8U+WnVd5HlSsdDAimKyfT8gVaw2HzHpXqPAuxGBKK/tDdJ3IIABjaBqOe9Y5fJji5L9NtHky2TUxZPQ+H317rb7JYFf9SvqzH76L/1YwX9Qnz/GuP8AiUfhlenE8CawYmDG1QKxGnn4175c7I4Fv9QvozfcaoY3sBg2XQOk6yGnb+KetVH9owfKYniXTPFoH5Apsvh8q3u0nBEw1w20ui4AJleWp0bXcVhMtd0ZqStA40QYeFRy/n6UaBG+s/LrNQNVZm4g1WnakDrU2qmyUtgJ6UxFSNNTJYj5ClTldJ5Hy+lKmIZWI2pqM9qo3bRVipjToZHoRvU2huLQKiK+hEfjUQKKbZOsfOm2hxQlNEFK3aJ5fGiLbbp9KhtG0URMTTmOketTW237P0oi2zBBTUxB6RUOSLoVsmtTDYm4olSwBMSJAnpI5xWdbVhyInQ+VEBaAMpisJpSNIbG5a49fXa9cA/iPzE1bt9p8TE+3eZGh/GK5rKelEfWMqt4jT5RWDwwfRpsdC3abE/1rxqJDR86o4vjFx/euOR4sTWYrtEQYmfXrvvyqN52YklTJ1O30GgojhinwO0DxLE71SIq1cQn7JoLWm2yn4V1wpIwkV3UVAirBQ/sn4UMoeh+FapmckBipz/PxqLgg7RTtckAaaA/Mzr13qjO0tgZ0NNNInWmgeM/KKozbGilT5T0pUAa7jTvD1G/86z7qjl1rdvWe5I6ctRWHiiSxnf8NK5sUrOnLGgdgDNqQNzrPTbSiu8cqrpvRLu9btWzBOkES6eh+FTOII5H4VawnDbjKGVQQZjUdY601/CPbjOImY1nbfShw7ozj5EW9Ke4H9YbaGjfby/CppiiNcrfCr9vh19lUBVIOollmInXXTerH/QWKMHIuv7y6/Ok8b+B/vcF2Za4oncNtppTnFeB+FaycDxPO0h696P8VRbgmI/q1EDaRr896j0n8Fry4fiRmjFDofh/On/XB+98P51ebg2I/qwfVfxqticDctkG4mWdtQdvU1Dx1yi4eTGTpMiuLXmG+VR/XB0Onh/OrL8PvhRNsxymOeumtJOF3yYyRPlr477CksX2G/Jj8opvjR0NL9dXaDp05+vpVt+E4jnbPrl/Ggtw29/V/T8a0WH7Gb8uPyio+KXoaG2KHQ1cbh17+r+n41VxGHdYziPDTXXlFV6dcoS8iMnSaAYgHSedAFGxPL8/negxVR4HJ7iceW1MtNNSTerJJe0pVK3aZjCiTSpV9iJZEnVod2K7EjwB2+FHx65WIIk6QenXTnOnwpYsLnAykQIblJjQgRoNR5789J8XSLhH1rO90dUl9LKFveiXGkz1oS70UoYzaQCB46/5Vp2c/R1fB3K2l6jUfE1n8bfRP7X3VocKT+hQ+B+p/CsvjZ0Txz/4a2l7TysX879Wa9i4QF12A+gozYpgIkgg/nyqkgMDyFSZtZNOzBrc1bPEXIOonlPltQLvEHBgHf8APpVBjppUGO2/nSZUYo0cTjXA7rc46xpr9Kr9oMSLlpD9qWUxoAYFQFpiAQrHXkCfpVXjQZbahgRLE6gjkNprGbTTVnV46qa2N/iz99FnVFEjlOUHrrVVcUxjWYEDfTnp01M1HiYPecK+w1I5xGnhtVLh14HQ6ka9fKeonl0qk0ZSi92aFzihTLmEjaJ5UM8RzSdpMafz9KzMSWBAcaTyAmBvHQ1C23d3ETtz+HpvWiZDgmrLl7G8p1NZPF7hLKDuJHzBqd1u9VLiDywneib+k38fGlNMr36EBRb29Cy8+VYR4PSfJECnXelA/D7/ALqS1Qi5w9yHOXeD934Uqjgx3z5H7vxpVcW6OTMvq4DYwHMs5dAoUDTukk7bzMzP0ipcaP8AStVa4QbgIM6rznpz50fiZm62vOuWqkvyZ6kn9L/MazhQiC44ksSEXr1Y9RQ7j5hJQR4CI8q6W/YUlWeMiQscoiVHymgcUxKMAF58gp57cqiOZt8GUse12W+FP/2ZQsTBE+pn61icaecnXvfdVzgF0hHtzs0+UiD9Kq8ct5Snjm+orubuJ5EI6c7X5m/7BQCMwMQARsdOXkapFJ16Vete7+fCnSyNNKZyaqbM/KaJbkERp90a1eeyBrtAmqeFxCu+WIImD1/CgtSvdGqnH8WBAvPp1yn6isPtTxK7dVBcfNBYjQCJjoK2hh51rmO0j98LEFQR56z6isZY4LdJWdHjZZSmlZsL2oxsd28YA2hNBt0rOu8SuPcDu5ZhpJjb0qlFKI1qo44rdJI0k3LZs08dikYiEkHYmRJ2MRWdfWDEQRoR0M605uGMrSRrG2/w2obt5a9PONRyrQzjGhmI/CquMbUE6n8Pz8qtkAhjIBEQP2teXlVLFbilPg3xe5A8QusAzsem4BO/w9KGB91SunWo1iuDt7Geko1pHWp5dR8qYg2EP9J00j6amdqVQsk5j1j8KVaR4OTL7jocfw+yoDKIM9TWRlVnEkySZmMsbiOckzNEv4kkb/n4VWNvQMYg7Tz66CuHFGSX1M9XPOPSOow+KEtbb3W7wLaAmBB8A3eHqKzOIYsB5AgBAo8wTqNNN6pXMSbjqPdAUAR+6BE8txUcYskSSdNjED4b0RxKMrZk8mqNE+FYtUY5tM2386t9oIlIMiGjpEiIrEe2QdJolq4TlnVRsJ28q7U9qOGWJa9dnZ4G4HEbEfkVo27EfhWBgL4zoxbTnzga6R5Gupw2KR3KGBqMs8yeUddqcmzyJxaZmcZYLbOurCB4zXN2XysGG4M6+FdF2nhYt8wZI8xp99c6E0B5TFOLtGmP2m1ieIl1le7BUiIEaAEHXvCda53jhYsMxltZ/nHOrS3SAVnQnX7qocUG3r91TLg6PHjU0EmpkaeFRgjY04bSqiW2QApisH+dTUSY0Gm5MeNDO9WKyTKQY/n9Kp4gd4TPpVyaqYoyRUz9prh9wG9vUAKvHBs/e0C7STHLlzJqNzCgDR1bwEg/MVzqWx37WVFpfaqXPpStrr5H76AJ2B3j5GlU8KB7Qztr9RSraHBx5n9Ql+u1SvuSfImPlTi/L5goUDXKDpoNqiFBnvQBEn0I08yPnWUEdWWW5C00Op8a0XAnb5+FZe4MddvpVjFXZ0XT8ifupZI20KDpELqM0kD3jAGnLwobsR3dhvHjRbd4Jp/mDyIo1h0uNDkkH5HqDT1NE6Sxwq5/6SD+fWtQv3s/rHpppWRZsm3eyMdGEg8iCJBHwrTSCQNfHx36fnWtFK1aODNBKQfiOL9o2dzLGBt0ArPYzMbbmtnA8EvX1ZrVvMgkk5gNv4jJ6VlXLJUkHkSI8edSpxeyMo46JJhy8KFMmT8pmh3rFk5Qzs0SDly5dNTqx+6rF2/7O3EHPcG4+yg5+pHyrc7NYGyLRe5bV2YcxIUHkJ+tcfkeRpV9fY9TxfGvfswMRhQQWtEso3BHeA2mBuPGqLitLHMLF4i2YSQQN4B0IPUaajxqGOswQV91hI8jy+6t8GW+e+DLycGjdGeqajQ+HlTOs+HxopU/Cp5ZIAnl5+ldNnHvZWW0ekzQr+EbMsggHmR412ODRbCg5QX1JJOiAb6xuPrNUbvE3xBKlQQuc5oJBBBgZdhrrPKK4peU5NqK2+T08XitVKT3+DMHfuKraIoA8Y30mj47hQDD2YJVpKEnVuum87/Csi5eZT3pOmn3CtOxhHLKXZSjZSGnvAbgLO3Pas5ak7s6Ixi1VGdxDB5Gza6ieUdJBG+tULXKu2t4M3rNy2g7yZismdDuCfgfSuNSyVPeBGsHTX8zWmLJqTvlESSi6JYUd8+v1pU+F98+R+opV2Q4ODN7gQO/kav4Hgt24hcAAHbMYkAjWOmo18atcH4M9yHOWGnKGJ5EasAJy+W/hW9iLd1ffuowGmiFV8pB2865J5a2TOufJymK4ZctKWuAAExMg678vCruGwWfD5xb1OY5z+77oXnP4VqrwcXAc91iuaVU/ZA5HrRsPft22a3LQAO79kxtp+dqwyeS2qW7RvixdvhnM4bglxxmAAB6mKWL4Q1s90ydPj4EVucTxjNb9nlEEiOs7CIrIxa3MNlVjLMCSCduW3XX5VePJOf/AAc8cYr/AGRt4n2ly1PvIMp+JgfCtvAWg7a+VcrYeGB2gj612eAEGYHoOldMvpjSPJz7ys7zheKS3agQND+dK5PjWCDt7Rf2gD6zE/CrWGuZmFsNGoLNE5VJiY5k6x5VQ7Q4lrIdA7MCF1IA3JGgAHKfia4FFxla5ZcVrpGFxzFIAw0J0VY6DmfDXaj8LwY0YXNMhiYH2ToT8K57iFwEDQhuZ5RAiPlVjAY8ZPZu2UAz7uYH+dazxS07fqenjnFOmS4tZNvLDTmGxjwP1FaHD3NxMkFmABAjWDyHXl86w+IYz2jDUtAiTp5acqvYK5F1IPIT46zHzrSKcYpvkyzJTtIs38M6Hvqy+YI+tWuEKTdzdMzknlAJk+ta823U6d06SJH051n4N7dsOtxwC0DLPeMGfgdNDV5J3jdHm+PG8iUuirxDHlgMqEqumZpCTzhftnc6mKHbwyJbbM75ngIV0AYGTOo5abc/CoYxCSWZRl+yUM8+h3J8elVb2PCDIyKx0KtqD5HXSuaMdkons6lu2NjUAnSSrOCeup1Hx+VQHErmbKSGVRATZRv8Yk0FrsCCZJOYeGn1mo28YsyyAtyIH3fdXQobbqzneT4Ok4VjDYtvccZS6HmY8NDzOlc1dxJZ83yP3+e9S4lirj5Q+g3VflNVFqsWNRbl2zOUmy3YCZpmN5mY+O4p6rBvyeVKt9VGMsduzuxehAihgg2y6DpuASfM1Sul1BhpH7Uar/GBoy/OqFogHS41p+UnuN0g7A+Bo1y5d+0SR1BzKf4hqQDXnKFM1sqvjWRiGXKeYBlT+8vUVQxeJhw25+o6jwrRTEK0JcXumV13UjbX76hd4QuUlbgI/ZOjq3nMEHb4VolFPdFxyNKitdxDXPdYaKW5aADX1oHEBnRLgLHKqhpMxM5deW1RtiGduqGI8QBRcDisoKRKkAGR4R6itIx07rocsjkZsxXb4DEm2rTDHNoDqFnWY5nbQyNK5XiGAyMCuqPJQ9R0PQjnNdHfW0Lbj2yFu4wymc0wCAeqwfjWk5RkjlyQbqiDOWJdjJYwTynppz1GlVcYmdVZ2yoBK9WO0noNKAjhDnRgdNFHXadedTxV0lFQZoCrEMACI6RWM+Uka4MelNszrlsMzAEhQZn0gbdTFCwVxVfv6Dyn5U11SojUkx5CNQD1NC9mSdATrG3P88q0StUbN07J424heUmPERPpRGtse8u5Guu/l1moXrGWBHekD8iiWHMZZ2Okc9dYPSjhKgTvk3eHYk5GA0jqCT4qVB30rPx2J307zTmJIZz1mJyjwoNt4cBVKyIbx8d96ujCIwLPcCbywQdPE1lsnuJxXuXPZQQsEzElRMCJ+OnT8albvsyMpynnPOefnVjD8O9oclu8GOgVSIzSYA3MfzqnxDCPZJS4mV9vh5VcdLddhbUbKVx5MzrO0cvzNPZYBwTyM/OhhSTpSIk10MzLPEb+e6zAzrpOunryoCnWoz86nEChKkBENSpBaVMDpcBigRrsfsnXX1rXREErlVY3AAHnqCK4hLhWtrhuPUb1xZMT5QGpx3hpe2GtS0GcsyR1ysdxrMSdtN65oXiWG87RPhrXULjmC85OirrA5axzjUmhXr9slM6hyNVnl1MDZfCphNxVNWBzNxSttV57nyHe/wAXyqGHuldiQSCp8Qdx5V1T4fCXJIQSdxnYZZEaa7adKr2WspmVEUou+cBpnqTWiyquGBU4fjoHs2l1P2BBHpOinx3rcwnAbZGZmdgR7q7g+cd74Cs1OL2rci3bVOZyjX40d+0ihBl1PQ7fI1z5lOXtVHR47im9RBsD7S57O0hVmOU5jIKk95pgZSo1K1vYjsfltzauMzqIho70awIiD51zPDOJe857pMj92IO3MHwrbw/bm5bGVUW4YMMc0r0zAaNWeRZk0o9Fzp7mA9kG4pdcw0kHpEDMo6b+lb+EdgFg5VC+6oygMs5oCxvpXMY7jTt3FGRTq5QZS5OreW9X/wBc0hvcKgqiGFjaGPPbnvFbyUtKszjBSfIruKuOp9o2YFGOoB2WRy3mKz8PbWRp3dpG4/MVcbFIud8xR8pyQsoTGgI+xMQaA/EfboIt/wBICJyqdVOhiOXga054VIhQcHTZHCYK7edhaQuUjYqIAkD3iOYHwpXuGXEuJ+sIyKW7zSpEb7KTE1u9g7Vy3iSz23VGR1JZSBMhhqfI/Gl2/vu1xFSTlObugmND0rP1JeroSVVyU90WrH9Db/WiEdiWVCiiEC6Z43ZtRttPPli8Qw9u/ldmdCRAJUS8baTyHPx8KnguIzgjbUgXEdz3wYyvBJB2LAg6Vjvim0uSSZjMeW0hR686ccbTtPcE7btbdE7nBDulwN56ffVO9gntwSVBgxrvyMfGiNjmE6/j8qrYnEl4kkxPl6Vvj139XAppVsQNsjlUHepLcjYmigjJPdJzaa6xGsjptrW5kQY6UqTXB0A8qVAE3Qjf50NXg6Ue+wOsJPr99AzeVQhIurxAxrrG3hQTjDJM6xHp0FVkaDpHrU3vA/YA8qNC+B0HtBW1Lhf7JP0q9ZtoylDdMGTAQzoJ310iscmpbyRpAG3lB+P30nC+y018G3Ywtoai9r4pP1FHbDWj714H+yB/hqvw7gF27hTfty5Fxrfs1UloVFuM8zAUBgIjcjrR17LYnc5PtAgOrMjhcwS4o91yNgfGTpWbxy+TRSjXA/6jh9vaD0JH0FGs2LCDu3WHkY+dD4X2RxDtluMtuc8EkOcyoz5cqHSQp1nSsA+7mJgEaCdTUyxPixrIvg6g2cKTLEExBJJn5b+tBuYDCHYx/aI++uXa6x1zHzk1H2h6n40LBL8QvUj8HTHBYX9onzYmat2L9m2P6O6U8p126eVcc1zaC089fHSPSpe3brT9GXyJzi9mjpLr22Yl8S7SSYhvvmjYTF4e0pVbh1OpytP0rm3MoHJAO0dd9fSq6Hfyo9G1TYlNR4RuYprLFiLr6ydUJEmJ0kdKq21sqZNx3PT2Yj4ZxWcEMFuUgE+JmPoaQSZ8BNWoUuQ130by4+yFhbbkzr3UAjlHeJ61l417ZOiFTv8AkCgW3gHXlyqDsTvpA51UYJMlybBVNmkmBHh/nUVE0wrQkeaVLKelKgDSYhtsq+SyfjVW9hSNQcw+dJHFW0uabbc5O0bRUU1wTdGXRBvVnE2Z1G/1qntVJ2UG7sc/j/KpWx3GP53qvNWl0tHxP5+tTIqKO07F8Mxt7DXbmESyURrgi4z5wz27Ycpl+1lUANIIlutA7P4vH8RvG1YayjhWusSgthz3EZ3KKS9w5hqerda7v9A/+h3/APf/APxW6q9j+DfqnaHFWwIRrL3E/ge5bYAeAMr6VVCs5zgnC+K4jEvbQofYXMru0C0GAIIBC5mMMdANjrE1jdqOwmMwKi5dVXt6LnRiQvIBgQCs9dvGvVOP4y5huEYi7ZbI7X70sPe72LdCQeRywAeUCsrsdxC7i+CY4Yl2u5ReRWc5mj2SuJY6khjIJ8KOw6PHcJhTdu27SQGd1RZ2zMwUT4Sa7v8A/jvEP28N/wAb/wD51xvZpv8AtmF/39n+8SvRv0z8XxFnGWls4i7aBsAkJcdQT7RxJCkawN/CmI59f0YYw32w3tMP7Rba3IzvBRmZe6cmpBXX+IVh8E7NX8TimwlsKLi58+cwq5DDSYJ3gDTmK0exXae7a4jYvXrr3AxFl2uOzkW3IG7EkBWIaPA17Df4ba4fc4hxMkQ6IwHQqDmA/jfL60AeT3f0eYv2d9w9grh2ZXh395VVmC9zWAwHLUGrw/RBxAfbw3/mP/8ASt/sniXucB4hcY99mxTsR+0baMSPWl+hPid68+K9teu3Aq2iud2fKSXmMxMTApUBwvansNisBbW7fa0VZ8gFtmY5srNqGUaQprn8HPe6Qfp/KrXGeKX7rMlzEXbih2IW5cdlUyRorEgEDSR1qpgD3o60pcFR5BA60zClc3NSS5HTYjUdRFUuCWiK0ezaB1OgPTnVc0YXNKaJd9F626Kfd+4n1pVSuSNCCDAPodR6U1O0RoAhqmHqTWxyoRFQnZqWRtPLafGKGtlm1AnrQ5qVu6VmDvSd9AhNZYbij3dLajrQTcmj4w91R4VLu0XHhnq/6JnK8KxzKSGD3CCNwRZUg12/BbaYq5huJoBL4Vrb9e81twD/AAstwf2q4f8ART/4Tj/4rn9wlXP0GcYz4e7hC0m02dJ/YfcDwDgn+3WhBc7ZtHBL5/29z/nHrH/Rq5bg3ECTOt7/AJdK6HF4L9f4bisJZdRdS/dBBOgYYhrqg9Ayka/hWZwzg7cK4LjBinTPcFwhVMjMyC2ig8ySJ0Gk+FKtwPIOzP8ApmF/39n+8Svce3vaDhmHvomNwhvu1vMrC3beFzMAJdgRqG+NeHdm2y4vDHpetf3i16n+kfszex2IS7aa3lS2LZzuVObOzaAKdO8KYI804/ctYrGscHaNu3dZEt28qqQSqJGVSQJeToTvXtX6SeGXW4O1sOWayttn/wBoEAzk6eBfT9muE7IdlXwvFbCXwrMLZvLlaVzSVQksBEamIOoHpr8P7ZfrGPx1h2UWbiFElsuX2asjFCREsGdtR9kUAVOyOKy9n8WgBJY4jaIA9kupJI00jSTJGlQ/QheC3MVJiVtc/wB5/jWJheIeywOIwyhintbyq0aQbcBp5aASDPvb0/6MnAuXQQdRbiBzDMRqNvz0oA43Eibj8u+3/uNPhTDioXfeb+JvqfnStHvClLgceUEu25ciY1q1bw9vSZPmSPpVbG+95gUAMetQk2kOWzNN8JbMZfDr6jes90Kkg064lutRuOSZNOKae5LGJpU1KtBDRUqjWzwrCrcQyqyDuVJmQ50hhJGWIHUUkNmOaiK01sKwkqATyGgHgO6Y+NRxCWwCPtDl6b+6KTAoA0fFnYeH4UJF2866HB9nL9+2r21Qi45S3LopZlIBAUmSBm1NS+UX/SwHCsTj7eHufq7XVsHMXykBWhQLhjdoWJjYb1LA4DiOEulrKXrTkZCUiSGaMpIJHvJqOWXWK0xgsbYwxf2dl1sC6qXBcDMgfKt3KFfK4BuDcGCx35bFq7xS6c/ssOS4a5OYZAobMUcK8K0YkD9ohlkyJqyDmcLb4pbvNet+3W60s7o0l+61wlsphxlVjGux50Lit3iOLObEG9cyMi9491WuAG2AohQWBGoHMTVrCdpL7K1uzbs21RdGBKhAAUDFy3eaX0JmTlG2lad3i2N7zHD2BmZjCju5kFp8055UZbNsrBghTvyQHIYLAX2ZzbRs1oyxBAKENAJJIg5h8RW2uK4sLltBcxIds2RQ2phZfLryFBfE31XFOlpLauSl6GLZGRwSAXYwWZoG86xsa0v+lsXda04tWfaD3CHYOqXctsMUz6LJUhuUjlQMxcfxXHB7d67dvB2SbdxmOYoSy91t8p73zrPu4W7aVLjKyhwSjGO8I1j0bn1rS7S4rEXWQ37aoVDqoQQI9o8iJMAGVEaQBXUXf1Y4XAriUZsyhUymIJCAkwRpqtJyo5s+d4mtrt9c8WcGMddClBcbKwgrOhG2o56VPh+Lu22Asu6sxUdwwSZhfWSY866z/qzYW7i0ILC2isneMqSpMGInUc6q4LhNtcNhr+Ui6cQoJJO2do7p0+yNaWtELzMbW19f5Vo5nGYa5bcpcUq41IO+onXzmaCu9eg8T4XbvYrGm4pZktIUgkQ3s+g31A0rn7/Cba8OXEZSLpeCSTtJHunTlvQpWGLy4ySvl1/dqzExO48qAzbcqNe2FCUU1wdsuRqVSAqIpkjk0qalVCHUxVmzfULBB08F6+NBC0riFWIO4qUNlo4lDyP/AApUTjI0VQR+8onx25VUNPM70MEW3vZoHQz8q0MJ2mxNlbSWnhLNxriLHdLtElxPfiNJ2k1kWBr6GhualKmW/adDje2OLuWntMUCXJLZUE94oWgkmJKKZ38ppYftnibZtZFsL7JCluLSwBmV5397Moadyd5rmzTiKsgtWse6u7nK5uTnDiVeWDmQIg5gDpEEVbPaDESe8veVkIyiMrZdAOUBQB0EjmayQKk1IDQu8Re4LmiKLhVnCggFlLEHUmDLtRsPxe4mQrkDJkAfKMxVCrIpOxUFV5SQoBJGlZdqp3GEDXXX01+dS+SlwHv8TuOFDEEIuRdBOWSRJG51iTyA6VYvcWustlGKxZjJCjTbf9r3RvWUg1o5aaGiXFSrUuODUXtJiRfa8HAdgA3dGUgbSu1NxHtFiL2Uu4ORgygKAMw2JA3rJ5+lO1KkQsGO9VK19jVXtFiBeOIDgOwCtCjKQAAAV25Ch8X4/iMSAt1gVBkBVCiepjes8UqeyBePjTUkla42E3uipodCJA9Kgvu+oqbEQNII8N9Z1oNZA2NQ6+dSyE8qYDQ1QiNKmpVRIQVGlSqEUyDVKlSpsSDL7x8vwoLUqVLst8DHlTUqVNEEl2NJ6VKjsfQ6b0z70qVHYdCSiUqVJjGPvelO1KlSAcbUhSpUFdEht8PrUsTvT0qRL4JnZvI1TTY0qVNCHpUqVaEn/9k=",
            },
            {
                id: 20,
                title: "Venom: Let There Be Carnage",
                genre_ids: [878, 28, 12],
                img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBcVFRQYGBcZGxkaGRoXGRgaGhkaGhoaGhoXGhkaICwjGhwoHRoaJDUlKS0vMjIyHCI4PTowPCwxMi8BCwsLDw4PHRERHTEoIygxMzExMTMxMTEyMTExMzExMTEzMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMf/AABEIAPQAzgMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAFAQIDBAYAB//EAD8QAAIBAgQDBgMGAwYHAQAAAAECEQADBBIhMQVBUQYTImFxgTKRoSNCUrHB0RRi8AdDcoKS4RUkJTNTovGy/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQIDBAAF/8QAJxEAAgICAgICAgIDAQAAAAAAAAECEQMhEjEEQRMiUXEykUJhsSP/2gAMAwEAAhEDEQA/APJMtJlqVhSCtfEjYirTwtcBT1FOoitiKlOy1Iop6rTqJJyEVaYVq0tuk7qn4i8iJVp2UVIts05bR50yiK2QMoqBkq+1maiNqucBoyBrJSFK1WBwdi0iveTvXuCUXNCKORYDVz5bDz1iC7xa3mynDWWUHlaVTE7Zkg+U1mlxReLbM4iVMEo9xXhCd2MTYnuyfEhILWiToD5Tp8tqDi2aeCVaBKQwN1pmape7Nc1umaYtogYUhFSZaTLS8RrIjUb1OyVGRSSiOmQGngaU5lpDpUuNDWJkpuWnF6eqcwaFfg4my1wSpyldWjiQ5EaJUyW6sYCyLjZSwXoTtPSrSYUZS2YZgYy9R1BplQkpMpra8qlbDwdKuW7J6VdGCTu82fxzBQ9Ooq3Eh8gMtp5VL3NXbVipkw9UUSTyA1bGtPW1RazgXZ8gENlDwxC+E7N4o0865GsKWDXDcKqSRaHhEbAuw1JJA8M770rnCPbHjGcukCe4J0UEnoBJ+VNvYZl+NGX/ABAj86Jpxu5bGVFyZRqoVIdp0W4Yl/nGka09+M3WI7y3aU6AZkl2LaaZiY1qbzL0i8cLrbF7S4NVsWrwWQQ48OyzcY78oECfSsbZtZnliQgIJjQkHWPImDR/h/Gnt2Dau2i9oFlJXcMIVhB0YadZqhh8bZSCQWtoWKA6M5GUqGmdASdvLzrDKSezXFNG5OGUcPbMoU3SuRDtbzgKCono0xv+dYfD4YM62+8UMxCxrKkmIYHaruM4jiL4tXLqC3azAW1AYZixUA5j0Bmf9o0GJOa2LoVLq5Q1suodgF/A6w4jTmCIjca0x5JJaElBewD/AMCc62yt0RPgM6TE9PrQu9aKnKwKkciIPyNX7uGOGuJetkgXA5yDN/mQOyg6Su40MHWiz8Ti49q+e/tD4ZVMwGXOGZzAAKmZB1JMRtVFmf8AkhHj/DMmUrlSjuN4Wr/aYdWymYRiGO+yMPjI6b8xPIQy8varxqStCO1plN6hZasOhqC5tSTQ8REWntbp9hKnyEqW0gaefypVFUc5b0U7dksYAknYUw2TJB3FWFPSm3E50jgMpl0JUiWJqcW6eqmrpGNzGJhasopGgpyAmr2Hw5PKqKKIyyDbERtUwtg1M1kKuYwANSToAOpoe/FrQUlTJHUQAPxfi5HSBt5ijKcYdsSGOWR/VBG3hoEnapkx1u2s25Lc2lBHIgGZB8h8+VCcR2g+yW3k+0YnSCpHiIAOXcERoI85qAcYthPtLas/Tx+CJAAiI/qahLMpaWjbi8bht7YuLYXcwFzNNtAGfXLZUHPB/EGRdAds0TUmA4zbtrkUBEYP9o653jZSqiASWG06ZBQTDcQBLowUBwyox1yBjORtR4TqJnSfWhlxm+8DMlY5gruPrWTnRs4mrxvFLWQMj55zL8C2gGiSCsBtAwMi4Jnyis5h77i+rjOzhgRlAJ06AE6b6+c03BjLIcrBBZQSJzrqp8gYynrMUVw5DIbbk2yzHvCoBMljDMg3WPDA2G3OUlNvbKY8abpDuC4xl7wXFOUhy2bXxA5mIHMbA+1O4faw5vIVtloKEqUaNIB0O0nWrLJh7RIV3cnYv4RJM5QsaCfMzpVvhNx0Ze7t5ZAJZ4CgBlmFBliOe0AE8oqbfpF44lGNydf6KPanihi2IhgoIg65TbGRjGktmLmOi1W4ZxpkAgiYKMrZir7agzIOgnzE86GcbxLXsRdaDCloHQIAJ/8AWai/giurMqjkrfEw1gwBsYMH9xTptPRnaTQR41xS7dfxtLaZdvDMABekwDTOJ3/+YuMrzLTMkiRAIk8gwIHkBVbCqZZyvgyXNT93wkKQdw2Yr8/OqV22QYBmI5flRcn2KkjX2uLEoVKIQY1XwnQ6kqHAJmZkb6iJmpbl1bw+0Ie5GmX/ALjZRA1PxkHQzJiKxVu+50DGOfzn86nstdQq6XGzGQMpOYbe45fLyplla6OeNMM8SwLWjBgg7Ee4IIOqsCCCp1EGhT1ocPi0uInevme4StwQoaVAyyNADOzHloZOgbiOzVwSQUKzAYsFDbGVDakajlFa45FJbIceLM6rRXB6S9h2DEMIgkEdCNCK5koXIakWEGlKVqNLkCnB5ok2maBbNTJYBq0LYqexhZ1qyPOlZXt2B0ophcMTroomCzGFHqf0puKZLKB3WSTlVRzaCdTyUAanzHWs1xTjd4sFEAAFiANFU7BTvroSZ1MUuTKolsXjObt9FntfjNERNE310a5IOpXkBqByPKd6DcBFov8AaZYAJi5myjXRjHIEjQeca1BjeINecORsoUDc5VECZOp/c1BbtzMtH059OesVhk+Ts9OMVGNIucaxfeXMwWFExyJkyW66knfWqVq+7OATpB5LOVVJiSOgjyqF1bYsT6E/LWn2Vjn86V22HSFYq7EwEYnQICUHTTca9KJcatrm7xRKs5zkbJcCgOo6E/F5+1VsNZAIMGVIMRzEED+hRDCcPle6fd2Ur0VhosnzzEcwJFMoMV5EgXYVM2fMfCCcpXXQfd5RqTJ1Ee9XMfwe4WNyFyEC5mBXZo8REzBJ09DT7eA11G0g/lRXCZfCuZVuKD3TMRBDN4rbAggg5mIkaSQdDIf49bJ/LvRkXsMD5zvIOs9RpRG3jHlYzEBTKkgiZICzpC7edELmFliCoGpkDLAOvTaDUKYUo06Eid/lQ+IPzAjCz452ysWPUkEL82Ybcp5TRPGm2wRHtEuLdoMysQVIRQBrpGWJkaGanuWcqBcoO9zWCAQjBBHPcnXn71XwWGLsWcAgAsSTvlAgepMD3peFaH+S9kOEwDMVRZgfEY0kgtJI6INvKpeJ4AqIVfAv3pJLeonwjyrVYOwFsydXcxIAAVFAEADzGWf5W5RLWw/lWrH4ylC2Y8nlcZ0jDm3liBp5UlvF920hc3k2x9YrT4rgaOZEof5dvl+1VLvZjwk954hqPBofXxT9KlPxprpFYeXjfbM/ZvF7udtWYkkzz6zvWv4XirmJw9yyUGVGRluGc0y0L0AgfMc50xuTKZ5j6H+hWx7LuptYlGJykIx+L+6+0B0ga+JTqNPlUIa7NEipxnCgBX+9qtzfxMJ8Qn0ZT5qOtBrlG8S5ZVBmCqsZ5uR4mJ569f1oa9mt8LcDNJpSBpFPzAVK6U02vKpuLH5JnoVrCiimHsARVbDkVfwy61SzFSMt2nxM3EUt4VJAG22p9T4vqKyWIuyrPm8RaAIEwASPTYbUe7UCLij/AB6zqTKrBHIeEn3NC7OGBRvDM7A9d50jp/W1ZZ29HoQqKBNhWkRrMaUSTCH7wIPnWr7A9nFu3We6ge3bWIMxnYjLtvADfMV6GeyWCaC1gadGuAfJWApUlHsnPLujxnDcOe44t20Z3OyoJJ/Yedendk/7PbdoC5ilW5c3CHW3b9Rs7fQcp3rZcP4basrltW0tjnkUCfU7n3q47KoliB6mKDl+BHJsA9qOzqYq2cqgXEEowGpgfAfLp0NeR3LZBjYz6EV78hB1BkeVeP8Aa1P+dviI8Y2HVQZ9apileic1SszfFMTcCzlDMYGaNffk0+Yp3Z/sribxDpbgE6FmCDXn1I32FTYy34RPUEEeVabsdj7rpcWxaQ3bKA5XLfagkbZeY/Wp53UqNvix5RszPEuD3sJfNu4AQQGlJK67GSAeWunOh99p6+9eu8Z4OMVbtXL6hLsgTaJMqVJy68g2+hMA15QbOYmDVMTuNEc8eM7KyDlMk7/7f1zongMGzxaVfiIZm6AEjU+s6c9Kl4NwJ7j5U8TbnkqjqSdT6Ct9geEC1bC9NWY6AnmfIVeEVezHnzOGo7bAVyxAAjQAD5UxbJJAAo65tswSdTMGDB8p2mp7eDA2GtbI5YNaPNyRyJ/a9gX/AIcedDeJ3rdshWYAnYDf/aiHbC5ct20ysVBYglSQdpAke/yoHxDs/iHXN4WJC+EABlEaCWG4mDrJ86nPLLqKNGHDFpSkwPj8NYu3PDc7smJJgAwAAArFY0HXU1awfBhaZXRw4GcNquuhQgFZCjcHnodqF8QwF63LXLbrqAWIMeXiHOilnjDG06vDOo10jcQSpUCDDCR8q8+f8raPYxv60mScQwgXKVJZWEieQgQPkR86HvZFFVuNcUSZUSRBkAnQiBt8I0qvcSNx71ux7gjFklU2gK+HjlVZkIOlGbizVZ0oSiPGZsMIwAothmrNWr+sTRTDXTprFdxI8wB2ytTfGwhRseedzA+c+9Q4BWhQokkwB1YmB/XnRTtOi94x3gKN5JIksI5QZ+lXeyWHX+JtrM5Ve4fOPAPTxa1l6dm9/wATc9n+GixaW3u3xOernf8AQegFG0Wq+HFW0FQk9kEiRFrG9urjpctFLr29GJyzGURmJgRA5+tbC5eVFLOwVRzJisL2l7QpcuKiMEUBlZmGpVhBMbgCR56+tLVo04Yu7NVwwJaX42K5M0trog8Rn1kkcp868q4xxDv7929Gj6jyygKAfQD8q3vGMSWwZW1cthXVrXimT3ogZD1WduhO0V5zicBctrbQ5S3iDRJUbQS240gRHKq4KQc+KUlyS0Rd5IjSP6irHZDiT28Uch0uQhEoA2o8MsQd/wAOtZ7F4ogZR6E/pUHCsVdtktacow5jpS+Q1JqvQ/iRlBNP2erdqOMFbaWmlLhZUADS0u2SMw38JPsawWJwbWbrW21gyp5Mp1Vh7frVrgYa67Xrrs76hOoLfFdmIBA26TWixwtX2XMMsP3aNExCu2XzUldPWjinT2L5EeT16HdibZOIQgwIcFfLISCY84q3/aJjzbC2kMEjM3oWgfqaD4a3ctN36toCArodAWkjMOmpkERBoXx/Hvibl24dwq7bACAI8qpkMuPGnPk/RpuArcKd0Htt3qmNLhGZSJLuF+zOUmDBggGa1PCrBuW5JBZWe2xHM23KE+8T715VwXjyWmFx0LMg8ADFfFynTbrqPevUuw2IzYcqSM4dmbzNyHmPOaRScVor5GNTQ3i/BVvIqn7txH/0sMw91zD3pj2JrQ3wJCgbzrpAjrr58qyXazFXreW3h7btcuTLKphRt8Wyk9Z09warDKY3i9GV7T8RQn+HQzLKLjDXZh9msbn9RHWsf2mw92y6j4EIzIFPMfFm/mE68q33CuzvcjvLsNe+YTyXzjn7Dzy3bC+ty+qAT3StnO41hmHsF+ZI5U2SNw5PstglU+MevZY4I+ZzbYliqgExGqnb/wBqu43Dxyqh2Rh1uXYIZnaRMiPCQR5wY9q0GISRVsD+hHyl/wCjMxftR6VWS4UJ1GvWjWJsdNfShOJw06zHKqNWhccqY9LpBoxhsWWCqxkKIXyBMx86BAUQwrdKCJ9FviRt52uG5z0y5cxIAGXUHbYiCNCas9n8dbtXGuhgxZSsMcpUSpOsEEaac9NazHHMVqwLfDmVQPNiST85+XnVHAXzmGxIkjMdDl8UH1iPOaxuSuj1lC47PceB8Xt3Sygw4+7P1U8xR5DWPwHZ/DtluoLlskBlKOwiRIiZrWWdABJJAEkxJ8zAAn0FRmtme16MT/aBiWNy1aBgZZ8pJ3+QFZ3h2G7y7bRv7w5UYjQvp8RGu8CfMelFf7Q7mXEITpoBO+mnLy1oJjT3Vy3lc3GXxSJ0ykkZZ2MCY6ija0j0MbqFGgx2DyC2LjBUNy5ohD+JZQ/Dp8besnlQzjJW3bGJZWksFysxlhlByurE6ZZG3LStNj+LWbl/BsEDK6vcygqIZiJJ/mBDbGZFZb+0bHJcu2wVKEBs3iDKYgLBX3+ZqEpyU1FLVFscmsTbRj8DaS53hI1EmAOfL23+VUDcjNHU/Xf8qscLuFboAIGYlddRuMunrA96jTCFr/dD71zJ7Zon5U7d9mda6N2+LRMMGtgeFFzBfxZMwTbcsQD6ig+Mu3UV7aIT3ZsEODs6OVzR5kRFDuNvcLIiO2V8zKq6TlItqQRr8NsGiHCMVcLDvbLOwEllcKbkajMpUgvPPSTvrJIT2LVI1HD72W8bf3RbDRykPdVxHqSfQkcqpdosKqKLyrCOGs3VSAJBIVxyBlT8hVTDYr/qL6Mo7lswbLmkhbhzBTAIzxp0NGY73hpLDU2zdHrJu1ojvRBunZ566KGiSVn0MVpcBxoWlXuw+YQSxMfCuUAAb+poC6DSBVvDW9KPHY7ejfXu1bgWLoVn7q2TfBAUur5QzJOjZchMjSRBia1rOHVXWCjAMDHJhIMehrz7ib2bmDwttrwt3ELk+FmItuXGaAPEuZQCPXpRi7wvFtaS7bu3EuWgDbQXDcs3lVVaVMZlzZR4XJ1kcyaXSIzhyQztgtwJltwpcGXZgoQc/OY5gaV5lxAW7KG3aum5ccFbjKq92VaPCpOs+Y0IY16/auLiLaXhBDAEj8J5qfMHSh1/AWySwtpprORZ+cVo4c49kMeT45NUY3s26WrLoZV1l3VgQ2UbMo3ZIkgid6K22DDMsQwBkcwQIPyiqna+1b7vvG8LoDlO2aZBtmNSrAkH386GDjd1bSXGW03eaKFZ1M/hiG15b9OtNGXD6v0dLG8v3j7YYu4o2gzhsoIKsdPhbQ6nb1oXeVdCSNdRQnil29fUhkVDtlGpIzK0ElhzUcutDkQLAv2yQBAIzGTpz+e2lCWSSeloeHjqtvf4QcjX96t4O3qAR09aV8PTrxZFORc1wwFUaSSeW3Kao5KMbIRg5SpGf7SMouPlObXcHRYiR88306a0sOwIyzmIICxO2532E+WpPlUnFsPcTu7jnx3AzQPuwZjTcwV/KnX+HPbPdvo0C4h1h0YSI03Ec/Pprg3Z6yapUe38Avl7Fpjzt2zpEaqNo0o7aNeU9m+1vcWO7e2zMuYpuNDrB8MAZix8gY5V6L2ev3bli3cugB3loAjKrMSiwddFy0ZGKcHFmd7c8MtZu+bMJKh8pk5dAcoOkxWWwuFuOouZgu4kkkyAB7TMVuu0zM161adEbDkqXYyGjNqJmI0HLnXn1sMmYITlMjfWOjCud0qNWFvi7JMPZMhwRpJWfPmBB6UN7TXy95Rp4Bk02kDX6zWmThMWy3ep1Imfh5SNiZ0B302msxjbUmfOudS2h3kcYqHp7BDIfE67plj1mf0q7w4Z8W7jeHZf8TDKv1cU7uotuOrfkKvdm7OW9cciYWNp0JH7Ck46F5WP4lhicQBbGtizbZFOoYqcxU9ZBolbti3dU6m1cXOhk5gCBKTuY5etD7WIQYu41zRTKkiYAACAyBpBG9GkxdtrRtrctu4E2vEuYMQYETJM9NxXRhsWT0Zm7ei9jLizAtlFmZ8ZS2N9a9G4dZAs27fLKqH/AExXl+F+O6G+9dSfRXLn/wDNem8OuTbQ+lUWmJLo87GHIYqfuyvupg/WiWBw85t9FJ0BO2usbCOewqDiD5b95el25H+sxV3g2PW3dR3+DVXA1ORwVfTn4SarQvI2/ZbB2cThmt3EVihOUkDMgcbq241E6U3GY/JaIxKC4HDWma0e6uC4oKslxZGZTBIbaI01rL8E4rdtXAbIJJ0IgsHHQoP01pMVh3NyChV7jaKVdTLEfj13PU89aT4/sEoYfGXbLFrbFZ3EAg+qnQ/nUmK7VXipC21DH7wkj/RP60mOw7IWVlIdCQyxsRUPZ9D38sPAAZkabafWrK70LKMWrasy/EsXnJa6XuPEDMAgH+k/SBUvD+M2bSrFtywABMqRP3iAdpJPnRPtPhbYuMVgA7x89vWs1avqh1VXHRgD9aSVwl2WSjKHRoF7T2GPiRh0JAMfI1DjeO4cxCsw8hEeXiNBLuJtMdLKqf8AE35CBUZy7lRr0kD2Arvkm+mhV48O6f8AZvMMsxNQceFxQhtll0ILqoYLto2hKg9QOUc6vYe1rNEUqs1yVGaH1lZk+N37eIsWbiRKFkdAwzIWEAk8hK6EjmPStjhuHWMXYtd4oYKiEZWIKHKAVkH6HpS3sKl22UcGDGxggjUEEc6XgnALdq53guXWP8zabRrlAzehkTy2qTi07Kc1xparos4XsXY7wMz3HQR4GIIMci0SV8vrW1tkASYAHsB+1DrDVX47gHvratqzC2bn2uUxNvKx16iQB6kVKQluT2xvbK2tyyFV17wQwQEZmSQGgbxqprDHCMIYqSsieUj1/Xzo32g7OnDL3lq4e7mMrfEpjQK25EA+00PwPGbiQLYZrmuVgFJWYmMw0Gg+VGLpGmEVqmR23a3mW4UtI4MC5m5kaCATyGp5VWucNuOGNtO8Ubta8Y/9dj5HWu4jhmLr3umciRqWBYwZDDSTJqK8xwQ0cqzBmQAmHBAgXCNivjAA5yZFdzrou/GcttlK9b/OrHZ94d9YnIJ+Z/aqL9phcb7SytwtuVZhcDcmDtMnnBkH60SwV/DKmlxnJILAd0uSNNc1yGHmPeKHNMmsEr1s7hFsNdfMuYZYI6lmL6/OiF7BWrRZ0WG3XUALoZ/TrVLCGyGLLibUmAUd0U8gIYMVb5irfFMFcCM2XMDMlSGAHnlmPemVWJOEoraM5wrD57hDTqZPrNeh8OwuW2qq8gaa6nf9JrB4C5kaQuY+Rj/7WiwHaBrblbqhAVZgWn4guk+RiKZx2SvRm+LXM+Iusk5TcaJWDE8xv5waTCuCR056imPdl82UqrnkTGnmTqCR7GrWHw4YNrDAFgTMNA1XyPTTWqpC8qDdoqbhe1ChcrBehAEx5Zp+lHOM8cZr1t3wrG1acOlwK+YwZJDMAuUwPD5b1j7DsgDgMIOjCR4hroetGMB2m7vV0a68HxvceQTIgAkjbmI9DSygcmRvxZLmLNxGfM52u5ABsAsg6iNp2jnvTOPMyqWcrbH+JR+RM+1WEt4bFobhti3ckhskEE6EEgiDvroNZoPj+HpaBLKuRfFK5QDqNwdj5c6pFSjEKnG69mZx94NAYsSRImfY5V115azVO/atqObH1I6+WkdCOdX8Hhg83G3JOjE7dJ6Roaj4jggo8Jqbg2uRpUknxBF3INs3L0/T8qhLn09T+lLdtkSSfadffpThhpXMCBrGvv5Vmak+ix6Xaar2FfMcoEkjpPuKztjEKVzbETmXmpHxLHl/W9WBilQZiwCjck6D39xWxNP2ebtM0llzy2G9EcNe5aVnrGLYAqZAMEj6g/X61ZOPt217xzEQJgk+IgQANTJjQVzWhfdGmXFKsZmAkwJIEnoJ56USsXa8545i0vslhbYvOj52UsQi5VaA7DQZiQuXmJ8jWn4VfuJbHe3M7nUkKqgT9xQOQ21JNQcLejnSVhLi9u5iPsFXLbmXuMOnJBz9ak4JwW1a7zLJObLmaJICrMRsM+bSn4bGq2xmqj8YSzhWvXAcozPAgk95cJUAjTXMNfPWkcWtD87VIB9pMRbF5VYAqDly+FjK+JjAJyyGHQ6isp22b7RpJa2pi2Zkrpz9TO86RtpU3EcW3eHRTfu+JlUSy7ELmjYKp00JBBPnb4lwVr1tbhBFxYGVSMxAAgNy0Gg18uQrpxdWbvGlScZPvowzYcMrEaZQST8MidAeunT9abgnAuIFXvCdkFuW2k7SSSNgOusUWxFxbXhuAgMCjDQMvwlSQJ10+nlVK9hO6sM6GWYISwJmHdwoHRYST1zL0rPyNksfHf47I8SuJtsXWzdthdZ+0IUfiJmF9xVnhPaJ0dmfxMR/3BCuokT9oIIEaTqdvSguCxT27gdHYOCDI6j89tqK8fyFlxCIii6oLqB4VuRLFV2AaJj9CKNiJtfZG77MY/CYy8v93fjdnlXOsE+EZmkRMgnTc1f45dPfFLiCAAIIBEbhgTupk15nwks90FT3aZlJKgwoQjxkjXwnL0BMe3qGHxyY7vEbX/x3SNUu87bEaMjQxHTUbjW+HIoyuRm8nx5Zcf117/Zh8bhMozbox0201OhjT0P5U/D3pAnU6e5okbeVrli4ApQTlP3hIUgEcwTO+2ooNdw5UtlByhjEGSOevPnWxpdo86NvUgmMW6LlAHUaa68j+MSDo0iqmJuF8sIoLTAU/H1gA6EdPpUNvHFgZgwNTEyNj85oaMT3V0XCA5UmH5qCCD4R8QE7+e1JOVFYQZqsAhw9pi3xE5o9gAv70C4jinxFwWwSFkE6aCAcx8tyBO9Jex7XmCISxMnMSACAdNhy029hV3DYdbWZjqzeew5KPIfWOVUS5Kl0KkoPk+xmIs2ipXIFMjxpKuYEQWB1HrO1B7/D7uXMrllmPEI13jMBvHLSruJuQ5SYI1g7x1iuGKcqLakkMwOUc22Hqf3866UYMrByQHxVl0KJeQICCVOWC4JBBLfeUHn6iqaXyDJ2I015Ax7bHSruLIcmSAACBPM8z8wB7GhjoSAf6O+sVkncXo1xlfZqrmLsqzd5lzjKDKiSIBBGmoI19xQe/aNzOLSQhaQdR+Gd4BEgwD+LlUV3GW2ZiykFiCTAJAAACjz01olh+N2QsQyxoARPvIO+1d9Zak0Z1Fx2kS4XFXra+FA43bkdgORMgADlsKdjuMXO4zxbyucsS5Y7zr4YiPyqu3aNRIVTHoo/+Gh/EOI27gMIQ0gySI030HWTt5UZyiotRkKoXK3E3PBVRLYyGQ3iLk6uTuxPWi9vFxXluEx7WyTZZ1ndCoZdPMnX5A0Su9qbsBciq3NtT7hTt7k1SGeCjshk8ablaZuuJcaa3bhI7y4RbQfzNpm9AJNDMThntYdka+xQjx3LjNkTxKIS0ozOdABJiD7VhhjWe6HuZnE+KNCV6CNF06R+ta7D4w38oACpcOUgnNcdBq5cz4VgZeZlhtS81Nt1+hviljS3+yDguLFphcsOrnxd8bgJfKfhtrIIWY1O5PlAoZxPtRiGfw3GQajwM66TP4jHtFFMZ9kpQAIsmAF09QBvI9d6yuJaTML0+GNucRvWaal7PVvHGC49vtj/APiTs+a6xuDWQ/iIH8ubYjpWs4ayX7XdO6r3ttVtu2wuoVKITyzFXWep+eICyI25mYj6a1ouy91WR7F3KUOp01VSdXU7+A+LTkTUa2mGOT6uL9oCPhWtXTbuAqwMMDv/AEa0HanC91Yw1ttLrG5cdBByKwtLaUgbGFJjfxVewfZ2411LjYm21q3/AHjOCUVTmEzOw130A25UC7QOrYiUZnVmKqzMS0DLDTyZvjPTMByp3VCRuqKfDeIvacaAKQyN0IMqT7ST9aKdm+L9wTcX4lZQGzNLAzmJUmG+6Yg1nApiSNJ1g6+UfXXyNSTLBQBOwC6yDrHUk/OgmdGTR6f2nhzauqYzqyEqYOa02UkE+WUCeQFZfD5rVzIzF1ecrNuGG4PXTb0o5w+8cVgrZBGewYgkeNbkAAdXzpoOeaOgrE8YxQcgKpkaE7j2HLc9K2LIlBSXaMWTE/karT2HMXh2B7y2YYakD8x51ADbMtdtkuQIYHKNtyuxP70At8RcQCS3kTt6Gfzp1zFuR95FPQT9ZFF54vdHRxyjpss3SqXctphBE6g+E7lQJ096lbitwAgw2vxamPLz+dCrd5QwOUwOfMnr5c9qt3eIKToGA5gwZHMedJDJp7oq4X2rFewxYMsOIAAGnoIB1HKKdZuWwuVoUgagrz57/OqffBfgc+Q1BHlThiwT4hPLb8q5SjF2u/7QeJPi1Urm1klcsaDLHPpy5U3CIWJAjT8TBfqfyqG5iZUIFGg0JmSPaq2Qnc0kp/a0UtVQ9FjofWnsF/CPr+9VvWRTw39b1OMlXQjRbt4y2v8AcqT5kx8jNQ3Lgc7BR0AApFCcwffSfkDU/c2ysic3TUj0jc+ulNbYNINcAsIJaBMaHcig/FrbC88g6sSIHLyqSxcUDwsQJ13gdCdJAo9gr8AeJG00kiPnWhKM4V1RCTcJ33ZmrOGdjkC+KM2ukAc6scKzowuIpYgGIVmhvPLHIkb9dKnw+NRbxaWYsQIEAEnzJ2kxWi4bwLFoAjYdUWYUm5bkseR8XiJ306eVSio8lsaUpJPQJtcY0K4hGDz4XIYxtsp2Gmw/3olwjs1dxxm0ALZ0N0ghByMaeJtNhr1jeqWLxtps1toYCZ2jw8wZ+RFbDtB2ia3grdq0rC49q2hCg/ZgovefCIXU5dNjm5imyS4rTTBC26pr/hnnweFF5rVpRct2wy964lr1yRmcH7tsRlUDzMmaXhuHtWb4OQJmDANmZ015FW5gwfas3g7uIBXwXCoOwQwdZjNEjeit7CG7lLLdVm2U5gZ6BSN/SjDjKFezpuUZ3eizhciviCFBzRbU6ajTMTIk6J0Hxe1VmwiZswO5BAMkLrqevp689BVLE4W9aaAWECSjqVMcjlI59fKtFwqzabh2Kvuk3bbBVbxABfAZC7TLHXX2o8IKNSQ3yT5covRmMdaVXhzIaYcaZhqVO24mNfKhb2irSOvh1E6bUXOLtnRxmU/dMz7c5objrOV41AO0zttz1ifpWWcFCVJ2jUp848qphy3jQMLeCqPH3RHLKTcLMP8AVb096H8XYXXa6sQ0F9QDnOjNHOTqTG5pmHweIupltWbtwIRraRnGY66lRoYM0y5iF7sIyshzOWI2zQF8IMRzDDyXXoFKjpS5aKL2WH3T8jRzDqO7VHGsbGrfDeHXb9kNZtXLmXSURm88pKiMwn1g+lDL93KxWdRIYDlG8nlWzGoR+19mWdvRQxFpVbQ7e9I94EDwieoAE+1OCKdf319zptTXVddD9fy/3qLtdVRRDQVJHhHn+9OuKOQAqIsOU+9Rk+etI5qug0OZI5j0FRmpFU+YFJMbGp9hHgTSNbgT+VTN1qHPJ1p2khU2cls9aI2rKxrrVJQ33dvOpkRubH20+tUx69CT37JbiBWDcifF6HrV0WkIgqPeD8qpm0IIjfSdz86ZYvkeE7iqKk6fsm7a16LFy4lrVVEn5xoNPn9DW77D8f7+21q4NbY8BOpykaCT6FfQgcq8+xdnNDDWOXWiPZS+UxCqAAboe3PLM48Ok6gNFJO7r0PFJxv2RcP4ZOKKXBmS0Xa4eq2jqv8AmOVf8wrUcF4kTxPNcPht2ruc8h95xA6MTTOIBbWa4hE3yrnqLdpV0P8Ajuwf8tAuzOIP8RdfMR9lc8UxHwgQd5mKgl6Kt3FsKcbu4tMW6WxfKjJBi6RLKrEkLpuToAB8oqzgeJX3xeDGJLk27jFS6urMCVLAZtx4AAOU+Yqtxbi+ItuqribvwK5+2u6Fi0KPHGgAqrwTEl8ZZZ2JYuCSTsACfbmfcmrQjq2Sk90aXtO38TauOHz3sMzEkgBmsXGDZSBubeZGHkWG80I4Vc/6ZjB1adPLuT+U1WxfFWsY666aqXhhvmWACAOZgsB61fxGHW3g74Qju7gd7eu6sLcD/Kcw9ADzrrqNB47Kd9Dg8IjIYv3gpZ48ah1DpaQkeAZCCx5kwfhFR9nrv8QWsYli9llEZvitMzBBdQn4SpIJ5Eb86b2ovd5hbN1dmuXGcA/CbihlX5K1V+xgg3rjfAtsKTHN7luB6+H6ik0xukaHsi7YS3i7OYi73pCsBIJtJmE7SrTH+as92quLlQoo7u8RfVpmDGW5bjmQxgk6yu1G+FcQ73F3SNjfGXzAtsD9LYNVcBZt4iwLbkA2G71tfuqYugevg88ztS1ofabZpexx/hrNqzKhmBvXVnWbgi0m/Rc3oD5V5ljYLkDmxJjpJrY8CxneYm7cJ3u2wNo8Nu7oP5dDHlFYpxLOTzYiPIE1TH1ROXdkptgAQNqp37fQ71KR0JHvp8jUDlus082qqhY3fZDHKnhNaSYFPVpqMVEq2xNxr/8AfenG2Bv7elIzEVx13rq9AsQkmQNKQLH6/tUlyCSRprprOnrUdwnnpNBr2FFhCBtUgaq1rapA1XhLRGS2WA9Mu251Bg/nTC0b0zvSdtKZyi9MEYvtEi3iNDoevI061eGdWmCCu22hned6iUqBqZriR91Y8/2pG/Q9bDvErji2SzfdW3bEbKATA88zMT5zQ7hltBn7wNlYBYSJ0IeddtUXToTtS3r5aC0aDYbTzOvM/sNhUZeujjXcgSyOqRob/FsO2WcOpIVVzMmacoAWQbmXl0qm2Otl1PwBbdz4EVDndSgChNAdQZn5UIL1G7UzjEWMpFnF32u3GcIQSMxCy0BVALEgbaSTyq6vF3uWLltwxyqcrKDEMyE5wug+Ewx6kVY7M3ItY0TocO30VyKj4LdP8DjVn/xGPeD9BU5P0VXdlXhnFVRGtXED2m3U6wZmRBBDfzAz5EaVPjeOILa27Nk2rczEkh2GneMx1dhqBrA3iaARRK/cVLfd6EtlnyiTp7k/SklQ8Y3djeHY0W90JOYMpDZcukGNDuDr7bVJc4s2dmEQc2UA6jMcwk88ukVQCldGAII29eXkfSmgry0pox0K20aPs3ZeFJEKbqkz/KjKup/muR5kxQO/8bf4m/M02xintmbbkag76SDI02METqKZ3uYknckk+c6zTR0wS2LNNNOpDFO2TIGpgkVzbmnRWftlx2fSkDGmk0haubYKJGpb1wtE8qiJpDXNnJEoeuLmowacGrrYKHAdTUqmq+anq1NFpAaH5df2rig9DTWYcq7vKa0dTFysOdOS7yPzpmemsZoX+DqvsmL1GblR5q4mg52coh3gF4C3iZ3NtgPdLm/lTuFX1/hsSDuRb39W1J9SPnQO2TrlJHIxOx3BjlT7blQSGMnSBMH160jY6RNayp42gyDlAPPrqNKgysxJ2mTTUEmTUt/SAPX9P3ro17Gk9aGADmZpSB/RqPNXZqryRKmTZYG29MYf7UzOdqSaDaYaHAkc6ksXwpkqG02O3rUINNJpG6OocRJp06VEGpZrk0GhZpKWabQCJXV1dQCdXV1dXAOpa6urgnVxpa6iASkrq6gE6urq6uAKjEHSnHeurqATl511zf2H6V1dXHEddXV1A4WlmurqdHCUldXUrOOpRXV1A46urq6iA//Z",
            },
        ]

        const Effectdata = [
            {
                name: "nike shoes",
                img: img1,
                size: [7, 8, 9, 10],
                color: ["9bdc28", "03a9f4", "e91e63"]
            },
            {
                name: "nike shoes",
                img: img2,
                size: [7, 8, 9, 10],
                color: ["9bdc28", "03a9f4", "e91e63"]
            },
            {
                name: "nike shoes",
                img: img3,
                size: [7, 8, 9, 10],
                color: ["9bdc28", "03a9f4", "e91e63"]
            },
            {
                name: "nike shoes",
                img: img1,
                size: [7, 8, 9, 10],
                color: ["9bdc28", "03a9f4", "e91e63"]
            }
        ]

        const mediaIcon = [
            {
                viewBox: "0 0 320 512",
                svgpath: "M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
            },
            {
                viewBox: "0 0 512 512",
                svgpath: "M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"
            },
            {
                viewBox: "0 0 448 512",
                svgpath: "M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
            },
            {
                viewBox: "0 0 448 512",
                svgpath: "M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"
            },
            {
                viewBox: "0 0 448 512",
                svgpath: "M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"
            }
        ]


        const HeaderNavigationDatas = [
            {
                svgpath: "M192 176C192 202.5 170.5 224 144 224H48C21.49 224 0 202.5 0 176V80C0 53.49 21.49 32 48 32H144C170.5 32 192 53.49 192 80V176zM192 432C192 458.5 170.5 480 144 480H48C21.49 480 0 458.5 0 432V336C0 309.5 21.49 288 48 288H144C170.5 288 192 309.5 192 336V432zM256 80C256 53.49 277.5 32 304 32H400C426.5 32 448 53.49 448 80V176C448 202.5 426.5 224 400 224H304C277.5 224 256 202.5 256 176V80zM448 432C448 458.5 426.5 480 400 480H304C277.5 480 256 458.5 256 432V336C256 309.5 277.5 288 304 288H400C426.5 288 448 309.5 448 336V432z",
                viewBox: "0 0 448 512",
                linkname: "Dashboard",
                submenu: [

                ]
            },
            {
                linkname: "Category",
                svgpath: "M32 32C49.67 32 64 46.33 64 64V400C64 408.8 71.16 416 80 416H480C497.7 416 512 430.3 512 448C512 465.7 497.7 480 480 480H80C35.82 480 0 444.2 0 400V64C0 46.33 14.33 32 32 32zM128 128C128 110.3 142.3 96 160 96H352C369.7 96 384 110.3 384 128C384 145.7 369.7 160 352 160H160C142.3 160 128 145.7 128 128zM288 192C305.7 192 320 206.3 320 224C320 241.7 305.7 256 288 256H160C142.3 256 128 241.7 128 224C128 206.3 142.3 192 160 192H288zM416 288C433.7 288 448 302.3 448 320C448 337.7 433.7 352 416 352H160C142.3 352 128 337.7 128 320C128 302.3 142.3 288 160 288H416z",
                viewBox: "0 0 512 512",
                submenu: [
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "HTML & CSS",
                        subchildmenu: []
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "JavaScript",
                        subchildmenu: []
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "PHP & MySQL",
                        subchildmenu: []
                    }
                ]
            },
            {
                linkname: "Posts",
                svgpath: "M147.8 192H480V144C480 117.5 458.5 96 432 96h-160l-64-64h-160C21.49 32 0 53.49 0 80v328.4l90.54-181.1C101.4 205.6 123.4 192 147.8 192zM543.1 224H147.8C135.7 224 124.6 230.8 119.2 241.7L0 480h447.1c12.12 0 23.2-6.852 28.62-17.69l96-192C583.2 249 567.7 224 543.1 224z",
                viewBox: "0 0 576 512",
                submenu: [
                    {
                        subtitleName: "Web Design",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subchildmenu: [
                            {
                                childname: "React js"
                            },
                            {
                                childname: "vue js"
                            },
                            {
                                childname: "angular js"
                            }
                        ]
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "Login Form",
                        subchildmenu: [
                            {
                                childname: "React js",
                                svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                                viewBox: "0 0 512 512",
                            },
                            {
                                childname: "vue js",
                                svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                                viewBox: "0 0 512 512",
                            },
                            {
                                childname: "angular js",
                                svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                                viewBox: "0 0 512 512",
                            }
                        ]
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "Card Design",
                        subchildmenu: []
                    }
                ]
            },
            {
                linkname: "Analytics",
                svgpath: "M304 16.58C304 7.555 310.1 0 320 0C443.7 0 544 100.3 544 224C544 233 536.4 240 527.4 240H304V16.58zM32 272C32 150.7 122.1 50.34 238.1 34.25C248.2 32.99 256 40.36 256 49.61V288L412.5 444.5C419.2 451.2 418.7 462.2 411 467.7C371.8 495.6 323.8 512 272 512C139.5 512 32 404.6 32 272zM558.4 288C567.6 288 575 295.8 573.8 305C566.1 360.9 539.1 410.6 499.9 447.3C493.9 452.1 484.5 452.5 478.7 446.7L320 288H558.4z",
                viewBox: "0 0 576 512",
                submenu: [
                    {
                        // 
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "HTML & CSS",
                        subchildmenu: []
                    }
                ]
            },
            {
                linkname: "Chart",
                svgpath: "M64 400C64 408.8 71.16 416 80 416H480C497.7 416 512 430.3 512 448C512 465.7 497.7 480 480 480H80C35.82 480 0 444.2 0 400V64C0 46.33 14.33 32 32 32C49.67 32 64 46.33 64 64V400zM342.6 278.6C330.1 291.1 309.9 291.1 297.4 278.6L240 221.3L150.6 310.6C138.1 323.1 117.9 323.1 105.4 310.6C92.88 298.1 92.88 277.9 105.4 265.4L217.4 153.4C229.9 140.9 250.1 140.9 262.6 153.4L320 210.7L425.4 105.4C437.9 92.88 458.1 92.88 470.6 105.4C483.1 117.9 483.1 138.1 470.6 150.6L342.6 278.6z",
                viewBox: "0 0 512 512",
                submenu: [
                    {
                        // 
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "HTML & CSS",
                        subchildmenu: []
                    }
                ]
            },
            {
                linkname: "Plugins",
                svgpath: "M96 0C113.7 0 128 14.33 128 32V128H64V32C64 14.33 78.33 0 96 0zM288 0C305.7 0 320 14.33 320 32V128H256V32C256 14.33 270.3 0 288 0zM352 160C369.7 160 384 174.3 384 192C384 209.7 369.7 224 352 224V256C352 333.4 297 397.1 224 412.8V512H160V412.8C86.97 397.1 32 333.4 32 256V224C14.33 224 0 209.7 0 192C0 174.3 14.33 160 32 160H352z",
                viewBox: "0 0 384 512",
                submenu: [
                    {
                        subtitleName: "UI Face",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subchildmenu: []
                    },
                    {
                        subtitleName: "Pigments",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subchildmenu: []
                    },
                    {
                        subtitleName: "Box Icons",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subchildmenu: []
                    }
                ]
            },
        ]
        const HeaderNavigationLogo = {
            svgpath: "M418.2 177.2c-5.4-1.8-10.8-3.5-16.2-5.1.9-3.7 1.7-7.4 2.5-11.1 12.3-59.6 4.2-107.5-23.1-123.3-26.3-15.1-69.2.6-112.6 38.4-4.3 3.7-8.5 7.6-12.5 11.5-2.7-2.6-5.5-5.2-8.3-7.7-45.5-40.4-91.1-57.4-118.4-41.5-26.2 15.2-34 60.3-23 116.7 1.1 5.6 2.3 11.1 3.7 16.7-6.4 1.8-12.7 3.8-18.6 5.9C38.3 196.2 0 225.4 0 255.6c0 31.2 40.8 62.5 96.3 81.5 4.5 1.5 9 3 13.6 4.3-1.5 6-2.8 11.9-4 18-10.5 55.5-2.3 99.5 23.9 114.6 27 15.6 72.4-.4 116.6-39.1 3.5-3.1 7-6.3 10.5-9.7 4.4 4.3 9 8.4 13.6 12.4 42.8 36.8 85.1 51.7 111.2 36.6 27-15.6 35.8-62.9 24.4-120.5-.9-4.4-1.9-8.9-3-13.5 3.2-.9 6.3-1.9 9.4-2.9 57.7-19.1 99.5-50 99.5-81.7 0-30.3-39.4-59.7-93.8-78.4zM282.9 92.3c37.2-32.4 71.9-45.1 87.7-36 16.9 9.7 23.4 48.9 12.8 100.4-.7 3.4-1.4 6.7-2.3 10-22.2-5-44.7-8.6-67.3-10.6-13-18.6-27.2-36.4-42.6-53.1 3.9-3.7 7.7-7.2 11.7-10.7zM167.2 307.5c5.1 8.7 10.3 17.4 15.8 25.9-15.6-1.7-31.1-4.2-46.4-7.5 4.4-14.4 9.9-29.3 16.3-44.5 4.6 8.8 9.3 17.5 14.3 26.1zm-30.3-120.3c14.4-3.2 29.7-5.8 45.6-7.8-5.3 8.3-10.5 16.8-15.4 25.4-4.9 8.5-9.7 17.2-14.2 26-6.3-14.9-11.6-29.5-16-43.6zm27.4 68.9c6.6-13.8 13.8-27.3 21.4-40.6s15.8-26.2 24.4-38.9c15-1.1 30.3-1.7 45.9-1.7s31 .6 45.9 1.7c8.5 12.6 16.6 25.5 24.3 38.7s14.9 26.7 21.7 40.4c-6.7 13.8-13.9 27.4-21.6 40.8-7.6 13.3-15.7 26.2-24.2 39-14.9 1.1-30.4 1.6-46.1 1.6s-30.9-.5-45.6-1.4c-8.7-12.7-16.9-25.7-24.6-39s-14.8-26.8-21.5-40.6zm180.6 51.2c5.1-8.8 9.9-17.7 14.6-26.7 6.4 14.5 12 29.2 16.9 44.3-15.5 3.5-31.2 6.2-47 8 5.4-8.4 10.5-17 15.5-25.6zm14.4-76.5c-4.7-8.8-9.5-17.6-14.5-26.2-4.9-8.5-10-16.9-15.3-25.2 16.1 2 31.5 4.7 45.9 8-4.6 14.8-10 29.2-16.1 43.4zM256.2 118.3c10.5 11.4 20.4 23.4 29.6 35.8-19.8-.9-39.7-.9-59.5 0 9.8-12.9 19.9-24.9 29.9-35.8zM140.2 57c16.8-9.8 54.1 4.2 93.4 39 2.5 2.2 5 4.6 7.6 7-15.5 16.7-29.8 34.5-42.9 53.1-22.6 2-45 5.5-67.2 10.4-1.3-5.1-2.4-10.3-3.5-15.5-9.4-48.4-3.2-84.9 12.6-94zm-24.5 263.6c-4.2-1.2-8.3-2.5-12.4-3.9-21.3-6.7-45.5-17.3-63-31.2-10.1-7-16.9-17.8-18.8-29.9 0-18.3 31.6-41.7 77.2-57.6 5.7-2 11.5-3.8 17.3-5.5 6.8 21.7 15 43 24.5 63.6-9.6 20.9-17.9 42.5-24.8 64.5zm116.6 98c-16.5 15.1-35.6 27.1-56.4 35.3-11.1 5.3-23.9 5.8-35.3 1.3-15.9-9.2-22.5-44.5-13.5-92 1.1-5.6 2.3-11.2 3.7-16.7 22.4 4.8 45 8.1 67.9 9.8 13.2 18.7 27.7 36.6 43.2 53.4-3.2 3.1-6.4 6.1-9.6 8.9zm24.5-24.3c-10.2-11-20.4-23.2-30.3-36.3 9.6.4 19.5.6 29.5.6 10.3 0 20.4-.2 30.4-.7-9.2 12.7-19.1 24.8-29.6 36.4zm130.7 30c-.9 12.2-6.9 23.6-16.5 31.3-15.9 9.2-49.8-2.8-86.4-34.2-4.2-3.6-8.4-7.5-12.7-11.5 15.3-16.9 29.4-34.8 42.2-53.6 22.9-1.9 45.7-5.4 68.2-10.5 1 4.1 1.9 8.2 2.7 12.2 4.9 21.6 5.7 44.1 2.5 66.3zm18.2-107.5c-2.8.9-5.6 1.8-8.5 2.6-7-21.8-15.6-43.1-25.5-63.8 9.6-20.4 17.7-41.4 24.5-62.9 5.2 1.5 10.2 3.1 15 4.7 46.6 16 79.3 39.8 79.3 58 0 19.6-34.9 44.9-84.8 61.4zm-149.7-15c25.3 0 45.8-20.5 45.8-45.8s-20.5-45.8-45.8-45.8c-25.3 0-45.8 20.5-45.8 45.8s20.5 45.8 45.8 45.8z",
            viewBox: "0 0 512 512",
            name: "CodingLab"
        }


        const navData = [
            {
                svgpath: "M192 176C192 202.5 170.5 224 144 224H48C21.49 224 0 202.5 0 176V80C0 53.49 21.49 32 48 32H144C170.5 32 192 53.49 192 80V176zM192 432C192 458.5 170.5 480 144 480H48C21.49 480 0 458.5 0 432V336C0 309.5 21.49 288 48 288H144C170.5 288 192 309.5 192 336V432zM256 80C256 53.49 277.5 32 304 32H400C426.5 32 448 53.49 448 80V176C448 202.5 426.5 224 400 224H304C277.5 224 256 202.5 256 176V80zM448 432C448 458.5 426.5 480 400 480H304C277.5 480 256 458.5 256 432V336C256 309.5 277.5 288 304 288H400C426.5 288 448 309.5 448 336V432z",
                viewBox: "0 0 448 512",
                linkname: "Dashboard",
                submenu: []
            },
            {
                linkname: "Category",
                svgpath: "M32 32C49.67 32 64 46.33 64 64V400C64 408.8 71.16 416 80 416H480C497.7 416 512 430.3 512 448C512 465.7 497.7 480 480 480H80C35.82 480 0 444.2 0 400V64C0 46.33 14.33 32 32 32zM128 128C128 110.3 142.3 96 160 96H352C369.7 96 384 110.3 384 128C384 145.7 369.7 160 352 160H160C142.3 160 128 145.7 128 128zM288 192C305.7 192 320 206.3 320 224C320 241.7 305.7 256 288 256H160C142.3 256 128 241.7 128 224C128 206.3 142.3 192 160 192H288zM416 288C433.7 288 448 302.3 448 320C448 337.7 433.7 352 416 352H160C142.3 352 128 337.7 128 320C128 302.3 142.3 288 160 288H416z",
                viewBox: "0 0 512 512",
                submenu: [
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "HTML & CSS",
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "JavaScript",
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "PHP & MySQL",
                    }
                ]
            },
            {
                linkname: "Posts",
                svgpath: "M147.8 192H480V144C480 117.5 458.5 96 432 96h-160l-64-64h-160C21.49 32 0 53.49 0 80v328.4l90.54-181.1C101.4 205.6 123.4 192 147.8 192zM543.1 224H147.8C135.7 224 124.6 230.8 119.2 241.7L0 480h447.1c12.12 0 23.2-6.852 28.62-17.69l96-192C583.2 249 567.7 224 543.1 224z",
                viewBox: "0 0 576 512",
                submenu: [
                    {
                        subtitleName: "Web Design",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "Login Form",
                    },
                    {
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                        subtitleName: "Card Design",
                    }
                ]
            },
            {
                linkname: "Analytics",
                svgpath: "M304 16.58C304 7.555 310.1 0 320 0C443.7 0 544 100.3 544 224C544 233 536.4 240 527.4 240H304V16.58zM32 272C32 150.7 122.1 50.34 238.1 34.25C248.2 32.99 256 40.36 256 49.61V288L412.5 444.5C419.2 451.2 418.7 462.2 411 467.7C371.8 495.6 323.8 512 272 512C139.5 512 32 404.6 32 272zM558.4 288C567.6 288 575 295.8 573.8 305C566.1 360.9 539.1 410.6 499.9 447.3C493.9 452.1 484.5 452.5 478.7 446.7L320 288H558.4z",
                viewBox: "0 0 576 512",
                submenu: []
            },
            {
                linkname: "Chart",
                svgpath: "M64 400C64 408.8 71.16 416 80 416H480C497.7 416 512 430.3 512 448C512 465.7 497.7 480 480 480H80C35.82 480 0 444.2 0 400V64C0 46.33 14.33 32 32 32C49.67 32 64 46.33 64 64V400zM342.6 278.6C330.1 291.1 309.9 291.1 297.4 278.6L240 221.3L150.6 310.6C138.1 323.1 117.9 323.1 105.4 310.6C92.88 298.1 92.88 277.9 105.4 265.4L217.4 153.4C229.9 140.9 250.1 140.9 262.6 153.4L320 210.7L425.4 105.4C437.9 92.88 458.1 92.88 470.6 105.4C483.1 117.9 483.1 138.1 470.6 150.6L342.6 278.6z",
                viewBox: "0 0 512 512",
                submenu: []
            },
            {
                linkname: "Plugins",
                svgpath: "M96 0C113.7 0 128 14.33 128 32V128H64V32C64 14.33 78.33 0 96 0zM288 0C305.7 0 320 14.33 320 32V128H256V32C256 14.33 270.3 0 288 0zM352 160C369.7 160 384 174.3 384 192C384 209.7 369.7 224 352 224V256C352 333.4 297 397.1 224 412.8V512H160V412.8C86.97 397.1 32 333.4 32 256V224C14.33 224 0 209.7 0 192C0 174.3 14.33 160 32 160H352z",
                viewBox: "0 0 384 512",
                submenu: [
                    {
                        subtitleName: "UI Face",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                    },
                    {
                        subtitleName: "Pigments",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                    },
                    {
                        subtitleName: "Box Icons",
                        svgpath: "M447.8,64H64c-23.6,0-42.7,19.1-42.7,42.7v63.9H64v-63.9h383.8v298.6H298.6V448H448c23.6,0,42.7-19.1,42.7-42.7V106.7 C490.7,83.1,471.4,64,447.8,64z M21.3,383.6L21.3,383.6l0,63.9h63.9C85.2,412.2,56.6,383.6,21.3,383.6L21.3,383.6z M21.3,298.6V341 c58.9,0,106.6,48.1,106.6,107h42.7C170.7,365.6,103.7,298.7,21.3,298.6z M213.4,448h42.7c-0.5-129.5-105.3-234.3-234.8-234.6l0,42.4 C127.3,255.6,213.3,342,213.4,448z",
                        viewBox: "0 0 512 512",
                    }
                ]
            },
            {
                linkname: "Explore",
                svgpath: "M384 320c-17.67 0-32 14.33-32 32v96H64V160h96c17.67 0 32-14.32 32-32s-14.33-32-32-32L64 96c-35.35 0-64 28.65-64 64V448c0 35.34 28.65 64 64 64h288c35.35 0 64-28.66 64-64v-96C416 334.3 401.7 320 384 320zM488 0H352c-12.94 0-24.62 7.797-29.56 19.75c-4.969 11.97-2.219 25.72 6.938 34.88L370.8 96L169.4 297.4c-12.5 12.5-12.5 32.75 0 45.25C175.6 348.9 183.8 352 192 352s16.38-3.125 22.62-9.375L416 141.3l41.38 41.38c9.156 9.141 22.88 11.84 34.88 6.938C504.2 184.6 512 172.9 512 160V24C512 10.74 501.3 0 488 0z",
                viewBox: "0 0 512 512",
                submenu: []
            },
            {
                linkname: "History",
                svgpath: "M256 0C397.4 0 512 114.6 512 256C512 397.4 397.4 512 256 512C201.7 512 151.2 495 109.7 466.1C95.2 455.1 91.64 436 101.8 421.5C111.9 407 131.8 403.5 146.3 413.6C177.4 435.3 215.2 448 256 448C362 448 448 362 448 256C448 149.1 362 64 256 64C202.1 64 155 85.46 120.2 120.2L151 151C166.1 166.1 155.4 192 134.1 192H24C10.75 192 0 181.3 0 168V57.94C0 36.56 25.85 25.85 40.97 40.97L74.98 74.98C121.3 28.69 185.3 0 255.1 0L256 0zM256 128C269.3 128 280 138.7 280 152V246.1L344.1 311C354.3 320.4 354.3 335.6 344.1 344.1C335.6 354.3 320.4 354.3 311 344.1L239 272.1C234.5 268.5 232 262.4 232 256V152C232 138.7 242.7 128 256 128V128z",
                viewBox: "0 0 512 512",
                submenu: []
            },
            {
                linkname: "Setting",
                svgpath: "M495.9 166.6C499.2 175.2 496.4 184.9 489.6 191.2L446.3 230.6C447.4 238.9 448 247.4 448 256C448 264.6 447.4 273.1 446.3 281.4L489.6 320.8C496.4 327.1 499.2 336.8 495.9 345.4C491.5 357.3 486.2 368.8 480.2 379.7L475.5 387.8C468.9 398.8 461.5 409.2 453.4 419.1C447.4 426.2 437.7 428.7 428.9 425.9L373.2 408.1C359.8 418.4 344.1 427 329.2 433.6L316.7 490.7C314.7 499.7 307.7 506.1 298.5 508.5C284.7 510.8 270.5 512 255.1 512C241.5 512 227.3 510.8 213.5 508.5C204.3 506.1 197.3 499.7 195.3 490.7L182.8 433.6C167 427 152.2 418.4 138.8 408.1L83.14 425.9C74.3 428.7 64.55 426.2 58.63 419.1C50.52 409.2 43.12 398.8 36.52 387.8L31.84 379.7C25.77 368.8 20.49 357.3 16.06 345.4C12.82 336.8 15.55 327.1 22.41 320.8L65.67 281.4C64.57 273.1 64 264.6 64 256C64 247.4 64.57 238.9 65.67 230.6L22.41 191.2C15.55 184.9 12.82 175.3 16.06 166.6C20.49 154.7 25.78 143.2 31.84 132.3L36.51 124.2C43.12 113.2 50.52 102.8 58.63 92.95C64.55 85.8 74.3 83.32 83.14 86.14L138.8 103.9C152.2 93.56 167 84.96 182.8 78.43L195.3 21.33C197.3 12.25 204.3 5.04 213.5 3.51C227.3 1.201 241.5 0 256 0C270.5 0 284.7 1.201 298.5 3.51C307.7 5.04 314.7 12.25 316.7 21.33L329.2 78.43C344.1 84.96 359.8 93.56 373.2 103.9L428.9 86.14C437.7 83.32 447.4 85.8 453.4 92.95C461.5 102.8 468.9 113.2 475.5 124.2L480.2 132.3C486.2 143.2 491.5 154.7 495.9 166.6V166.6zM256 336C300.2 336 336 300.2 336 255.1C336 211.8 300.2 175.1 256 175.1C211.8 175.1 176 211.8 176 255.1C176 300.2 211.8 336 256 336z",
                viewBox: "0 0 512 512",
                submenu: []
            },
        ]

        const navLogo = {
            svgpath: "M418.2 177.2c-5.4-1.8-10.8-3.5-16.2-5.1.9-3.7 1.7-7.4 2.5-11.1 12.3-59.6 4.2-107.5-23.1-123.3-26.3-15.1-69.2.6-112.6 38.4-4.3 3.7-8.5 7.6-12.5 11.5-2.7-2.6-5.5-5.2-8.3-7.7-45.5-40.4-91.1-57.4-118.4-41.5-26.2 15.2-34 60.3-23 116.7 1.1 5.6 2.3 11.1 3.7 16.7-6.4 1.8-12.7 3.8-18.6 5.9C38.3 196.2 0 225.4 0 255.6c0 31.2 40.8 62.5 96.3 81.5 4.5 1.5 9 3 13.6 4.3-1.5 6-2.8 11.9-4 18-10.5 55.5-2.3 99.5 23.9 114.6 27 15.6 72.4-.4 116.6-39.1 3.5-3.1 7-6.3 10.5-9.7 4.4 4.3 9 8.4 13.6 12.4 42.8 36.8 85.1 51.7 111.2 36.6 27-15.6 35.8-62.9 24.4-120.5-.9-4.4-1.9-8.9-3-13.5 3.2-.9 6.3-1.9 9.4-2.9 57.7-19.1 99.5-50 99.5-81.7 0-30.3-39.4-59.7-93.8-78.4zM282.9 92.3c37.2-32.4 71.9-45.1 87.7-36 16.9 9.7 23.4 48.9 12.8 100.4-.7 3.4-1.4 6.7-2.3 10-22.2-5-44.7-8.6-67.3-10.6-13-18.6-27.2-36.4-42.6-53.1 3.9-3.7 7.7-7.2 11.7-10.7zM167.2 307.5c5.1 8.7 10.3 17.4 15.8 25.9-15.6-1.7-31.1-4.2-46.4-7.5 4.4-14.4 9.9-29.3 16.3-44.5 4.6 8.8 9.3 17.5 14.3 26.1zm-30.3-120.3c14.4-3.2 29.7-5.8 45.6-7.8-5.3 8.3-10.5 16.8-15.4 25.4-4.9 8.5-9.7 17.2-14.2 26-6.3-14.9-11.6-29.5-16-43.6zm27.4 68.9c6.6-13.8 13.8-27.3 21.4-40.6s15.8-26.2 24.4-38.9c15-1.1 30.3-1.7 45.9-1.7s31 .6 45.9 1.7c8.5 12.6 16.6 25.5 24.3 38.7s14.9 26.7 21.7 40.4c-6.7 13.8-13.9 27.4-21.6 40.8-7.6 13.3-15.7 26.2-24.2 39-14.9 1.1-30.4 1.6-46.1 1.6s-30.9-.5-45.6-1.4c-8.7-12.7-16.9-25.7-24.6-39s-14.8-26.8-21.5-40.6zm180.6 51.2c5.1-8.8 9.9-17.7 14.6-26.7 6.4 14.5 12 29.2 16.9 44.3-15.5 3.5-31.2 6.2-47 8 5.4-8.4 10.5-17 15.5-25.6zm14.4-76.5c-4.7-8.8-9.5-17.6-14.5-26.2-4.9-8.5-10-16.9-15.3-25.2 16.1 2 31.5 4.7 45.9 8-4.6 14.8-10 29.2-16.1 43.4zM256.2 118.3c10.5 11.4 20.4 23.4 29.6 35.8-19.8-.9-39.7-.9-59.5 0 9.8-12.9 19.9-24.9 29.9-35.8zM140.2 57c16.8-9.8 54.1 4.2 93.4 39 2.5 2.2 5 4.6 7.6 7-15.5 16.7-29.8 34.5-42.9 53.1-22.6 2-45 5.5-67.2 10.4-1.3-5.1-2.4-10.3-3.5-15.5-9.4-48.4-3.2-84.9 12.6-94zm-24.5 263.6c-4.2-1.2-8.3-2.5-12.4-3.9-21.3-6.7-45.5-17.3-63-31.2-10.1-7-16.9-17.8-18.8-29.9 0-18.3 31.6-41.7 77.2-57.6 5.7-2 11.5-3.8 17.3-5.5 6.8 21.7 15 43 24.5 63.6-9.6 20.9-17.9 42.5-24.8 64.5zm116.6 98c-16.5 15.1-35.6 27.1-56.4 35.3-11.1 5.3-23.9 5.8-35.3 1.3-15.9-9.2-22.5-44.5-13.5-92 1.1-5.6 2.3-11.2 3.7-16.7 22.4 4.8 45 8.1 67.9 9.8 13.2 18.7 27.7 36.6 43.2 53.4-3.2 3.1-6.4 6.1-9.6 8.9zm24.5-24.3c-10.2-11-20.4-23.2-30.3-36.3 9.6.4 19.5.6 29.5.6 10.3 0 20.4-.2 30.4-.7-9.2 12.7-19.1 24.8-29.6 36.4zm130.7 30c-.9 12.2-6.9 23.6-16.5 31.3-15.9 9.2-49.8-2.8-86.4-34.2-4.2-3.6-8.4-7.5-12.7-11.5 15.3-16.9 29.4-34.8 42.2-53.6 22.9-1.9 45.7-5.4 68.2-10.5 1 4.1 1.9 8.2 2.7 12.2 4.9 21.6 5.7 44.1 2.5 66.3zm18.2-107.5c-2.8.9-5.6 1.8-8.5 2.6-7-21.8-15.6-43.1-25.5-63.8 9.6-20.4 17.7-41.4 24.5-62.9 5.2 1.5 10.2 3.1 15 4.7 46.6 16 79.3 39.8 79.3 58 0 19.6-34.9 44.9-84.8 61.4zm-149.7-15c25.3 0 45.8-20.5 45.8-45.8s-20.5-45.8-45.8-45.8c-25.3 0-45.8 20.5-45.8 45.8s20.5 45.8 45.8 45.8z",
            viewBox: "0 0 512 512",
            name: "CodingLab"


        }

        const userdetails = {
            userName: "siva...",
            job: "Web Desginer",
            profile: profile,
        }

        const ListViewdata = [
            {
                title: "A1",
                name: "title1",
            },
            {
                title: "A2",
                name: "title1",
            },
            {
                title: "A3",
                name: "title1",
            },
            {
                title: "A4",
                name: "title1",
            },
            {
                title: "A5",
                name: "title1",
            },
            {
                title: "A6",
                name: "title1",
            },
        ]


        return (
            <main className="main">
                <h1>CSS is Cool</h1>
                <p>
                    I'm baby kale chips affogato ennui lumbersexual, williamsburg paleo quinoa
                    iceland normcore tumeric. Kitsch coloring book retro, seitan schlitz
                    tattooed biodiesel vexillologist neutra. Synth mumblecore deep v, umami
                    selfies normcore gluten-free snackwave. Seitan ramps drinking vinegar
                    venmo keytar, humblebrag VHS post-ironic tacos godard pour-over.
                </p>
                <br />
                <p>
                    Sartorial kogi taxidermy, kickstarter synth yr irony ennui everyday carry
                    retro helvetica stumptown cloud bread squid echo park. Etsy cloud bread
                    sartorial quinoa tacos beard mumblecore shaman tumblr pop-up. Twee retro
                    fingerstache af helvetica pabst 8-bit leggings taiyaki portland ramps tbh
                    tumblr vinyl. Neutra humblebrag bushwick portland subway tile plaid, offal
                    scenester flexitarian cliche squid small batch palo santo. Palo santo meh
                    adaptogen +1 3 wolf moon, listicle brunch ethical fanny pack everyday
                    carry fam. Offal fingerstache taxidermy, man bun venmo PBR&amp;B helvetica
                    thundercats everyday carry tote bag artisan cray wolf jianbing.
                </p>
                <br />
                <p>
                    Taxidermy thundercats whatever austin. VHS helvetica ethical, dreamcatcher
                    enamel pin YOLO shabby chic locavore man bun crucifix pabst chillwave
                    pop-up vegan. Air plant mlkshk ethical echo park tumeric, whatever
                    crucifix godard scenester locavore pork belly yuccie vape. +1 gochujang
                    put a bird on it, pork belly whatever selfies vaporware occupy banh mi
                    normcore VHS. Cornhole normcore hashtag tilde. Hell of yr try-hard DIY raw
                    denim banjo, enamel pin irony polaroid copper mug tofu. Dreamcatcher lomo
                    literally 90's before they sold out, 3 wolf moon banh mi seitan chambray
                    cliche offal tote bag occupy pug.
                </p>
                <br />
                <p>
                    Post-ironic hot chicken salvia yr yuccie ugh cold-pressed keffiyeh franzen
                    viral taxidermy mustache slow-carb crucifix vape. Taiyaki yuccie hell of
                    tacos PBR&amp;B, kitsch meggings tbh truffaut kickstarter mixtape af kogi.
                    Fingerstache vegan tofu waistcoat gentrify cray. Drinking vinegar 3 wolf
                    moon health goth craft beer master cleanse. Letterpress health goth 8-bit
                    chillwave craft beer brooklyn. Chicharrones master cleanse 8-bit,
                    mumblecore copper mug messenger bag poutine lomo kale chips flannel. Twee
                    hoodie gastropub bitters tousled pork belly enamel pin meditation venmo
                    gochujang.
                </p>
                <br />
                <p>
                    Next level selfies cronut ethical. Tofu tumblr you probably haven't heard
                    of them, man braid literally forage swag chillwave. Pug yr flannel
                    tumeric. Coloring book yr chillwave snackwave, shoreditch shaman gentrify
                    typewriter tumeric DIY copper mug small batch. Scenester waistcoat YOLO
                    hexagon kombucha poke 8-bit meditation. Selvage scenester forage
                    williamsburg. Hoodie fingerstache tacos mustache, hashtag quinoa next
                    level sartorial craft beer retro disrupt lo-fi.
                </p>
                <br />
                <p>
                    YOLO twee keytar farm-to-table flexitarian cardigan polaroid lumbersexual
                    adaptogen drinking vinegar echo park dreamcatcher. Brunch shoreditch
                    dreamcatcher iPhone knausgaard plaid edison bulb letterpress ethical yr
                    fanny pack. Typewriter portland woke glossier cronut, post-ironic migas
                    gentrify letterpress cray brunch lyft 8-bit master cleanse. Pitchfork
                    thundercats organic pour-over unicorn lomo.
                </p>
                <br />
                <p>
                    Ugh yr tacos aesthetic everyday carry, tumeric selvage cliche skateboard.
                    Wolf truffaut enamel pin vexillologist poutine. Hoodie roof party pabst,
                    cardigan letterpress af disrupt +1 subway tile chillwave live-edge
                    meggings next level readymade. Master cleanse gentrify hashtag, stumptown
                    fam single-origin coffee occupy dreamcatcher air plant viral vexillologist
                    enamel pin meggings. Tumblr chambray pickled microdosing austin scenester
                    green juice.
                </p>
                <br />
                <p>
                    Austin four dollar toast church-key, vaporware hoodie edison bulb jean
                    shorts sustainable williamsburg plaid helvetica scenester lomo humblebrag.
                    Meditation tumblr kickstarter ennui williamsburg taiyaki pabst pour-over.
                    8-bit godard cred, chillwave enamel pin skateboard you probably haven't
                    heard of them. Meditation before they sold out single-origin coffee swag
                    try-hard jianbing slow-carb shaman leggings. Palo santo shabby chic
                    whatever man bun. Master cleanse wayfarers single-origin coffee pork belly
                    cronut, normcore cliche jianbing before they sold out tousled shabby chic
                    af pop-up gentrify. Direct trade la croix vexillologist jianbing,
                    flexitarian selvage try-hard stumptown polaroid shaman wayfarers poke
                    ramps food truck swag.
                </p>
                <br />
                <p>
                    Pok pok lumbersexual wayfarers, direct trade leggings poutine truffaut
                    kitsch. Seitan aesthetic master cleanse squid coloring book banh mi YOLO
                    vegan locavore vexillologist readymade next level pop-up edison bulb.
                    Selvage knausgaard literally, quinoa photo booth 3 wolf moon microdosing
                    freegan yuccie. Truffaut gentrify lomo put a bird on it waistcoat. Ugh
                    austin distillery, tbh actually pork belly snackwave artisan mixtape
                    quinoa vexillologist pok pok polaroid listicle readymade.
                </p>
                <br />
                <p>
                    Hammock letterpress prism dreamcatcher truffaut shabby chic vice
                    cold-pressed. Franzen pug fashion axe before they sold out, tumblr irony
                    kogi actually af bushwick banh mi. Snackwave bicycle rights tofu
                    dreamcatcher tote bag pour-over meditation raw denim fanny pack. Pop-up
                    retro taiyaki meditation twee gastropub VHS etsy. Semiotics gochujang
                    street art normcore, edison bulb farm-to-table pour-over taxidermy
                    brooklyn.
                </p>


                <CountdownTimer className="sample" interval="1:3:0:10" />
                <DragandDrop className="sample" />
                <JavascriptDnd className="sample" />
                <Navigation className="sample" data={data} />
                <AccordianFirst className="sample" listData={listContent} />
                <Accordian className="sample" listData={listContentSecond} />
                <HorizontalAccordian className="sample" horizontalAccordian_listDATA={horizontalAccordian_listDATA} />
                <Stepper className="sample" />
                <LoadingButton className="sample" />
                <LoadingAnimationButton className="sample" />
                <SelectorBox className="sample" />
                <AnimationSelector className="sample" />
                <Table className="sample" />
                <Customization className="sample" />
                <DenseTable className="sample" />
                <DynamicTableApp className="sample" />
                <SortingAndSelecting className="sample" />
                <AreaChart className="sample" data={AreaChartData} />
                <InterpolationModes className="sample" data={InterpolationmodesData} />
                <Linechart className="sample" data={linechartdata} />
                <LineChartAnimation className="sample" data={LineChartAnimationData} />
                <LineChartBoundaries className="sample" data={LineChartBoundariesData} />
                <LineChartDatasets className="sample" />
                <ScriptableOptionsLineChart className="sample" data={ScriptableOptionsLineChartData} />
                <BarChart className="sample" data={BarChartData} />
                <Barparsing className="sample" data={BarparsingData} />
                <CreatingBarCharts className="sample" data={CreatingBarChartsData} />
                <DensityChart className="sample" data={DensityChartData} />
                <BarChartBorderRadius className="sample" data={BarChartBorderRadiusData} />
                <BarBorderRadius className="sample" data={BarBorderRadiusData} />
                <StackedBar className="sample" data={StackedBarData} />
                <FloatingBars className="sample" data={FloatingBarsData} />
                <BarChartHover className="sample" data={BarChartHoverData} />
                <PieChart className="sample" data={PieChartData} />
                <RadarChart className="sample" data={RadarChartData} />
                <PolarAreaChart className="sample" data={PolarAreaChartData} />
                <Doughnut className="sample" data={DoughnutData} />
                <Delay className="sample" data={DelayData} />
                <Drop className="sample" data={DropData} />
                <Loop className="sample" data={LoopData} />
                <ProgressiveLine className="sample" />
                <Scatter className="sample" data={ScatterData} />
                <CustomTooltipContent className="sample" data={CustomTooltipContentData} />
                <LineSegmentStyling className="sample" />
                <Implementation className="sample" data={ImplementationData} />
                <LineChartUpdate className="sample" data={LineChartUpdateData} />
                <AnimationLineChart className="sample" />
                <LineIndexAxis className="sample" data={LineIndexAxisData} />
                <UpdateChartType
                    className="sample"
                    config={config} configline={configline} configbar={configbar}
                    configdoughnut={configdoughnut} configpie={configpie}
                    configradar={configradar} configscatter={configscatter}
                    configbubble={configbubble} configpolarArea={configpolarArea} />

                {/* <LearnFilterAnimation className="sample" data={filterdata} /> */}


                <BouncingBall className="sample" />
                <ButtonHoverEffects
                    className="sample"
                    bodybg="#000000"
                    color="#ffffff"
                    hcolor="#000000"
                    bgcolor="#00ff00"
                    hueRotate="#00E6FF" />
                <ClippathButtonHoverEffect className="sample" />
                <Clock className="sample" />
                <Effect className="sample" data={Effectdata} color={true} size={true} BuyNow={true} />
                <LiquidLoader className="sample" darkcolor="#00bcd4" lightcolor="#c7eeff" />
                <Loading className="sample" hueStart={30} hueEnd={360} />
                <MediaIcon className="sample" data={mediaIcon} />
                <Pepsi className="sample" image={PepsiImage} />
                <RadioButton className="sample" />
                <TextTyping className="sample" />
                <HeaderNavigation className="sample" data={HeaderNavigationDatas} logo={HeaderNavigationLogo} />

                {/* all components commend use next NavigationLeft uncommend  */}

                {/* <NavigationLeft className="sample" withlogo={true} data={navData} logo={navLogo} userdetails={userdetails} withprofile={true} /> */}

                <Netflix className="sample" />
                <ListView className="sample" position="left" data={ListViewdata} itemTemplate={SampleCompOne} mapping={{
                    symbol: "title",
                    company: "name"
                }} />
                <DragDrop />
                <Dnd /> 
                <SortableComponent />

            </main>
        )
    }
}

export default Mian;