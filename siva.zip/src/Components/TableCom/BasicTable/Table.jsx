import React from "react";
import "./table.css";
class Table extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            tableData: [
                {
                    Dessert: "Frozen yoghurt",
                    Calories: "159",
                    Fat: "6",
                    Carbs: "24	",
                    Protein: "4"
                },
                {
                    Dessert: "Ice cream sandwich",
                    Calories: "237",
                    Fat: "9	",
                    Carbs: "37",
                    Protein: "4.3"
                },
                {
                    Dessert: "Eclair",
                    Calories: "262",
                    Fat: "16	",
                    Carbs: "24",
                    Protein: "6"
                },
                {
                    Dessert: "Cupcake",
                    Calories: "305	",
                    Fat: "3.7	",
                    Carbs: "67",
                    Protein: "4.3"
                },
                {
                    Dessert: "Gingerbread",
                    Calories: "356",
                    Fat: "16	",
                    Carbs: "49",
                    Protein: "3.9"
                }
            ]
        }
    }
    render() {
        return (

            <div className={"tableContainer " + this.props.className}>
                <table >
                    <tr>
                        <th>Dessert (100g serving)</th>
                        <th>Calories</th>
                        <th>Fat (g)</th>
                        <th>Carbs (g)</th>
                        <th>Protein (g)</th>
                    </tr>
                    {this.state.tableData.map((item, index) => {
                        return (
                            <tr key={index}>
                                <td>{item.Dessert}</td>
                                <td>{item.Calories}</td>
                                <td>{item.Fat}</td>
                                <td>{item.Carbs}</td>
                                <td>{item.Protein}</td>
                            </tr>
                        )
                    })}

                </table>

            </div>
        );
    }
}

export default Table;