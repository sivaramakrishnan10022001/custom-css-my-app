import React from "react";
import "./Customization.css";

class Customization extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			// heading:{ dessert: "Dessert (100g serving)" ,calories: "Calories", fat: "Fat (g)", carbs: "Carbs (g)", protein: "Protein (g)" },
			heading: ["dessert", "calories", "fat", "carbs", "protein"],

			customization_data_original: [
				{
					dessert: "Frozen yoghurt",
					calories: 159,
					fat: 6,
					carbs: 24,
					protein: 4,
				},
				{
					dessert: "Ice cream sandwich",
					calories: 237,
					fat: 9,
					carbs: 37,
					protein: 4.3,
				},
				{
					dessert: "Eclair",
					calories: 262,
					fat: 16,
					carbs: 24,
					protein: 6,
				},
				{
					dessert: "Cupcake",
					calories: 305,
					fat: 3.7,
					carbs: 67,
					protein: 4.3,
				},
				{
					dessert: "Gingerbread",
					calories: 356,
					fat: 16,
					carbs: 49,
					protein: 3.9,
				},
			],
			customization_data: [],
		};
		this.myRef = React.createRef();
		this.refOver = React.createRef();
		this.headingRef = React.createRef();
		this.headingHoverRef = React.createRef();
	}
	componentDidMount() {
		this.setState({
			customization_data: this.state.customization_data_original,
		});
	}

	headingStart = (e, index) => {
		this.headingRef = index;
		console.log("position", this.headingRef);
		console.log(e.target.innerHTML);
	};

	headingHover = (e, index) => {
		this.headingHoverRef = index;
		console.log("position", this.headingHoverRef);
		console.log(e.target.innerHTML);
	};

	headingEnd = () => {
		let data = [...this.state.heading];
		let copyheading = data[this.headingRef];
		data.splice(this.headingRef, 1);
		data.splice(this.headingHoverRef, 0, copyheading);
		this.headingRef = null;
		this.headingHoverRef = null;
		this.setState({
			heading: data,
		});
	};

	dragStart = (e, position) => {
		this.myRef.current = position;
		console.log(e.target.innerHTML, "start");
	};

	dragenter = (e, position) => {
		this.refOver.current = position;
		console.log(e.target.innerHTML, "hover");
	};

	dragEnd = () => {
		let datas = [...this.state.customization_data];
		let copydata = datas[this.myRef.current];
		console.log("end", copydata);
		datas.splice(this.myRef.current, 1);
		datas.splice(this.refOver.current, 0, copydata);
		this.myRef.current = null;
		this.refOver.current = null;
		this.setState({
			customization_data: datas,
		});
	};

	render() {
		return (
			<div className={"Customization " + this.props.className}>
				<div>
					<h1>Customization</h1>
				</div>
				<div className="table_wapper">
					<div className="table_container">
						<table>
							<thead>
								<tr>
									{this.state.heading.map((v, index) => {
										return (
											<th
												onDragStart={(e) => this.headingStart(e, index)}
												onDragEnter={(e) => this.headingHover(e, index)}
												onDragEnd={() => this.headingEnd()}
												draggable
											>
												{v}
											</th>
										);
									})}
								</tr>
							</thead>
							<tbody>
								{this.state.customization_data.map((value, inx) => {
									const AddNumber = inx % 2;
									return (
										<tr
											key={inx}
											className={AddNumber === 0 ? "grey" : "white"}
											onDragStart={(e) => this.dragStart(e, inx)}
											onDragEnter={(e) => this.dragenter(e, inx)}
											onDragEnd={(e) => this.dragEnd(e)}
											draggable
										>
											{this.state.heading.map((hval, hindex) => {
												return <td>{value[hval]}</td>;
											})}
										</tr>
									);
								})}
							</tbody>
							{/* <tfoot></tfoot> */}
						</table>
					</div>
				</div>
			</div>
		);
	}
}

export default Customization;
