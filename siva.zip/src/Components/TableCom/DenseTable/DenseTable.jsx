import React from "react";
import "./DenseTable.css";

class DenseTable extends React.Component{

    constructor(props){
        super(props);
        this.state={
            DenseTableData:[
                {
                    name:"Frozen yoghurt",
                    calories: 159 ,
                    fat: 6.0, 
                    carbs: 24,
                    protein:4.0 ,
                },
                {
                    name:"Ice cream sandwich",
                    calories: 237 ,
                    fat: 9.0, 
                    carbs: 37,
                    protein:4.3 ,
                },
                {
                    name:"Eclair",
                    calories: 262 ,
                    fat:16.0, 
                    carbs: 24,
                    protein:6.0,
                },
                {
                    name:"Cupcake",
                    calories: 305 ,
                    fat:3.7, 
                    carbs: 67,
                    protein:4.3,
                },
                {
                    name:"Gingerbread",
                    calories: 356 ,
                    fat:16.0, 
                    carbs: 49,
                    protein:3.9,
                },
            ]   
        }
    }
    render(){
        return(
            <div className={"DenseTable "+this.props.className}>
               <table>
                   <thead>
                       <tr> 
                           <th>Dessert (100g serving)</th>
                           <th>Calories	</th>
                           <th>Fat (g)</th>
                           <th>Carbs (g)</th>
                           <th>Protein (g)</th>
                       </tr>
                   </thead>
                   <tbody>
                       {this.state.DenseTableData.map((item,index)=>{
                           return(
                              <tr key={index}>
                                  <td>{item.name}</td>
                                  <td>{item.calories}</td>
                                  <td>{item.fat}</td>
                                  <td>{item.carbs}</td>
                                  <td>{item.protein}</td>
                              </tr>
                           );
                       })}
                   </tbody>
                   <tfoot></tfoot>
               </table>
            </div>
        );
    }
}

export default DenseTable