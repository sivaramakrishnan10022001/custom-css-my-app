import React from "react";
import DynamicTable from "./dynamicTable";
import "./dynamicTable.css";

class DynamicTableApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            checkbox: true,
            heading: {
                id: "id",
                firstname: "firstname",
                lastname: "lastname",
                age: "age",
                fullname: "fullname",

            },
            hideColumns: {
                checkbox: "Checkbox selection",
                id: "id",
                firstname: "firstname",
                lastname: "lastname",
                age: "age",
                fullname: "fullname",
            },
            hideColumnchecked: {
                checkbox: true,
                id: true,
                firstname: true,
                lastname: true,
                age: true,
                fullname: true,

            },
            filterLogic: {
                contains: "Contains",
                operators: "equals",
                startswith: "starts with",
                endswith: "ends with",
                isempty: "is empty",
                isnotempty: "is not empty"
            },
            filterNumberLogic: {
                equal: "=",
                notequal: "!=",
                greaterthan: ">",
                greaterthanequal: ">=",
                lessthan: "<",
                lessthanequal: "<=",
                isempty: "is empty",
                isnotempty: "is not empty"
            },

            // filterNumberLogic: {
            //     equal:"equal",
            //     notequal: "not equal",
            //     greaterthan:"greaterthan",
            //     greaterthanequal: "greaterthan equal",
            //     lessthan: "lessthan",
            //     lessthanequal: "lessthan equal",
            //     isempty: "is empty",
            //     isnotempty: "is not empty"
            // },

            data: [
                {
                    id: 1, firstname: "sivarama", lastname: "krishnan", age: 22, fullname: "sivaramakrishnan",
                },
                {
                    id: 2, firstname: "vel", lastname: "murugan", age: 27, fullname: "Velmurugan",
                },
                {
                    id: 3, firstname: "anbu", lastname: "raj", age: 11, fullname: "anbu raj",
                },
                {
                    id: 4, firstname: "sasi", lastname: "kumar", age: 19, fullname: "raj kumar",
                },
                {
                    id: 5, firstname: "raja", lastname: "pandi", age: 34, fullname: "raja pandi",
                },
                {
                    id: 6, firstname: "mani", lastname: 'kandan', age: 42, fullname: "manikandan"
                },
                {
                    id: 7, firstname: 'Ferrara', lastname: 'Clifford', age: 44, fullname: "Clifford Ferrara",
                },
                {
                    id: 8, firstname: 'Rossini', lastname: 'Frances', age: 36, fullname: "Frances Rossini",
                },
                {
                    id: 9, firstname: 'Harvey', lastname: 'Roxie', age: 65, fullname: "Roxie Harvey",
                },
                {
                    id: 10, firstname: "John", lastname: "Smith", age: 22, fullname: "John Smith",
                },
                {
                    id: 11, firstname: "Ted", lastname: "Masters", age: 27, fullname: "Ted Masters",
                },
                {
                    id: 12, firstname: "Fran", lastname: "Jones", age: 11, fullname: "Fran Jones",
                },
                {
                    id: 13, firstname: "Tallulah", lastname: "Smith", age: 19, fullname: "Tallulah Smith",
                },
                {
                    id: 14, firstname: "Vimal", lastname: "Kashiyani", age: 34, fullname: "Vimal Kashiyani",
                },
                {
                    id: 15, firstname: "Hardik", lastname: 'Savani', age: 100, fullname: "Hardik Savani",
                },
                {
                    id: 16, firstname: 'Harshad', lastname: 'Pathak', age: 32, fullname: "Harshad Pathak",
                },
                {
                    id: 17, firstname: 'Harsukh', lastname: 'Makawana', age: 65, fullname: "Harsukh Makawana",
                },
                {
                    id: 18, firstname: 'muthu', lastname: 'vel', age: 27, fullname: "Muthuvel",
                },
                {
                    id: 19, firstname: 'sv', lastname: 'vel', age: 27, fullname: "Muthuvel",
                },
            ],

        }
    }
    render() {
        return (

            <DynamicTable
                className={this.props.className}
                heading={this.state.heading}
                data={this.state.data}
                hideColumns={this.state.hideColumns}
                checkbox={this.state.checkbox}
                filterLogic={this.state.filterLogic}
                filterNumberLogic={this.state.filterNumberLogic}
                hideColumnchecked={this.state.hideColumnchecked} />

        )
    }

}

export default DynamicTableApp;