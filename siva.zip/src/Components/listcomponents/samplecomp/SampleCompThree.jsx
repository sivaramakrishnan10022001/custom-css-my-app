import React from "react";

export const SampleCompThree = (props)=> {

    return(
        <div>{props.title}{props.name}</div>
    )
}