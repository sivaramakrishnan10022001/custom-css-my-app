import React from "react";

export const SampleCompTwo = (props)=> {
    return(
        <div>{props.title}{props.name}</div>
    )
}